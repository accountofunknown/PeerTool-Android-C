// Top-level build file. AGP 9.x ships built-in Kotlin, so the
// org.jetbrains.kotlin.android plugin is intentionally NOT applied.
// The Compose compiler plugin below also puts Kotlin Gradle Plugin
// (same version) on the build classpath, which built-in Kotlin picks up.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
