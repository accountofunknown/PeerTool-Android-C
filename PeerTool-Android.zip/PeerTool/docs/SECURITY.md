# Security notes and threat model

## Assets
Message content, identity private keys, contact list, who talks to whom.

## Adversaries considered
1. Network observer / malicious Wi-Fi: must not read or modify messages.
2. Honest-but-curious or malicious signaling server: must not read or forge messages; can see peer IDs, IPs, timing and refuse service.
3. Other nearby device or internet peer: can open links to you; must not be able to impersonate a contact or flood you.
4. Someone with the unlocked-off phone file system (no root): must not read message bodies or private keys from app storage.

Not defended: a compromised/rooted phone while unlocked, a malicious OS, traffic analysis, anonymity, a contact who screenshots/forwards.

## Design
* Identity = Tink ECIES (P-256, HKDF-HMAC-SHA256, AES-128-GCM) key pair + Ed25519 signing key pair. Peer ID = base32(SHA-256(public bundle)[0..16]) so an ID cryptographically names its keys; a key change means a new ID (never a silent change under the same ID).
* Each message: inner JSON is ECIES-encrypted to the recipient with the envelope fields (kind, id, from, to) bound as associated data; the envelope (including ciphertext and timestamp) is Ed25519-signed.
* Links are authenticated with a signed challenge/response (nonce from the verifier), so "connected" only ever means "the holder of this peer's private key answered just now". Re-challenged every ~25 s for liveness.
* Delivery: sender stores encrypted envelope + outbox job in one SQLite transaction, transmits, and marks DELIVERED only on an authenticated ack. Receiver verifies, decrypts, dedups and stores message + dedup record in one transaction, and acks after commit (duplicates are re-acked). At-least-once transport, idempotent receive.
* Replay: dedup table keyed by (peer, message id) kept 14 days; envelopes older than 8 days or >10 min in the future are rejected.
* At rest: private keysets and message bodies are sealed with a non-exportable Android Keystore AES-256-GCM key (hardware-backed where the device supports it). Backups and device transfer are disabled.
* Limits: envelope ≤ 64 KB, text ≤ 8,000 bytes, per-link receive rate limit, ≤ 24 links, ≤ 6 unknown-peer links, ≤ 50 pending contact requests, bounded outbox. Names are stripped of control/bidi characters. No JavaScript bridge or WebView exists.
* Logs: in-memory ring buffer only, contains shortened peer IDs and event names, never message text, keys or credentials.

## Known gaps
* No forward secrecy / post-compromise security (static ECIES per message). A future compromise of a private key exposes recorded ciphertext.
* A relaying attacker can proxy a challenge/response between two honest parties (channel binding is not implemented); content stays protected but can be dropped or delayed.
* Contact-request metadata (display name, public bundle) is signed but sent in the clear, because no key exists yet.
* The TURN credential is stored sealed but is used in cleartext by the WebRTC stack.
* Deletion-for-everyone, read receipts and acks are best-effort and not retried.
* Attachments are not implemented.
* Not independently audited; the code was not compiled or run by its author.
