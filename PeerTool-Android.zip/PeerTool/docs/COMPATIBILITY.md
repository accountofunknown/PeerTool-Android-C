# Compatibility report

Selected on 2026-10-27. "Verified" = looked up in official/maintainer sources during this build.
"Pinned from prior knowledge" = a version known to exist and to be compatible but NOT re-verified as the newest; update if a newer stable is wanted.

| Component | Version | Status / source |
|---|---|---|
| Android Gradle Plugin | 9.4.0 | Verified: developer.android.com/build/releases/about-agp and agp-9-4-0-release-notes (stable, Sept 2026) |
| Gradle | 9.6.0 | Verified: same AGP page (minimum/default Gradle for AGP 9.4) |
| JDK (build) | 17 | Verified: AGP 9.4 requires JDK 17+ |
| Build-tools / compileSdk / targetSdk | 36.0.0 / 37 / 36 | Build tools verified (AGP 9.4 default). compileSdk 37 is REQUIRED by androidx.core 1.19 and Compose 1.12 (confirmed by the first CI run); targetSdk stays 36 so no API 37 runtime behaviour changes are opted into |
| minSdk | 26 | Project decision (java.util.Base64, adaptive icons, Keystore AES-GCM) |
| Kotlin | 2.4.10 | Verified from AGP "built-in Kotlin" migration guide (example version). AGP 9 built-in Kotlin: `org.jetbrains.kotlin.android` is not applied |
| Compose compiler plugin | 2.4.10 (same as Kotlin) | Required to match Kotlin |
| Compose BOM | 2026.08.00 | Cited in official Compose BOM docs; compose-ui 1.12.x / material3 1.4.x stable per AndroidX release pages |
| androidx.core:core-ktx | 1.19.0 | Verified stable (AndroidX versions page) |
| androidx.work:work-runtime-ktx | 2.11.2 | Verified (AndroidX / binding release listing) |
| androidx.activity:activity-compose | 1.10.1 | Pinned from prior knowledge |
| androidx.lifecycle:lifecycle-runtime-compose | 2.9.2 | Pinned from prior knowledge (2.11 RC existed mid-2026) |
| kotlinx-coroutines-android | 1.10.2 | Pinned from prior knowledge |
| OkHttp | 4.12.0 | Pinned from prior knowledge (maintained 4.x line) |
| Google Tink (tink-android) | 1.23.0 | Verified: developers.google.com/tink Java setup |
| WebRTC (io.getstream:stream-webrtc-android) | 1.3.10 | Verified: Maven Central listing / GetStream releases (unofficial but maintained build of libwebrtc; Google's own artifact is deprecated) |
| play-services-nearby | 19.3.0 | Pinned from prior knowledge |
| play-services-code-scanner | 16.1.0 | Pinned from prior knowledge |
| ZXing core | 3.5.3 | Pinned from prior knowledge (QR generation only) |
| JUnit / org.json / sqlite-jdbc (tests only) | 4.13.2 / 20240303 / 3.46.1.0 | Pinned from prior knowledge |
| GitHub Actions | checkout v4, setup-java v4, gradle/actions/setup-gradle v4, upload-artifact v4 | Majors known to exist and be supported; newer majors may exist |

Notes
* Persistence uses platform SQLite (`SQLiteOpenHelper`) with a tested, versioned migration chain instead of Room, to avoid an annotation-processor (KSP) dependency whose compatibility with AGP 9 built-in Kotlin could not be verified without a build.
* PeerJS (JavaScript) is not embedded. Only its signaling *protocol* is implemented natively, so no WebView/JS bridge exists.
* CI history: run 1 resolved all dependencies and compiled the Kotlin sources (`compileDebugKotlin` succeeded) but failed AAR-metadata checks because compileSdk was 36; fixed by moving to 37.
