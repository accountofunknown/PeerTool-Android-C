# PeerTool

Hybrid peer-to-peer Android messenger. Application ID `creator.peer.tool`, app name **PeerTool**.
Native Kotlin, Jetpack Compose (Material 3), single `app` module.

## Build on GitHub from an Android phone

1. Create (or open) a GitHub repository.
2. Upload **`PeerTool-Android.zip`** to the repository root (*Add file → Upload files*). Do not extract it.
3. Add the workflow as **`.github/workflows/peer-tool-android.yml`**
   (*Add file → Create new file*, type the full path as the file name, paste the contents of `peer-tool-android.yml`).
   GitHub only runs workflows stored in `.github/workflows/`; a copy at the repository root will not run.
4. Open the **Actions** tab. The workflow starts on push, or tap *PeerTool Android Build → Run workflow*.
5. When it finishes, open the run and download the **PeerTool-debug-APK** artifact (a zip containing `PeerTool-debug.apk`,
   its SHA-256 and a build summary). Extract it on the phone and install the APK (allow "install unknown apps" for your file manager).
6. If a run fails, download **PeerTool-reports** (test/lint) and open the failing step's log; send the log so it can be fixed.

The ZIP intentionally ships `gradle/wrapper/gradle-wrapper.properties` but not `gradle-wrapper.jar`/`gradlew`; the workflow
generates the wrapper with the pinned Gradle version, then builds with `./gradlew`.

## Project layout

```
PeerTool/
  settings.gradle.kts, build.gradle.kts, gradle.properties
  gradle/libs.versions.toml            version catalog (all versions pinned)
  gradle/wrapper/gradle-wrapper.properties
  app/src/main/java/creator/peer/tool/
    crypto/      identity keys (Tink), Keystore at-rest cipher
    protocol/    wire envelopes, inner payloads, share links
    storage/     SQLite schema + migrations, Store, settings
    transport/   Transport interface, WebRTC (+PeerJS signaling), Nearby Connections
    routing/     route selection policy
    messaging/   MessagingEngine (auth, handshake, outbox, receipts), WorkManager worker
    service/     optional foreground service
    notifications/, ui/, util/
  app/src/test/  JVM unit tests
  docs/          COMPATIBILITY.md, SECURITY.md
```

## What is implemented

* Identity: Ed25519 signing key + ECIES P-256 encryption key (Google Tink), peer ID = hash of the public bundle (an ID authenticates its keys).
* Contacts: QR (ML Kit code scanner) / link / manual ID, request + accept, block, remove, rename, mute, verification codes.
* Messaging: text (Unicode), reply, pin, local search (per chat and global), delete locally, delete-for-everyone (best effort),
  delivery acks (separate from optional read receipts), duplicate suppression, durable outbox with bounded exponential backoff + jitter,
  expiry, resend/cancel, recovery after process death.
* Transports: WebRTC data channels with PeerJS-protocol signaling (public PeerJS cloud or self-hosted), STUN/TURN settings;
  Google Nearby Connections for offline Bluetooth/Wi-Fi links. Every link is authenticated with a signed challenge before use,
  with periodic liveness checks. Connection states shown in UI: discovered, connecting, connected, degraded, reconnecting, disconnected, failed.
* Privacy/storage: discoverability, read receipts, notification previews off by default, retention, backups disabled.
* **File sharing (v1.1):** images and documents up to a configurable limit (5–100 MB). The offer (name, size, SHA-256, one-time AES-256 key) is a normal end-to-end encrypted message; after the receiver taps Download, 16 KiB chunks are pulled in a sliding window, each AES-GCM encrypted and bound to transfer/index/count. Progress bars, cancel, retry, resume after a dropped connection or app restart (bitmap checkpoints), whole-file SHA-256 verification, open/save-as, image previews, optional auto-download of images from verified contacts, orphan/temp file cleanup, expiry of never-accepted offers.
* **Easy adding (v1.2):**
  * **Short invite code** (e.g. `K7M4-QX2P`): tap *Create a code*, give it to the other person, they enter it under *Add contact*. Single use, valid 10 minutes, you approve the request, and both sides prove they know the code, so the contact ends up marked verified. Needs both phones online.
  * **Handle** (e.g. `@shashank`): an optional label under Settings → Profile, sent to contacts and included in your QR. It is a label, not a unique address.
  * **Easy-to-say ID name** (e.g. `brave-otter-42`) shown next to every peer ID for reading aloud when comparing security codes.
  * The slow "custom ID search" from v1.1 was removed.
* **Reactions, chat export (plain text, with warning), app lock (phone PIN/pattern/biometrics), block screenshots/recents preview (v1.1).**

## Deferred / not implemented (by design, to avoid half-working features)

Message editing, disappearing messages, multi-device, group chat, voice/video calls, forward secrecy (no ratchet),
store-and-forward relay service, typing indicators. See `docs/SECURITY.md`.

## Limitations to know about

* Both phones must have the app running to exchange messages; Android may stop background apps (Doze, battery optimisation, force-stop).
* The default signaling server is third-party public infrastructure; it learns peer IDs, IP addresses and timing, never message content.
* Nearby needs Google Play services and runtime permissions; the QR scanner also uses Google Play services.
* This is a debug-signed APK, not a production release.
