# WebRTC (JNI calls into org.webrtc classes by name)
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**
# Tink uses reflection for key manager registration
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn com.google.crypto.tink.**
# OkHttp
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
