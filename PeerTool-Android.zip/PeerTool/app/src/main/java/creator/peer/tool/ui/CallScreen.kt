package creator.peer.tool.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.messaging.CallInfo
import creator.peer.tool.messaging.CallPhase
import kotlinx.coroutines.delay
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

/** Full-screen call UI. Shown on top of everything whenever a call exists (ringing, connecting, active, just ended). */
@Composable
fun CallOverlay(c: AppContainer) {
    val info by c.engine.calls.info.collectAsStateWithLifecycle()
    val i = info
    if (i != null) {
        BackHandler(enabled = true) { /* back does not leave a call; use the End button */ }
        CallScreen(c, i)
    }
}

private fun granted(ctx: android.content.Context, perm: String): Boolean =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
private fun CallScreen(c: AppContainer, i: CallInfo) {
    val ctx = LocalContext.current
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    val calls = c.engine.calls
    val local by calls.localVideo.collectAsStateWithLifecycle()
    val remote by calls.remoteVideo.collectAsStateWithLifecycle()
    val inCall = i.phase == CallPhase.CONNECTING || i.phase == CallPhase.ACTIVE

    val answerPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) calls.answer(granted(ctx, Manifest.permission.CAMERA)) else calls.decline()
    }
    val elapsed by produceState(0L, i.activeSince) {
        while (true) {
            val since = i.activeSince
            value = if (since != null) ((System.currentTimeMillis() - since) / 1000).coerceAtLeast(0) else 0L
            delay(500)
        }
    }
    val statusLine = when {
        i.phase == CallPhase.ACTIVE -> "%d:%02d".format(elapsed / 60, elapsed % 60)
        else -> i.status
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0E1018))) {
        val showRemote = i.video && inCall && remote != null
        if (showRemote) {
            VideoView(remote, calls.eglBaseContext(), mirror = false, overlay = false, modifier = Modifier.fillMaxSize())
        } else {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Avatar(i.peerName, 96.dp, i.peerId)
                Spacer(Modifier.height(20.dp))
                Text(i.peerName, color = Color.White, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Text(statusLine, color = Color(0xCCFFFFFF), style = MaterialTheme.typography.bodyLarge)
            }
        }
        if (showRemote) {
            Column(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(16.dp)) {
                Text(i.peerName, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(statusLine, color = Color(0xCCFFFFFF), style = MaterialTheme.typography.labelSmall)
            }
        }
        if (i.video && local != null && i.cameraOn && i.phase != CallPhase.ENDED) {
            VideoView(
                local, calls.eglBaseContext(), mirror = true, overlay = true,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(12.dp)
                    .size(108.dp, 156.dp)
                    .clip(RoundedCornerShape(14.dp)),
            )
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Top,
        ) {
            when (i.phase) {
                CallPhase.INCOMING -> {
                    CallButton("\u260E", "Decline", Color(0xFFD13B3B)) { calls.decline() }
                    CallButton("\u2706", "Accept", Color(0xFF2E9E6B)) {
                        val needed = ArrayList<String>()
                        if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
                        if (i.video && !granted(ctx, Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
                        if (needed.isEmpty()) calls.answer(granted(ctx, Manifest.permission.CAMERA)) else answerPerms.launch(needed.toTypedArray())
                    }
                }
                CallPhase.ENDED -> Unit
                else -> {
                    CallButton(if (i.muted) "\uD83D\uDD07" else "\uD83C\uDFA4", if (i.muted) "Unmute" else "Mute", if (i.muted) Color(0x99FFFFFF) else Color(0x33FFFFFF)) { calls.toggleMute() }
                    CallButton(if (i.speaker) "\uD83D\uDD0A" else "\uD83D\uDD08", "Speaker", if (i.speaker) Color(0x99FFFFFF) else Color(0x33FFFFFF)) { calls.toggleSpeaker() }
                    if (i.video && local != null) {
                        CallButton("\uD83D\uDCF7", if (i.cameraOn) "Camera off" else "Camera on", if (i.cameraOn) Color(0x33FFFFFF) else Color(0x99FFFFFF)) { calls.toggleCamera() }
                        CallButton("\uD83D\uDD04", "Flip", Color(0x33FFFFFF)) { calls.switchCamera() }
                    }
                    CallButton("\u260E", "End", Color(0xFFD13B3B)) { calls.hangup() }
                }
            }
        }
    }
}

@Composable
private fun CallButton(symbol: String, label: String, background: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(background)
                .clickable(onClick = onClick)
                .semantics { contentDescription = label },
            contentAlignment = Alignment.Center,
        ) {
            Text(symbol, fontSize = 26.sp, color = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun VideoView(track: VideoTrack?, egl: EglBase.Context, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val renderer = remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            SurfaceViewRenderer(ctx).also { r ->
                r.init(egl, null)
                r.setMirror(mirror)
                r.setEnableHardwareScaler(true)
                r.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                if (overlay) r.setZOrderMediaOverlay(true)
                renderer.value = r
            }
        },
    )
    val r = renderer.value
    DisposableEffect(track, r) {
        if (r != null && track != null) {
            try {
                track.addSink(r)
            } catch (_: Throwable) {
            }
        }
        onDispose {
            if (r != null && track != null) {
                try {
                    track.removeSink(r)
                } catch (_: Throwable) {
                }
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            try {
                renderer.value?.release()
            } catch (_: Throwable) {
            }
        }
    }
}
