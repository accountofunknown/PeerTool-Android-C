@file:OptIn(ExperimentalMaterial3Api::class)

package creator.peer.tool.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import creator.peer.tool.AppContainer
import creator.peer.tool.storage.ContactState
import creator.peer.tool.util.Perms
import creator.peer.tool.util.Qr
import kotlinx.coroutines.launch

@Composable
private fun BackBar(title: String, nav: Nav) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = { IconButton(onClick = { nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
    )
}

// ------------------------------------------------------------------ add contact

@Composable
fun AddContactScreen(c: AppContainer, nav: Nav) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var input by rememberSaveable { mutableStateOf("") }
    val nearby by c.engine.nearby.collectAsStateWithLifecycle()
    val contacts by rememberContacts(c)
    val settings by c.settings.flow.collectAsStateWithLifecycle()
    val pending by c.pendingLink.collectAsStateWithLifecycle()

    fun submit(text: String) {
        scope.launch {
            val t = text.trim()
            val r = if (t.startsWith("peertool://")) c.engine.addContactFromLink(t) else c.engine.addContactById(t)
            r.onSuccess {
                snack.showSnackbar("Request sent. They need to accept it.")
                input = ""
                nav.pop()
            }.onFailure { snack.showSnackbar(it.message ?: "Could not add contact") }
        }
    }

    LaunchedEffect(pending) {
        val p = pending
        if (p != null) {
            c.pendingLink.value = null
            input = p
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        c.engine.kick()
    }

    Scaffold(
        topBar = { BackBar("Add contact", nav) },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                "The safest way is to scan the other person's QR code in person: it proves their identity key. " +
                    "Adding by ID only works if you got the ID from them over a channel you trust.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(16.dp))
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
                    GmsBarcodeScanning.getClient(ctx, opts).startScan()
                        .addOnSuccessListener { code -> code.rawValue?.let { submit(it) } }
                        .addOnFailureListener {
                            scope.launch { snack.showSnackbar("Scanner unavailable. Paste the link or ID instead.") }
                        }
                },
            ) { Text("Scan QR code") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { nav.push(Route.MyIdentity) }) { Text("Show my QR code") }

            SectionTitle("PASTE LINK OR ID")
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text("peertool:// link or peer ID") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { submit(input) }, enabled = input.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("Send request")
            }

            SectionTitle("NEARBY DEVICES")
            if (!settings.nearbyEnabled) {
                Text(
                    "Turn on nearby discovery to find people around you without internet. It uses Bluetooth and Wi-Fi and needs Google Play services.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    val missing = Perms.missing(ctx, Perms.nearbyRequired())
                    c.settings.update { it.copy(nearbyEnabled = true) }
                    if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
                }) { Text("Enable nearby discovery") }
            } else if (nearby.isEmpty()) {
                Text("Looking for PeerTool users nearby…", style = MaterialTheme.typography.bodyMedium)
            } else {
                for (n in nearby) {
                    val known = contacts.firstOrNull { it.peerId == n.advertisedId }
                    ListItem(
                        leadingContent = { Avatar(known?.displayName ?: "?", 40.dp, n.advertisedId) },
                        headlineContent = { Text(known?.displayName ?: "PeerTool user") },
                        supportingContent = { Text(n.advertisedId.take(10) + "…", fontFamily = FontFamily.Monospace) },
                        trailingContent = {
                            if (known == null || known.state != ContactState.ACCEPTED) {
                                TextButton(onClick = { submit(n.advertisedId) }) { Text("Request") }
                            } else {
                                TextButton(onClick = { nav.push(Route.Chat(n.advertisedId)) }) { Text("Chat") }
                            }
                        },
                    )
                }
                Text(
                    "Nearby names are not verified. After connecting, compare security codes in person.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ------------------------------------------------------------------ my identity

@Composable
fun MyIdentityScreen(c: AppContainer, nav: Nav) {
    val ctx = LocalContext.current
    val settings by c.settings.flow.collectAsStateWithLifecycle()
    val link = remember(settings.displayName) { c.engine.myShareLink() }
    val peerId = c.engine.myPeerId() ?: ""
    val fp = c.engine.myFingerprint() ?: ""
    val bmp = remember(link) { link?.let { Qr.render(it) } }

    Scaffold(topBar = { BackBar("My code", nav) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(settings.displayName, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "QR code with your PeerTool identity",
                    modifier = Modifier.size(260.dp).clip(RoundedCornerShape(12.dp)).background(androidx.compose.ui.graphics.Color.White),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Let your contact scan this in person. It contains only your public keys and name.",
                style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            )
            SectionTitle("YOUR PEER ID")
            Text(peerId, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
            SectionTitle("SECURITY CODE")
            Text(fp, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { copyToClipboard(ctx, "PeerTool ID", peerId) }) { Text("Copy ID") }
                Button(onClick = {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link ?: peerId)
                    ctx.startActivity(Intent.createChooser(i, "Share your PeerTool link"))
                }) { Text("Share link") }
            }
        }
    }
}

// ------------------------------------------------------------------ contact detail & verification

@Composable
fun ContactDetailScreen(c: AppContainer, peerId: String, nav: Nav) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contacts by rememberContacts(c)
    val contact = contacts.firstOrNull { it.peerId == peerId }
    val states by c.engine.peerStates.collectAsStateWithLifecycle()
    var renaming by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var confirmBlock by remember { mutableStateOf(false) }

    Scaffold(topBar = { BackBar("Contact", nav) }) { pad ->
        if (contact == null) {
            EmptyState("Contact not found", "It may have been removed.", Modifier.padding(pad))
            return@Scaffold
        }
        val theirFp = contact.bundle?.let { creator.peer.tool.crypto.PeerCrypto.fingerprint(it) }
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(contact.displayName, 64.dp, peerId)
                Spacer(Modifier.size(16.dp))
                Column {
                    Text(contact.displayName, style = MaterialTheme.typography.titleLarge)
                    ConnBadge(states[peerId])
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { renaming = true }) { Text("Rename") }
                OutlinedButton(onClick = { c.engine.connectNow(peerId) }) { Text("Connect now") }
                if (contact.state == ContactState.ACCEPTED) {
                    Button(onClick = { nav.push(Route.Chat(peerId)) }) { Text("Message") }
                }
            }

            SectionTitle("PEER ID")
            Text(peerId, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)

            SectionTitle("SECURITY CODES")
            if (theirFp != null) {
                Text("Theirs", style = MaterialTheme.typography.labelSmall)
                Text(theirFp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Text("Yours", style = MaterialTheme.typography.labelSmall)
                Text(c.engine.myFingerprint() ?: "", fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Compare these codes with your contact in person or over a call. If they match on both phones, no one is impersonating either of you. " +
                        "A person's ID is derived from their keys, so changed keys always show up as a different ID/new contact — never silently under the same name.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                SwitchRow("Mark as verified", "Shown next to the contact", contact.verified) {
                    scope.launch { c.engine.setVerified(peerId, it) }
                }
            } else {
                Text("Keys will be available once the contact is accepted.", style = MaterialTheme.typography.bodyMedium)
            }

            SectionTitle("CONVERSATION")
            SwitchRow("Mute notifications", null, contact.muted) { scope.launch { c.engine.setMuted(peerId, it) } }
            HorizontalDivider()
            Spacer(Modifier.height(16.dp))
            if (contact.state == ContactState.IN_REQUEST) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { c.engine.acceptRequest(peerId) } }) { Text("Accept request") }
                    OutlinedButton(onClick = { scope.launch { c.engine.declineRequest(peerId, false); nav.pop() } }) { Text("Decline") }
                }
                Spacer(Modifier.height(8.dp))
            }
            OutlinedButton(onClick = { confirmBlock = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (contact.state == ContactState.BLOCKED) "Unblock" else "Block")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmRemove = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Remove contact and messages", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (renaming && contact != null) {
        var name by remember { mutableStateOf(contact.customName ?: contact.name) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Rename contact") },
            text = {
                OutlinedTextField(
                    value = name, onValueChange = { if (it.length <= 40) name = it },
                    singleLine = true, label = { Text("Name (only on this device)") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { c.engine.renameContact(peerId, name) }
                    renaming = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }
    if (confirmRemove) {
        ConfirmDialog(
            "Remove contact?",
            "The contact and every message with them are deleted from this device. Unsent messages are discarded.",
            "Remove",
            onConfirm = { scope.launch { c.engine.removeContact(peerId); nav.popToHome() } },
            onDismiss = { confirmRemove = false },
        )
    }
    if (confirmBlock && contact != null) {
        val blocked = contact.state == ContactState.BLOCKED
        ConfirmDialog(
            if (blocked) "Unblock contact?" else "Block contact?",
            if (blocked) "They will be able to connect and message you again."
            else "Their connections and messages are rejected and unsent messages to them fail.",
            if (blocked) "Unblock" else "Block",
            onConfirm = { scope.launch { c.engine.setBlocked(peerId, !blocked) } },
            onDismiss = { confirmBlock = false },
        )
    }
}
