package creator.peer.tool.storage

import creator.peer.tool.core.B64
import creator.peer.tool.crypto.LocalCrypto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class RoutePref { AUTO, INTERNET_ONLY, NEARBY_ONLY }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class Settings(
    val displayName: String = "",
    val handle: String = "",
    val onboardingDone: Boolean = false,
    // Internet transport
    val internetEnabled: Boolean = true,
    val sigHost: String = "0.peerjs.com",
    val sigPort: Int = 443,
    val sigPath: String = "/",
    val sigKey: String = "peerjs",
    val sigSecure: Boolean = true,
    val stunUrl: String = "stun:stun.l.google.com:19302",
    val turnUrl: String = "",
    val turnUser: String = "",
    val turnCred: String = "",
    // Nearby transport
    val nearbyEnabled: Boolean = false,
    val routePref: RoutePref = RoutePref.AUTO,
    // Privacy
    val discoverable: Boolean = true,
    val readReceipts: Boolean = false,
    // Notifications
    val notifications: Boolean = true,
    val notifPreview: Boolean = false,
    // Storage
    val retentionDays: Int = 0,
    val expiryHours: Int = 168,
    // Background
    val keepReachable: Boolean = false,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    // Files
    val maxFileMb: Int = 25,
    val autoDownloadImages: Boolean = false,
    // Device security
    val appLock: Boolean = false,
    val blockScreenshots: Boolean = false,
    // Calls
    val allowCalls: Boolean = true,
    val callHideIp: Boolean = false,
) {
    /** Fields that require transports to be restarted when changed. */
    fun transportKey(): List<Any> = listOf(
        internetEnabled, sigHost, sigPort, sigPath, sigKey, sigSecure, stunUrl, turnUrl, turnUser, turnCred,
        nearbyEnabled, discoverable
    )
}

class SettingsHolder(private val store: Store, private val local: LocalCrypto) {
    private val _flow = MutableStateFlow(Settings())
    val flow: StateFlow<Settings> = _flow
    val current: Settings get() = _flow.value

    fun load() {
        val m = store.allSettings()
        fun s(k: String, d: String) = m[k] ?: d
        fun b(k: String, d: Boolean) = m[k]?.let { it == "1" } ?: d
        fun i(k: String, d: Int) = m[k]?.toIntOrNull() ?: d
        val d = Settings()
        val cred = m["turnCred"]?.let {
            try {
                String(local.open(B64.dec(it), "turnCred".toByteArray()), Charsets.UTF_8)
            } catch (e: Exception) {
                ""
            }
        } ?: ""
        _flow.value = Settings(
            displayName = s("displayName", d.displayName),
            handle = s("handle", d.handle),
            onboardingDone = b("onboardingDone", d.onboardingDone),
            internetEnabled = b("internetEnabled", d.internetEnabled),
            sigHost = s("sigHost", d.sigHost),
            sigPort = i("sigPort", d.sigPort),
            sigPath = s("sigPath", d.sigPath),
            sigKey = s("sigKey", d.sigKey),
            sigSecure = b("sigSecure", d.sigSecure),
            stunUrl = s("stunUrl", d.stunUrl),
            turnUrl = s("turnUrl", d.turnUrl),
            turnUser = s("turnUser", d.turnUser),
            turnCred = cred,
            nearbyEnabled = b("nearbyEnabled", d.nearbyEnabled),
            routePref = runCatching { RoutePref.valueOf(s("routePref", "AUTO")) }.getOrDefault(RoutePref.AUTO),
            discoverable = b("discoverable", d.discoverable),
            readReceipts = b("readReceipts", d.readReceipts),
            notifications = b("notifications", d.notifications),
            notifPreview = b("notifPreview", d.notifPreview),
            retentionDays = i("retentionDays", d.retentionDays),
            expiryHours = i("expiryHours", d.expiryHours),
            keepReachable = b("keepReachable", d.keepReachable),
            theme = runCatching { ThemeMode.valueOf(s("theme", "SYSTEM")) }.getOrDefault(ThemeMode.SYSTEM),
            maxFileMb = i("maxFileMb", d.maxFileMb),
            autoDownloadImages = b("autoDownloadImages", d.autoDownloadImages),
            appLock = b("appLock", d.appLock),
            blockScreenshots = b("blockScreenshots", d.blockScreenshots),
            allowCalls = b("allowCalls", d.allowCalls),
            callHideIp = b("callHideIp", d.callHideIp),
        )
    }

    fun update(block: (Settings) -> Settings) {
        val next = block(_flow.value)
        _flow.value = next
        fun b(v: Boolean) = if (v) "1" else "0"
        store.putSettings(
            mapOf(
                "displayName" to next.displayName,
                "handle" to next.handle,
                "onboardingDone" to b(next.onboardingDone),
                "internetEnabled" to b(next.internetEnabled),
                "sigHost" to next.sigHost,
                "sigPort" to next.sigPort.toString(),
                "sigPath" to next.sigPath,
                "sigKey" to next.sigKey,
                "sigSecure" to b(next.sigSecure),
                "stunUrl" to next.stunUrl,
                "turnUrl" to next.turnUrl,
                "turnUser" to next.turnUser,
                "turnCred" to B64.enc(local.seal(next.turnCred.toByteArray(Charsets.UTF_8), "turnCred".toByteArray())),
                "nearbyEnabled" to b(next.nearbyEnabled),
                "routePref" to next.routePref.name,
                "discoverable" to b(next.discoverable),
                "readReceipts" to b(next.readReceipts),
                "notifications" to b(next.notifications),
                "notifPreview" to b(next.notifPreview),
                "retentionDays" to next.retentionDays.toString(),
                "expiryHours" to next.expiryHours.toString(),
                "keepReachable" to b(next.keepReachable),
                "theme" to next.theme.name,
                "maxFileMb" to next.maxFileMb.toString(),
                "autoDownloadImages" to b(next.autoDownloadImages),
                "appLock" to b(next.appLock),
                "blockScreenshots" to b(next.blockScreenshots),
                "allowCalls" to b(next.allowCalls),
                "callHideIp" to b(next.callHideIp),
            )
        )
    }
}
