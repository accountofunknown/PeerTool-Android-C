@file:OptIn(ExperimentalMaterial3Api::class)

package creator.peer.tool.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.compose.material.icons.filled.Call
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.plus
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.messaging.ConnState
import creator.peer.tool.protocol.Limits
import creator.peer.tool.storage.ContactState
import creator.peer.tool.storage.Message
import creator.peer.tool.storage.MsgState
import creator.peer.tool.storage.Transfer
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(c: AppContainer, peerId: String, nav: Nav) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val contacts by rememberContacts(c)
    val contact = contacts.firstOrNull { it.peerId == peerId }
    val messages by rememberMessages(c, peerId)
    val states by c.engine.peerStates.collectAsStateWithLifecycle()
    val conn = states[peerId]

    var text by rememberSaveable { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<Message?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var pinnedOnly by rememberSaveable { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmExport by remember { mutableStateOf(false) }
    var pendingCallVideo by remember { mutableStateOf<Boolean?>(null) }
    fun has(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    val callPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        val video = pendingCallVideo
        pendingCallVideo = null
        if (video != null) {
            if (has(Manifest.permission.RECORD_AUDIO)) {
                c.engine.calls.start(peerId, video && has(Manifest.permission.CAMERA))
            } else {
                scope.launch { snack.showSnackbar("Allow the microphone to make calls") }
            }
        }
    }
    fun startCall(video: Boolean) {
        val needed = ArrayList<String>()
        if (!has(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
        if (video && !has(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
        if (needed.isEmpty()) {
            c.engine.calls.start(peerId, video)
        } else {
            pendingCallVideo = video
            callPerms.launch(needed.toTypedArray())
        }
    }
    val transfers by rememberTransfers(c, peerId)
    val trById = remember(transfers) { transfers.associateBy { it.id } }
    val progress by c.engine.transferProgress.collectAsStateWithLifecycle()
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                scope.launch { snack.showSnackbar("Preparing file…") }
                val r = c.engine.sendFile(peerId, uri)
                snack.currentSnackbarData?.dismiss()
                r.onFailure { snack.showSnackbar(it.message ?: "Could not send the file") }
            }
        }
    }

    DisposableEffect(peerId) {
        c.engine.activeChat.value = peerId
        onDispose { if (c.engine.activeChat.value == peerId) c.engine.activeChat.value = null }
    }
    LaunchedEffect(peerId, messages.size) { c.engine.markRead(peerId) }

    val shown = remember(messages, query, pinnedOnly, searching) {
        messages.filter { m ->
            (!pinnedOnly || m.pinned) && (!searching || query.isBlank() || m.body.contains(query, ignoreCase = true))
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(shown.size) { if (shown.isNotEmpty()) listState.animateScrollToItem(shown.lastIndex) }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { nav.push(Route.ContactDetail(peerId)) },
                    ) {
                        Avatar(contact?.displayName ?: "?", 36.dp, peerId)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(contact?.displayName ?: "Unknown", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            ConnBadge(conn)
                        }
                    }
                },
                actions = {
                    if (contact?.state == ContactState.ACCEPTED) {
                        IconButton(onClick = { startCall(false) }) { Icon(Icons.Filled.Call, "Voice call") }
                        IconButton(onClick = { startCall(true) }) { Text("\uD83D\uDCF9", modifier = Modifier.semantics { contentDescription = "Video call" }) }
                    }
                    if (conn?.state != ConnState.CONNECTED) {
                        IconButton(onClick = {
                            c.engine.connectNow(peerId)
                            scope.launch { snack.showSnackbar("Trying to connect…") }
                        }) { Icon(Icons.Filled.Refresh, "Connect now") }
                    }
                    IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                        Icon(Icons.Filled.Search, "Search in chat")
                    }
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(if (pinnedOnly) "Show all messages" else "Show pinned only") },
                            onClick = { pinnedOnly = !pinnedOnly; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("Contact & security") },
                            onClick = { menuOpen = false; nav.push(Route.ContactDetail(peerId)) },
                        )
                        DropdownMenuItem(
                            text = { Text("Export chat as text") },
                            onClick = { menuOpen = false; confirmExport = true },
                        )
                        DropdownMenuItem(
                            text = { Text("Clear conversation") },
                            onClick = { menuOpen = false; confirmClear = true },
                        )
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Search in this chat") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
            if (contact?.state == ContactState.IN_REQUEST) {
                RequestBanner(
                    "${contact.displayName} wants to connect. Accept to exchange messages.",
                    onAccept = { scope.launch { c.engine.acceptRequest(peerId) } },
                    onDecline = { scope.launch { c.engine.declineRequest(peerId, false); nav.pop() } },
                )
            } else if (contact?.state == ContactState.OUT_PENDING) {
                InfoBanner("Waiting for ${contact.displayName} to accept. Both of you need the app open once to complete this.")
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
                if (shown.isEmpty()) {
                    item {
                        EmptyState(
                            if (messages.isEmpty()) "No messages yet" else "Nothing to show",
                            if (messages.isEmpty()) "Say hello. Messages are end-to-end encrypted." else "Try a different search.",
                        )
                    }
                }
                items(shown, key = { it.id }) { m ->
                    val tr = trById[m.id]
                    MessageBubble(
                        m = m,
                        attachment = if (tr != null) ({
                            AttachmentCard(c, tr, progress[tr.id]) { msg -> scope.launch { snack.showSnackbar(msg) } }
                        }) else null,
                        onReact = { e -> scope.launch { c.engine.react(m.id, e) } },
                        replied = m.replyTo?.let { id -> messages.firstOrNull { it.id == id } },
                        onReply = { replyTo = m },
                        onCopy = { copyToClipboard(ctx, "message", m.body) },
                        onPin = { scope.launch(Dispatchers.IO) { c.store.setPinned(m.id, !m.pinned) } },
                        onDelete = { everyone -> scope.launch { c.engine.deleteMessage(m.id, everyone) } },
                        onResend = {
                            scope.launch {
                                c.engine.resend(m.id).onFailure { snack.showSnackbar(it.message ?: "Could not resend") }
                            }
                        },
                    )
                }
            }
            val canSend = contact?.state == ContactState.ACCEPTED
            Column(Modifier.imePadding().navigationBarsPadding()) {
                replyTo?.let { r ->
                    Row(
                        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Replying: ${r.body}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { replyTo = null }) { Icon(Icons.Filled.Close, "Cancel reply") }
                    }
                }
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Bottom) {
                    IconButton(enabled = canSend, onClick = { pickFile.launch("*/*") }) {
                        Icon(Icons.Filled.Add, "Attach a file")
                    }
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        enabled = canSend,
                        placeholder = { Text(if (canSend) "Message" else "Not connected as contacts yet") },
                        maxLines = 5,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = canSend && text.isNotBlank(),
                        onClick = {
                            val body = text
                            val re = replyTo?.id
                            text = ""
                            replyTo = null
                            scope.launch {
                                c.engine.sendText(peerId, body, re).onFailure {
                                    text = body
                                    snack.showSnackbar(it.message ?: "Could not send")
                                }
                            }
                        },
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Send message", tint = MaterialTheme.colorScheme.primary) }
                }
            }
        }
    }
    if (confirmExport) {
        ConfirmDialog(
            "Export this chat?",
            "This creates a plain, unencrypted text copy of the conversation (file names only, no attachments) that you can send to another app. It is no longer protected by PeerTool. Share it only with apps you trust.",
            "Export",
            onConfirm = {
                scope.launch {
                    val name = contact?.displayName ?: "Contact"
                    val text = withContext(Dispatchers.IO) {
                        c.store.messagesFor(peerId, 5000).joinToString("\n") {
                            "[" + formatFull(it.createdAt) + "] " + (if (it.outgoing) "Me" else name) + ": " + it.body
                        }.take(200_000)
                    }
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(i, "Export chat"))
                }
            },
            onDismiss = { confirmExport = false },
        )
    }
    if (confirmClear) {
        ConfirmDialog(
            "Clear conversation?",
            "All messages with this contact are deleted from this device, including unsent ones. The other person keeps their copy.",
            "Clear",
            onConfirm = { scope.launch { c.engine.clearConversation(peerId) } },
            onDismiss = { confirmClear = false },
        )
    }
}

@Composable
private fun RequestBanner(text: String, onAccept: () -> Unit, onDecline: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(text, style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAccept) { Text("Accept") }
                OutlinedButton(onClick = onDecline) { Text("Decline") }
            }
        }
    }
}

@Composable
private fun InfoBanner(text: String) {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
    }
}

@Composable
private fun MessageBubble(
    m: Message,
    attachment: (@Composable () -> Unit)?,
    onReact: (String?) -> Unit,
    replied: Message?,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onPin: () -> Unit,
    onDelete: (everyone: Boolean) -> Unit,
    onResend: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val mine = m.outgoing
    val bg = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box {
            Column(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bg)
                    .pointerInput(m.id) { detectTapGestures(onLongPress = { menu = true }) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                if (replied != null) {
                    Text(
                        replied.body, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                            .padding(6.dp),
                    )
                }
                if (attachment != null) attachment() else Text(m.body, style = MaterialTheme.typography.bodyLarge)
                if (m.myReaction != null || m.theirReaction != null) {
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        m.theirReaction?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                        m.myReaction?.let { Text("$it \u00B7 you", style = MaterialTheme.typography.labelSmall) }
                    }
                }
                Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (m.pinned) Text("📌 ", style = MaterialTheme.typography.labelSmall)
                    Text(
                        formatTime(m.createdAt) + if (mine) "  " + statusText(m) else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (m.state == MsgState.FAILED || m.state == MsgState.EXPIRED) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                Row(Modifier.padding(horizontal = 8.dp)) {
                    for (e in listOf("\uD83D\uDC4D", "\u2764\uFE0F", "\uD83D\uDE02", "\uD83D\uDE2E", "\uD83D\uDE22", "\uD83D\uDE4F")) {
                        TextButton(onClick = { menu = false; onReact(e) }) { Text(e) }
                    }
                }
                if (m.myReaction != null) {
                    DropdownMenuItem(text = { Text("Remove my reaction") }, onClick = { menu = false; onReact(null) })
                }
                DropdownMenuItem(text = { Text("Reply") }, onClick = { menu = false; onReply() })
                DropdownMenuItem(text = { Text("Copy") }, onClick = { menu = false; onCopy() })
                DropdownMenuItem(text = { Text(if (m.pinned) "Unpin" else "Pin") }, onClick = { menu = false; onPin() })
                if (mine && (m.state == MsgState.FAILED || m.state == MsgState.EXPIRED)) {
                    DropdownMenuItem(text = { Text("Resend") }, onClick = { menu = false; onResend() })
                }
                if (mine && (m.state == MsgState.QUEUED || m.state == MsgState.SENDING)) {
                    DropdownMenuItem(text = { Text("Cancel sending") }, onClick = { menu = false; onDelete(false) })
                } else {
                    DropdownMenuItem(text = { Text("Delete on this device") }, onClick = { menu = false; onDelete(false) })
                }
                if (mine && m.state == MsgState.DELIVERED) {
                    DropdownMenuItem(text = { Text("Delete for everyone (best effort)") }, onClick = { menu = false; onDelete(true) })
                }
            }
        }
    }
}

private fun statusText(m: Message): String = when (m.state) {
    MsgState.QUEUED -> "⏳ Queued"
    MsgState.SENDING -> "↗ Sent, awaiting delivery"
    MsgState.DELIVERED -> if (m.readByPeerAt != null) "✓✓ Read" else "✓ Delivered"
    MsgState.FAILED -> "⚠ Failed"
    MsgState.EXPIRED -> "⚠ Expired"
    MsgState.RECEIVED -> ""
}
