@file:OptIn(ExperimentalMaterial3Api::class)

package creator.peer.tool.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.storage.Contact
import creator.peer.tool.storage.ContactState
import creator.peer.tool.storage.MsgState
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(c: AppContainer, nav: Nav) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val contacts by rememberContacts(c)
    val requests = contacts.count { it.state == ContactState.IN_REQUEST }
    val title = when (tab) {
        0 -> "Chats"
        1 -> "Contacts"
        else -> "Settings"
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text(title) }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Email, contentDescription = null) }, label = { Text("Chats") },
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = {
                        Box {
                            Icon(Icons.Filled.Person, contentDescription = null)
                            if (requests > 0) Badge(Modifier.align(Alignment.TopEnd)) { Text("$requests") }
                        }
                    },
                    label = { Text("Contacts") },
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) }, label = { Text("Settings") },
                )
            }
        },
        floatingActionButton = {
            if (tab != 2) {
                FloatingActionButton(onClick = { nav.push(Route.AddContact) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add contact")
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatsTab(c, nav, contacts)
                1 -> ContactsTab(c, nav, contacts)
                else -> SettingsRoot(c, nav)
            }
        }
    }
}

@Composable
private fun ChatsTab(c: AppContainer, nav: Nav, contacts: List<Contact>) {
    val convs by rememberConversations(c)
    val states by c.engine.peerStates.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    val byId = contacts.associateBy { it.peerId }

    Column(Modifier.fillMaxSize()) {
        if (searching) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search all messages") },
                trailingIcon = {
                    IconButton(onClick = { query = ""; searching = false }) { Icon(Icons.Filled.Close, "Close search") }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Search messages") }
            }
        }
        if (searching && query.isNotBlank()) {
            val results by remember(query) { c.store.observe { c.store.search(query) } }
                .collectAsStateWithLifecycle(initialValue = emptyList())
            if (results.isEmpty()) {
                EmptyState("No matches", "Nothing in your stored messages matches “$query”.")
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(results, key = { it.id }) { m ->
                        val ct = byId[m.peerId]
                        ListItem(
                            leadingContent = { Avatar(ct?.displayName ?: "?", 40.dp, m.peerId) },
                            headlineContent = { Text(ct?.displayName ?: "Unknown") },
                            supportingContent = { Text(m.body, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { Text(formatTime(m.createdAt), style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.clickable { nav.push(Route.Chat(m.peerId)) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        } else if (convs.isEmpty()) {
            EmptyState(
                "No conversations yet",
                "Add a contact by scanning their QR code or entering their ID. Once they accept, you can start chatting.",
                action = { Button(onClick = { nav.push(Route.AddContact) }) { Text("Add a contact") } },
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                items(convs, key = { it.peerId }) { cv ->
                    val ct = byId[cv.peerId]
                    val name = ct?.displayName ?: "Unknown"
                    ListItem(
                        leadingContent = { Avatar(name, 48.dp, cv.peerId) },
                        headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = {
                            val prefix = if (cv.lastOutgoing) {
                                when (cv.lastState) {
                                    MsgState.QUEUED, MsgState.SENDING -> "⏳ "
                                    MsgState.FAILED, MsgState.EXPIRED -> "⚠ "
                                    else -> "You: "
                                }
                            } else ""
                            Text(prefix + cv.lastBody, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                        trailingContent = {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(formatTime(cv.lastAt), style = MaterialTheme.typography.labelSmall)
                                if (cv.unread > 0) Badge { Text("${cv.unread}") } else StatusDot(states[cv.peerId])
                            }
                        },
                        modifier = Modifier.clickable { nav.push(Route.Chat(cv.peerId)) },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun ContactsTab(c: AppContainer, nav: Nav, contacts: List<Contact>) {
    val states by c.engine.peerStates.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val requests = contacts.filter { it.state == ContactState.IN_REQUEST }
    val waiting = contacts.filter { it.state == ContactState.OUT_PENDING }
    val accepted = contacts.filter { it.state == ContactState.ACCEPTED }

    if (contacts.none { it.state != ContactState.BLOCKED }) {
        EmptyState(
            "No contacts",
            "Share your QR code or ID so someone can add you, or scan theirs.",
            action = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { nav.push(Route.AddContact) }) { Text("Add") }
                    OutlinedButton(onClick = { nav.push(Route.MyIdentity) }) { Text("My code") }
                }
            },
        )
    } else LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
        if (requests.isNotEmpty()) {
            item { SectionTitle("REQUESTS") }
            items(requests, key = { "r" + it.peerId }) { ct ->
                ListItem(
                    leadingContent = { Avatar(ct.displayName, 44.dp, ct.peerId) },
                    headlineContent = { Text(ct.displayName) },
                    supportingContent = { Text("Wants to connect · not verified") },
                    trailingContent = {
                        Row {
                            TextButton(onClick = { scope.launch { c.engine.declineRequest(ct.peerId, false) } }) { Text("Decline") }
                            TextButton(onClick = { scope.launch { c.engine.acceptRequest(ct.peerId) } }) { Text("Accept") }
                        }
                    },
                    modifier = Modifier.clickable { nav.push(Route.ContactDetail(ct.peerId)) },
                )
            }
        }
        if (waiting.isNotEmpty()) {
            item { SectionTitle("WAITING FOR ACCEPTANCE") }
            items(waiting, key = { "w" + it.peerId }) { ct ->
                ListItem(
                    leadingContent = { Avatar(ct.displayName, 44.dp, ct.peerId) },
                    headlineContent = { Text(ct.displayName) },
                    supportingContent = { ConnBadge(states[ct.peerId]) },
                    trailingContent = {
                        TextButton(onClick = { c.engine.connectNow(ct.peerId) }) { Text("Retry") }
                    },
                    modifier = Modifier.clickable { nav.push(Route.ContactDetail(ct.peerId)) },
                )
            }
        }
        if (accepted.isNotEmpty()) {
            item { SectionTitle("CONTACTS") }
            items(accepted, key = { "a" + it.peerId }) { ct ->
                ListItem(
                    leadingContent = { Avatar(ct.displayName, 44.dp, ct.peerId) },
                    headlineContent = { Text(ct.displayName) },
                    supportingContent = {
                        Column {
                            if (!ct.handle.isNullOrEmpty()) Text("@" + ct.handle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            ConnBadge(states[ct.peerId])
                        }
                    },
                    trailingContent = { if (ct.verified) Text("Verified", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary) },
                    modifier = Modifier.clickable { nav.push(Route.Chat(ct.peerId)) },
                )
                HorizontalDivider()
            }
        }
    }
}
