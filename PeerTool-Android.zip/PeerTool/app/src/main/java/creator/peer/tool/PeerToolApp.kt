package creator.peer.tool

import android.app.Activity
import android.app.Application
import android.os.Bundle

class PeerToolApp : Application() {
    lateinit var container: AppContainer
        private set

    private var started = 0

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.boot()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                started++
                container.engine.appVisible.value = true
            }

            override fun onActivityStopped(activity: Activity) {
                started = (started - 1).coerceAtLeast(0)
                container.engine.appVisible.value = started > 0
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
