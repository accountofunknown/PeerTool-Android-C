package creator.peer.tool.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import creator.peer.tool.MainActivity
import creator.peer.tool.R
import creator.peer.tool.storage.Contact
import creator.peer.tool.storage.SettingsHolder
import creator.peer.tool.util.Perms

class Notifier(private val context: Context, private val settings: SettingsHolder) {

    fun ensureChannels() {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, context.getString(R.string.channel_messages), NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REQUESTS, context.getString(R.string.channel_requests), NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, context.getString(R.string.channel_service), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun openIntent(peerId: String?): PendingIntent {
        val i = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (peerId != null) i.putExtra(EXTRA_PEER_ID, peerId)
        return PendingIntent.getActivity(
            context, (peerId ?: "home").hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun newMessage(contact: Contact, body: String) {
        val s = settings.current
        if (!s.notifications || contact.muted || !Perms.notificationsGranted(context)) return
        val text = if (s.notifPreview) body.take(120) else "New message"
        val n = NotificationCompat.Builder(context, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_peertool)
            .setContentTitle(contact.displayName)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(openIntent(contact.peerId))
            .build()
        notify(contact.peerId.hashCode(), n)
    }

    fun newRequest(name: String, peerId: String) {
        val s = settings.current
        if (!s.notifications || !Perms.notificationsGranted(context)) return
        val n = NotificationCompat.Builder(context, CH_REQUESTS)
            .setSmallIcon(R.drawable.ic_stat_peertool)
            .setContentTitle("Contact request")
            .setContentText(if (s.notifPreview) "$name wants to connect" else "Someone wants to connect")
            .setAutoCancel(true)
            .setContentIntent(openIntent(null))
            .build()
        notify(("req" + peerId).hashCode(), n)
    }

    fun serviceNotification(): Notification =
        NotificationCompat.Builder(context, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_peertool)
            .setContentTitle("PeerTool is reachable")
            .setContentText("Listening for peers while the app is in the background")
            .setOngoing(true)
            .setContentIntent(openIntent(null))
            .build()

    fun cancelFor(peerId: String) {
        NotificationManagerCompat.from(context).cancel(peerId.hashCode())
    }

    private fun notify(id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    companion object {
        const val CH_MESSAGES = "messages"
        const val CH_REQUESTS = "requests"
        const val CH_SERVICE = "service"
        const val EXTRA_PEER_ID = "creator.peer.tool.PEER_ID"
        const val SERVICE_NOTIFICATION_ID = 7001
    }
}
