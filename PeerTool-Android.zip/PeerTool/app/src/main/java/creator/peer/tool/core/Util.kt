package creator.peer.tool.core

import java.security.SecureRandom
import java.util.Base64
import kotlin.math.min
import kotlin.random.Random

fun interface Clock {
    fun now(): Long
}

object SystemClockImpl : Clock {
    override fun now(): Long = System.currentTimeMillis()
}

object Hex {
    private val chars = "0123456789abcdef".toCharArray()

    fun encode(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xff
            out[i * 2] = chars[v ushr 4]
            out[i * 2 + 1] = chars[v and 0x0f]
        }
        return String(out)
    }
}

object B64 {
    fun enc(b: ByteArray): String = Base64.getEncoder().withoutPadding().encodeToString(b)
    fun dec(s: String): ByteArray = Base64.getDecoder().decode(s)
    fun encUrl(b: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(b)
    fun decUrl(s: String): ByteArray = Base64.getUrlDecoder().decode(s)
}

object Base32 {
    private const val ALPHABET = "abcdefghijklmnopqrstuvwxyz234567"

    fun encode(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xff)
            bits += 8
            while (bits >= 5) {
                sb.append(ALPHABET[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        if (bits > 0) {
            sb.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        }
        return sb.toString()
    }
}

object Ids {
    private val rng = SecureRandom()

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { rng.nextBytes(it) }

    fun newMessageId(): String = Hex.encode(randomBytes(16))
}

/** Bounded exponential backoff with jitter. */
class Backoff(
    private val baseMs: Long = 5_000,
    private val capMs: Long = 15 * 60_000,
    private val jitter: Double = 0.2,
) {
    fun delayMs(attempt: Int, rnd: Random = Random.Default): Long {
        val exp = min(attempt.coerceAtLeast(0), 20)
        val raw = min(capMs, baseMs * (1L shl exp))
        val j = (raw * jitter).toLong()
        if (j <= 0L) return raw
        return raw - j + rnd.nextLong(0, 2 * j + 1)
    }

    fun maxDelayMs(): Long = capMs + (capMs * jitter).toLong()
}

object TextSafety {
    /** Removes control and bidi-override characters, collapses whitespace, bounds the length. */
    fun sanitizeName(raw: String, max: Int = 40): String {
        val sb = StringBuilder()
        for (ch in raw) {
            if (Character.isISOControl(ch)) continue
            if (ch in '\u202A'..'\u202E' || ch in '\u2066'..'\u2069' || ch == '\u200E' || ch == '\u200F') continue
            sb.append(ch)
        }
        val s = sb.toString().trim().replace(Regex("\\s+"), " ")
        return if (s.length > max) s.substring(0, max).trim() else s
    }

    fun utf8Size(s: String): Int = s.toByteArray(Charsets.UTF_8).size
}
