@file:OptIn(ExperimentalMaterial3Api::class)

package creator.peer.tool.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.BuildConfig
import creator.peer.tool.service.ReachabilityService
import creator.peer.tool.storage.ContactState
import creator.peer.tool.storage.MsgState
import creator.peer.tool.storage.RoutePref
import creator.peer.tool.storage.Settings
import creator.peer.tool.storage.ThemeMode
import creator.peer.tool.transport.TransportKind
import creator.peer.tool.transport.TransportStatus
import creator.peer.tool.util.Perms
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun pageTitle(p: SettingsPage) = when (p) {
    SettingsPage.MAIN -> "Settings"
    SettingsPage.PROFILE -> "Profile"
    SettingsPage.PRIVACY -> "Privacy"
    SettingsPage.NETWORK -> "Network & routing"
    SettingsPage.NOTIFICATIONS -> "Notifications"
    SettingsPage.STORAGE -> "Storage & retention"
    SettingsPage.APPEARANCE -> "Appearance"
    SettingsPage.OUTBOX -> "Pending & failed"
    SettingsPage.DIAGNOSTICS -> "Connection diagnostics"
    SettingsPage.ABOUT -> "About & security"
}

/** Content of the Settings tab. */
@Composable
fun SettingsRoot(c: AppContainer, nav: Nav) {
    val settings by c.settings.flow.collectAsStateWithLifecycle()
    val pendingCount by remember(c) { c.store.observe { c.store.outboxCount() } }.collectAsStateWithLifecycle(initialValue = 0)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ListItem(
            leadingContent = { Avatar(settings.displayName.ifBlank { "?" }, 48.dp, "me") },
            headlineContent = { Text(settings.displayName) },
            supportingContent = { Text("Show my QR code") },
            modifier = Modifier.clickable { nav.push(Route.MyIdentity) },
        )
        HorizontalDivider()
        SettingsLink("Profile", "Display name") { nav.push(Route.Settings(SettingsPage.PROFILE)) }
        SettingsLink("Privacy", "Discoverability, read receipts, blocked contacts") { nav.push(Route.Settings(SettingsPage.PRIVACY)) }
        SettingsLink("Network & routing", "Internet, nearby, signaling, TURN") { nav.push(Route.Settings(SettingsPage.NETWORK)) }
        SettingsLink("Notifications", null) { nav.push(Route.Settings(SettingsPage.NOTIFICATIONS)) }
        SettingsLink("Storage & retention", "Auto-delete, message expiry") { nav.push(Route.Settings(SettingsPage.STORAGE)) }
        SettingsLink("Appearance", "Light, dark, system") { nav.push(Route.Settings(SettingsPage.APPEARANCE)) }
        SettingsLink("Pending & failed messages", if (pendingCount > 0) "$pendingCount waiting to send" else "Nothing waiting") {
            nav.push(Route.Settings(SettingsPage.OUTBOX))
        }
        SettingsLink("Connection diagnostics", "Transports, links, log") { nav.push(Route.Settings(SettingsPage.DIAGNOSTICS)) }
        SettingsLink("About & security", "Version ${BuildConfig.VERSION_NAME}") { nav.push(Route.Settings(SettingsPage.ABOUT)) }
    }
}

@Composable
private fun SettingsLink(title: String, subtitle: String?, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = if (subtitle != null) ({ Text(subtitle) }) else null,
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
fun SettingsScreens(c: AppContainer, page: SettingsPage, nav: Nav) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pageTitle(page)) },
                navigationIcon = { IconButton(onClick = { nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            when (page) {
                SettingsPage.MAIN, SettingsPage.PROFILE -> ProfilePage(c)
                SettingsPage.PRIVACY -> PrivacyPage(c)
                SettingsPage.NETWORK -> NetworkPage(c)
                SettingsPage.NOTIFICATIONS -> NotificationsPage(c)
                SettingsPage.STORAGE -> StoragePage(c, nav)
                SettingsPage.APPEARANCE -> AppearancePage(c)
                SettingsPage.OUTBOX -> OutboxPage(c)
                SettingsPage.DIAGNOSTICS -> DiagnosticsPage(c)
                SettingsPage.ABOUT -> AboutPage()
            }
        }
    }
}

// ------------------------------------------------------------------ pages

@Composable
private fun ProfilePage(c: AppContainer) {
    val s by c.settings.flow.collectAsStateWithLifecycle()
    var name by remember(s.displayName) { mutableStateOf(s.displayName) }
    val scope = rememberCoroutineScope()
    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = name, onValueChange = { if (it.length <= 40) name = it },
            label = { Text("Display name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Your name is sent to contacts when you connect. Your Peer ID and keys do not change when you rename.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = name.isNotBlank() && name != s.displayName,
            onClick = {
                scope.launch(Dispatchers.IO) {
                    c.settings.update { it.copy(displayName = creator.peer.tool.core.TextSafety.sanitizeName(name)) }
                }
            },
        ) { Text("Save") }
    }
}

@Composable
private fun PrivacyPage(c: AppContainer) {
    val s by c.settings.flow.collectAsStateWithLifecycle()
    val contacts by rememberContacts(c)
    val scope = rememberCoroutineScope()
    val io = Dispatchers.IO
    SwitchRow(
        "Discoverable", "Advertise on nearby devices and accept contact requests from people you haven't added. Turn off to only talk to existing contacts.",
        s.discoverable,
    ) { v -> scope.launch(io) { c.settings.update { it.copy(discoverable = v) } } }
    SwitchRow(
        "Send read receipts", "Let contacts see when you've read their messages. Delivery receipts are always sent.",
        s.readReceipts,
    ) { v -> scope.launch(io) { c.settings.update { it.copy(readReceipts = v) } } }
    SectionTitle("BLOCKED CONTACTS")
    val blocked = contacts.filter { it.state == ContactState.BLOCKED }
    if (blocked.isEmpty()) {
        Text("No blocked contacts.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium)
    }
    for (b in blocked) {
        ListItem(
            leadingContent = { Avatar(b.displayName, 40.dp, b.peerId) },
            headlineContent = { Text(b.displayName) },
            trailingContent = { TextButton(onClick = { scope.launch { c.engine.setBlocked(b.peerId, false) } }) { Text("Unblock") } },
        )
    }
    SectionTitle("WHAT END-TO-END ENCRYPTION DOES NOT HIDE")
    Text(
        "Message text is encrypted so only you and your contact can read it. The signaling server and network can still see that your device is online, " +
            "IP addresses (unless you use a TURN relay you trust), timing and approximate message sizes. PeerTool does not provide anonymity.",
        Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium,
    )
}

@Composable
private fun NetworkPage(c: AppContainer) {
    val ctx = LocalContext.current
    val s by c.settings.flow.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val io = Dispatchers.IO
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { c.engine.kick() }

    SectionTitle("INTERNET")
    SwitchRow("Internet transport (WebRTC)", "Direct encrypted peer-to-peer connections. Needs a signaling server to set up each connection.", s.internetEnabled) { v ->
        scope.launch(io) { c.settings.update { it.copy(internetEnabled = v) } }
    }
    var host by remember(s.sigHost) { mutableStateOf(s.sigHost) }
    var port by remember(s.sigPort) { mutableStateOf(s.sigPort.toString()) }
    var path by remember(s.sigPath) { mutableStateOf(s.sigPath) }
    var key by remember(s.sigKey) { mutableStateOf(s.sigKey) }
    var secure by remember(s.sigSecure) { mutableStateOf(s.sigSecure) }
    var stun by remember(s.stunUrl) { mutableStateOf(s.stunUrl) }
    var turn by remember(s.turnUrl) { mutableStateOf(s.turnUrl) }
    var turnUser by remember(s.turnUser) { mutableStateOf(s.turnUser) }
    var turnCred by remember(s.turnCred) { mutableStateOf(s.turnCred) }
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Signaling server (PeerJS protocol). Only connection set-up data passes through it, never message content. The default is the public PeerJS cloud; you can run your own.",
            style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedTextField(host, { host = it }, label = { Text("Host") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                port, { port = it.filter { ch -> ch.isDigit() }.take(5) }, label = { Text("Port") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
            )
            OutlinedTextField(path, { path = it }, label = { Text("Path") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(key, { key = it }, label = { Text("Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        SwitchRow("Secure (wss)", null, secure) { secure = it }
        Text(
            "STUN helps peers discover their public address. TURN relays traffic when a direct connection is impossible (still end-to-end encrypted). TURN is optional and needs your own server or provider.",
            style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedTextField(stun, { stun = it }, label = { Text("STUN URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(turn, { turn = it }, label = { Text("TURN URL (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(turnUser, { turnUser = it }, label = { Text("TURN username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            turnCred, { turnCred = it }, label = { Text("TURN credential") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = {
            scope.launch(io) {
                c.settings.update {
                    it.copy(
                        sigHost = host.trim(), sigPort = port.toIntOrNull() ?: 443, sigPath = path.trim().ifEmpty { "/" },
                        sigKey = key.trim().ifEmpty { "peerjs" }, sigSecure = secure, stunUrl = stun.trim(),
                        turnUrl = turn.trim(), turnUser = turnUser, turnCred = turnCred,
                    )
                }
            }
        }) { Text("Apply and reconnect") }
    }

    SectionTitle("NEARBY (OFFLINE)")
    SwitchRow(
        "Nearby transport", "Bluetooth + Wi-Fi via Google Nearby Connections. Works without internet, needs Google Play services and uses more battery while on.",
        s.nearbyEnabled,
    ) { v ->
        scope.launch(io) { c.settings.update { it.copy(nearbyEnabled = v) } }
        if (v) {
            val missing = Perms.missing(ctx, Perms.nearbyRequired())
            if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
        }
    }

    SectionTitle("ROUTING")
    for ((pref, label, sub) in listOf(
        Triple(RoutePref.AUTO, "Automatic", "Prefer nearby when available, otherwise internet"),
        Triple(RoutePref.INTERNET_ONLY, "Internet only", "Never use Bluetooth/Wi-Fi nearby links"),
        Triple(RoutePref.NEARBY_ONLY, "Nearby only", "Never use the internet or signaling server"),
    )) {
        ListItem(
            headlineContent = { Text(label) },
            supportingContent = { Text(sub) },
            leadingContent = { RadioButton(selected = s.routePref == pref, onClick = null) },
            modifier = Modifier.clickable { scope.launch(io) { c.settings.update { it.copy(routePref = pref) } } },
        )
    }
    Text(
        "Messages are never downgraded to unencrypted routes and never sent through a service that is not part of the route you chose.",
        Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall,
    )

    SectionTitle("BACKGROUND")
    SwitchRow(
        "Stay reachable", "Runs a visible foreground notification so Android is less likely to stop the app while it waits for peers. Uses battery. Not a delivery guarantee.",
        s.keepReachable,
    ) { v ->
        scope.launch(io) { c.settings.update { it.copy(keepReachable = v) } }
        ReachabilityService.apply(ctx, v)
    }
    Spacer(Modifier.height(24.dp))
}

@Composable
private fun NotificationsPage(c: AppContainer) {
    val ctx = LocalContext.current
    val s by c.settings.flow.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val io = Dispatchers.IO
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    if (!Perms.notificationsGranted(ctx)) {
        Column(Modifier.padding(16.dp)) {
            Text("Android notification permission is off.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { launcher.launch(android.Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications") }
        }
    }
    SwitchRow("Message notifications", null, s.notifications) { v -> scope.launch(io) { c.settings.update { it.copy(notifications = v) } } }
    SwitchRow(
        "Show message preview", "Off by default so message text never appears on the lock screen or in notification history.",
        s.notifPreview,
    ) { v -> scope.launch(io) { c.settings.update { it.copy(notifPreview = v) } } }
    ListItem(
        headlineContent = { Text("System notification settings") },
        supportingContent = { Text("Sounds, vibration and per-channel options") },
        modifier = Modifier.clickable {
            val i = Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName)
            ctx.startActivity(i)
        },
    )
    Text("Mute individual contacts from their contact page.", Modifier.padding(16.dp), style = MaterialTheme.typography.labelSmall)
}

@Composable
private fun StoragePage(c: AppContainer, nav: Nav) {
    val s by c.settings.flow.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val io = Dispatchers.IO
    val count by remember(c) { c.store.observe { c.store.messageCount() } }.collectAsStateWithLifecycle(initialValue = 0)
    var confirmWipeMessages by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    Text("$count messages stored (encrypted at rest with a hardware-backed key where available).", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
    SectionTitle("AUTO-DELETE OLD MESSAGES")
    for ((days, label) in listOf(0 to "Keep forever", 7 to "After 7 days", 30 to "After 30 days", 90 to "After 90 days", 365 to "After 1 year")) {
        ListItem(
            headlineContent = { Text(label) },
            leadingContent = { RadioButton(selected = s.retentionDays == days, onClick = null) },
            modifier = Modifier.clickable { scope.launch(io) { c.settings.update { it.copy(retentionDays = days) } } },
        )
    }
    SectionTitle("UNSENT MESSAGE EXPIRY")
    for ((h, label) in listOf(24 to "1 day", 72 to "3 days", 168 to "7 days (default)")) {
        ListItem(
            headlineContent = { Text(label) },
            supportingContent = if (h == 24) ({ Text("Queued messages that still aren't delivered by then are marked expired.") }) else null,
            leadingContent = { RadioButton(selected = s.expiryHours == h, onClick = null) },
            modifier = Modifier.clickable { scope.launch(io) { c.settings.update { it.copy(expiryHours = h) } } },
        )
    }
    SectionTitle("BACKUP & EXPORT")
    Text(
        "Cloud backup and device-to-device transfer are disabled for this app on purpose, so keys and messages never leave the device. " +
            "A new phone starts with a new identity. Message export is not implemented.",
        Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium,
    )
    SectionTitle("DANGER ZONE")
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { confirmWipeMessages = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete all messages") }
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Reset identity and delete everything", color = MaterialTheme.colorScheme.error)
        }
    }
    Spacer(Modifier.height(24.dp))
    if (confirmWipeMessages) {
        ConfirmDialog("Delete all messages?", "Every conversation is emptied on this device, including unsent messages.", "Delete",
            onConfirm = {
                scope.launch(io) {
                    for (ct in c.store.contacts()) c.store.clearConversation(ct.peerId)
                }
            }, onDismiss = { confirmWipeMessages = false })
    }
    if (confirmReset) {
        ConfirmDialog(
            "Reset everything?",
            "Your keys, contacts and messages are erased. People who know your old ID won't be able to reach you; you'll have a new identity.",
            "Erase",
            onConfirm = { scope.launch { c.resetEverything(); nav.popToHome() } },
            onDismiss = { confirmReset = false },
        )
    }
}

@Composable
private fun AppearancePage(c: AppContainer) {
    val s by c.settings.flow.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    for ((mode, label) in listOf(ThemeMode.SYSTEM to "Follow system", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark")) {
        ListItem(
            headlineContent = { Text(label) },
            leadingContent = { RadioButton(selected = s.theme == mode, onClick = null) },
            modifier = Modifier.clickable { scope.launch(Dispatchers.IO) { c.settings.update { it.copy(theme = mode) } } },
        )
    }
}

@Composable
private fun OutboxPage(c: AppContainer) {
    val scope = rememberCoroutineScope()
    val contacts by rememberContacts(c)
    val items by remember(c) {
        c.store.observe { c.store.messagesInStates(listOf(MsgState.QUEUED, MsgState.SENDING, MsgState.FAILED, MsgState.EXPIRED)) }
    }.collectAsStateWithLifecycle(initialValue = emptyList())
    val states by c.engine.peerStates.collectAsStateWithLifecycle()
    if (items.isEmpty()) {
        EmptyState("All caught up", "No messages are waiting to be delivered, and none have failed.")
    } else Column {
    Text(
        "“Queued” means saved on this phone. “Sent” means handed to a connection. Only “Delivered” means your contact's phone confirmed it stored the message.",
        Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium,
    )
    for (m in items) {
        val ct = contacts.firstOrNull { it.peerId == m.peerId }
        ListItem(
            headlineContent = { Text(ct?.displayName ?: "Unknown", maxLines = 1) },
            supportingContent = {
                Column {
                    Text(m.body, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${m.state.name.lowercase().replaceFirstChar { it.uppercase() }} · ${connLabel(states[m.peerId])}",
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            },
            trailingContent = {
                if (m.state == MsgState.FAILED || m.state == MsgState.EXPIRED) {
                    TextButton(onClick = { scope.launch { c.engine.resend(m.id) } }) { Text("Resend") }
                } else {
                    TextButton(onClick = { scope.launch { c.engine.deleteMessage(m.id, false) } }) { Text("Cancel") }
                }
            },
        )
        HorizontalDivider()
    }
    }
}

@Composable
private fun DiagnosticsPage(c: AppContainer) {
    val ctx = LocalContext.current
    val webrtc by c.webrtcInfo.collectAsStateWithLifecycle()
    val nearby by c.nearbyInfo.collectAsStateWithLifecycle()
    val links by c.engine.linkViews.collectAsStateWithLifecycle()
    val log by c.diag.lines.collectAsStateWithLifecycle()
    val s by c.settings.flow.collectAsStateWithLifecycle()

    SectionTitle("TRANSPORTS")
    TransportRow("Internet (WebRTC)", webrtc.status, webrtc.detail, s.internetEnabled)
    TransportRow("Nearby", nearby.status, nearby.detail, s.nearbyEnabled)
    SectionTitle("ACTIVE LINKS")
    if (links.isEmpty()) Text("No links.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyMedium)
    for (l in links) {
        val state = when {
            l.authed && l.missed > 0 -> "authenticated, unresponsive (${l.missed})"
            l.authed -> "authenticated"
            l.up -> "verifying identity"
            else -> "connecting"
        }
        ListItem(
            headlineContent = { Text((if (l.kind == TransportKind.NEARBY) "Nearby" else "Internet") + " · " + state) },
            supportingContent = {
                Text(
                    "peer " + (l.peerId ?: l.hint ?: "unknown").take(12) + "… · " + (l.ageMs / 1000) + "s",
                    fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall,
                )
            },
        )
    }
    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { c.engine.kick() }) { Text("Reconnect now") }
        OutlinedButton(onClick = { copyToClipboard(ctx, "diagnostics", log.joinToString("\n")) }) { Text("Copy log") }
    }
    SectionTitle("EVENT LOG (no message content)")
    Column(Modifier.padding(horizontal = 16.dp)) {
        for (line in log.takeLast(60).reversed()) {
            Text(line, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
        }
    }
    Spacer(Modifier.height(24.dp))
}

@Composable
private fun TransportRow(name: String, status: TransportStatus, detail: String, enabled: Boolean) {
    ListItem(
        headlineContent = { Text(name) },
        supportingContent = {
            Text(
                if (!enabled) "Turned off in settings"
                else when (status) {
                    TransportStatus.OFF -> "Not running"
                    TransportStatus.STARTING -> detail.ifBlank { "Starting…" }
                    TransportStatus.READY -> detail.ifBlank { "Ready" }
                    TransportStatus.ERROR -> detail.ifBlank { "Error" }
                }
            )
        },
    )
}

@Composable
private fun AboutPage() {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PeerTool ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleLarge)
        Text("Application ID ${BuildConfig.APPLICATION_ID} · ${if (BuildConfig.DEBUG) "debug build" else "release build"}", style = MaterialTheme.typography.bodyMedium)
        SectionTitle("HOW MESSAGES ARE PROTECTED")
        Text(
            "Each message is encrypted to the recipient's public key (Tink ECIES, P-256 + AES-GCM) and signed with your Ed25519 key. Message bodies on this phone are encrypted with a non-exportable Android Keystore key.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            "Not provided: forward secrecy or post-compromise security (there is no ratchet), multi-device support, attachments, anonymity, or protection against a compromised phone.",
            style = MaterialTheme.typography.bodyMedium,
        )
        SectionTitle("BACKGROUND LIMITS")
        Text(
            "Android may stop the app in the background (Doze, battery optimisation, force-stop). Messages wait in the outbox and are retried when both phones are online, but delivery needs the other person's app to be running. Force-stopped apps stay stopped until you open them again.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            "This is a debug build. A debug APK is not a production-signed release.",
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
