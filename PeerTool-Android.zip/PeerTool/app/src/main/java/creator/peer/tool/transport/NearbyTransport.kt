package creator.peer.tool.transport

import android.content.Context
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import creator.peer.tool.core.DiagLog
import creator.peer.tool.crypto.PeerCrypto
import creator.peer.tool.storage.Settings
import creator.peer.tool.util.Perms
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline transport built on Google Nearby Connections (Bluetooth + Wi-Fi). Requires Google Play services
 * and runtime permissions. The advertised endpoint name is only a routing hint; real identity is proven
 * by the challenge/response handshake performed above the transport.
 */
class NearbyTransport(
    private val context: Context,
    private val settings: () -> Settings,
    private val selfId: () -> String?,
    private val diag: DiagLog,
) : Transport {

    override val kind = TransportKind.NEARBY
    private val _info = MutableStateFlow(TransportInfo(TransportStatus.OFF))
    override val info: StateFlow<TransportInfo> = _info
    private val channel = Channel<TransportEvent>(Channel.UNLIMITED)
    override val events: ReceiveChannel<TransportEvent> = channel

    private val started = AtomicBoolean(false)
    private var client: ConnectionsClient? = null

    private val endpointNames = ConcurrentHashMap<String, String>()   // discovered endpointId -> advertised name
    private val connected = ConcurrentHashMap.newKeySet<String>()      // connected endpointIds
    private val requested = ConcurrentHashMap.newKeySet<String>()      // endpointIds with a pending request
    private val wanted = ConcurrentHashMap.newKeySet<String>()         // peer IDs we want to reach

    private fun linkId(endpointId: String) = "nearby:$endpointId"

    override fun start() {
        if (!started.compareAndSet(false, true)) return
        val missing = Perms.missing(context, Perms.nearbyRequired())
        if (missing.isNotEmpty()) {
            started.set(false)
            _info.value = TransportInfo(TransportStatus.ERROR, "Permissions needed for nearby devices")
            return
        }
        val availability = try {
            GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context)
        } catch (e: Throwable) {
            ConnectionResult.SERVICE_MISSING
        }
        if (availability != ConnectionResult.SUCCESS) {
            started.set(false)
            _info.value = TransportInfo(TransportStatus.ERROR, "Google Play services unavailable")
            return
        }
        val id = selfId()
        if (id == null) {
            started.set(false)
            _info.value = TransportInfo(TransportStatus.ERROR, "No identity yet")
            return
        }
        _info.value = TransportInfo(TransportStatus.STARTING, "Starting nearby discovery")
        val c = Nearby.getConnectionsClient(context.applicationContext)
        client = c
        val strategy = Strategy.P2P_CLUSTER
        c.startDiscovery(
            SERVICE_ID, discoveryCallback,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnSuccessListener {
            _info.value = TransportInfo(TransportStatus.READY, "Looking for nearby devices")
        }.addOnFailureListener { e ->
            fail("Discovery failed: ${e.javaClass.simpleName}")
        }
        if (settings().discoverable) {
            c.startAdvertising(
                id, SERVICE_ID, lifecycleCallback,
                AdvertisingOptions.Builder().setStrategy(strategy).build()
            ).addOnFailureListener { e ->
                diag.add("nearby: advertising failed ${e.javaClass.simpleName}")
            }
        }
    }

    private fun fail(msg: String) {
        diag.add("nearby: $msg")
        _info.value = TransportInfo(TransportStatus.ERROR, msg)
    }

    override fun stop() {
        if (!started.compareAndSet(true, false)) {
            _info.value = TransportInfo(TransportStatus.OFF)
            return
        }
        val c = client
        client = null
        try {
            c?.stopAdvertising()
            c?.stopDiscovery()
            c?.stopAllEndpoints()
        } catch (_: Throwable) {
        }
        for (e in connected.toList()) channel.trySend(TransportEvent.LinkDown(linkId(e), kind, "transport stopped"))
        for ((e, n) in endpointNames) channel.trySend(TransportEvent.Discovered(kind, e, n, false))
        connected.clear()
        requested.clear()
        endpointNames.clear()
        wanted.clear()
        _info.value = TransportInfo(TransportStatus.OFF)
    }

    override fun kick() {
        if (started.get() && _info.value.status == TransportStatus.ERROR) {
            stop()
            start()
        }
    }

    override fun connect(hint: String): Boolean {
        if (!started.get() || !PeerCrypto.isValidPeerId(hint)) return false
        wanted.add(hint)
        var any = false
        for ((endpointId, name) in endpointNames) {
            if (name == hint) {
                requestIfNeeded(endpointId)
                any = true
            }
        }
        return any
    }

    private fun requestIfNeeded(endpointId: String) {
        val c = client ?: return
        val me = selfId() ?: return
        if (connected.contains(endpointId) || !requested.add(endpointId)) return
        channel.trySend(TransportEvent.LinkConnecting(linkId(endpointId), kind, endpointNames[endpointId], false))
        c.requestConnection(me, endpointId, lifecycleCallback).addOnFailureListener { e ->
            requested.remove(endpointId)
            val code = (e as? com.google.android.gms.common.api.ApiException)?.statusCode
            if (code != ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT) {
                channel.trySend(TransportEvent.LinkDown(linkId(endpointId), kind, "request failed"))
            }
        }
    }

    override fun send(linkId: String, bytes: ByteArray): Boolean {
        val c = client ?: return false
        val endpointId = linkId.removePrefix("nearby:")
        if (!connected.contains(endpointId) || bytes.size > ConnectionsClient.MAX_BYTES_DATA_SIZE) return false
        return try {
            c.sendPayload(endpointId, Payload.fromBytes(bytes))
            true
        } catch (e: Throwable) {
            false
        }
    }

    override fun close(linkId: String) {
        val endpointId = linkId.removePrefix("nearby:")
        try {
            client?.disconnectFromEndpoint(endpointId)
        } catch (_: Throwable) {
        }
        if (connected.remove(endpointId)) {
            channel.trySend(TransportEvent.LinkDown(linkId, kind, "closed locally"))
        }
        requested.remove(endpointId)
    }

    // ------------------------------------------------------------------ callbacks

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val name = info.endpointName
            if (!PeerCrypto.isValidPeerId(name) || name == selfId()) return
            endpointNames[endpointId] = name
            channel.trySend(TransportEvent.Discovered(kind, endpointId, name, true))
            if (wanted.contains(name)) requestIfNeeded(endpointId)
        }

        override fun onEndpointLost(endpointId: String) {
            val name = endpointNames.remove(endpointId)
            channel.trySend(TransportEvent.Discovered(kind, endpointId, name, false))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            channel.trySend(TransportEvent.Data(linkId(endpointId), kind, bytes))
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // Authentication happens at the application layer (signed challenge), so accept the raw link.
            if (connected.size >= 8) {
                client?.rejectConnection(endpointId)
                return
            }
            val hint = endpointNames[endpointId] ?: info.endpointName
            channel.trySend(TransportEvent.LinkConnecting(linkId(endpointId), kind, hint, !requested.contains(endpointId)))
            client?.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            requested.remove(endpointId)
            if (result.status.isSuccess) {
                connected.add(endpointId)
                channel.trySend(TransportEvent.LinkUp(linkId(endpointId), kind, endpointNames[endpointId], false))
            } else {
                channel.trySend(TransportEvent.LinkDown(linkId(endpointId), kind, "connection refused (${result.status.statusCode})"))
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId)
            channel.trySend(TransportEvent.LinkDown(linkId(endpointId), kind, "disconnected"))
        }
    }

    companion object {
        private const val SERVICE_ID = "creator.peer.tool.nearby.v1"
    }
}
