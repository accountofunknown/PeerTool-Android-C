package creator.peer.tool.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** At-rest protection for data stored in the local database. */
interface LocalCrypto {
    fun seal(plain: ByteArray, aad: ByteArray): ByteArray
    fun open(blob: ByteArray, aad: ByteArray): ByteArray
}

/** AES-256-GCM with a non-exportable Android Keystore key. */
class KeystoreLocalCrypto(private val alias: String = "peertool_local_aead_v1") : LocalCrypto {
    private val secret: SecretKey by lazy { loadOrCreate() }

    private fun loadOrCreate(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    override fun seal(plain: ByteArray, aad: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secret)
        c.updateAAD(aad)
        val ct = c.doFinal(plain)
        val iv = c.iv
        return byteArrayOf(iv.size.toByte()) + iv + ct
    }

    override fun open(blob: ByteArray, aad: ByteArray): ByteArray {
        require(blob.size > 13) { "blob too short" }
        val n = blob[0].toInt() and 0xff
        require(n in 12..16 && blob.size > 1 + n) { "bad blob" }
        val iv = blob.copyOfRange(1, 1 + n)
        val ct = blob.copyOfRange(1 + n, blob.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secret, GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return c.doFinal(ct)
    }
}
