package creator.peer.tool.storage

enum class ContactState { OUT_PENDING, IN_REQUEST, ACCEPTED, BLOCKED }

enum class MsgState { QUEUED, SENDING, DELIVERED, FAILED, EXPIRED, RECEIVED }

data class Contact(
    val peerId: String,
    val name: String,
    val customName: String?,
    val bundle: ByteArray?,
    val state: ContactState,
    val verified: Boolean,
    val muted: Boolean,
    val createdAt: Long,
    val lastSeenAt: Long?,
) {
    val displayName: String get() = customName?.takeIf { it.isNotBlank() } ?: name
}

data class Message(
    val id: String,
    val peerId: String,
    val outgoing: Boolean,
    val body: String,
    val replyTo: String?,
    val createdAt: Long,
    val receivedAt: Long?,
    val state: MsgState,
    val read: Boolean,
    val readByPeerAt: Long?,
    val pinned: Boolean,
)

data class OutboxRow(
    val msgId: String,
    val peerId: String,
    val envelope: ByteArray,
    val attempts: Int,
    val nextAttemptAt: Long,
    val createdAt: Long,
    val expiresAt: Long,
    val lastError: String?,
)

data class ConversationSummary(
    val peerId: String,
    val lastBody: String,
    val lastAt: Long,
    val lastOutgoing: Boolean,
    val lastState: MsgState,
    val unread: Int,
)

data class StoredIdentity(val peerId: String, val bundle: ByteArray, val privSealed: ByteArray, val createdAt: Long)

object TextLimits {
    const val NAME = 40
}
