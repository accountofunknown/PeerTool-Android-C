package creator.peer.tool.service

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import creator.peer.tool.PeerToolApp
import creator.peer.tool.notifications.Notifier

/**
 * Keeps the microphone (and camera for video calls) usable while PeerTool is in the background during a call.
 * Android requires a visible foreground notification for that.
 */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as PeerToolApp
        val video = intent?.getBooleanExtra(EXTRA_VIDEO, false) == true
        val name = intent?.getStringExtra(EXTRA_NAME) ?: "Call"
        val notification = app.container.notifier.callInProgressNotification(name)
        try {
            var type = 0
            if (Build.VERSION.SDK_INT >= 30) {
                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (video && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
            }
            ServiceCompat.startForeground(this, Notifier.CALL_SERVICE_NOTIFICATION_ID, notification, type)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    companion object {
        private const val EXTRA_VIDEO = "video"
        private const val EXTRA_NAME = "name"

        fun apply(ctx: Context, on: Boolean, name: String, video: Boolean) {
            val i = Intent(ctx, CallService::class.java).putExtra(EXTRA_VIDEO, video).putExtra(EXTRA_NAME, name)
            if (on) {
                try {
                    ContextCompat.startForegroundService(ctx, i)
                } catch (_: Exception) {
                }
            } else {
                ctx.stopService(i)
            }
        }
    }
}
