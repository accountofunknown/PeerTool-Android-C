package creator.peer.tool.storage

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PeerToolDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "peertool.db", null, Schema.VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        for (sql in Schema.statements(0, Schema.VERSION)) db.execSQL(sql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        for (sql in Schema.statements(oldVersion, newVersion)) db.execSQL(sql)
    }
}
