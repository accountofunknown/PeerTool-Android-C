package creator.peer.tool.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import creator.peer.tool.PeerToolApp
import creator.peer.tool.notifications.Notifier

/**
 * Optional foreground service ("Stay reachable"). It only keeps the app process alive and visible to the user
 * while the signaling connection and nearby discovery run; it does not guarantee delivery.
 */
class ReachabilityService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as PeerToolApp
        val notification = app.container.notifier.serviceNotification()
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING else 0
            ServiceCompat.startForeground(this, Notifier.SERVICE_NOTIFICATION_ID, notification, type)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        app.container.engine.kick()
        return START_STICKY
    }

    companion object {
        fun apply(ctx: Context, enabled: Boolean) {
            val i = Intent(ctx, ReachabilityService::class.java)
            if (enabled) {
                try {
                    ContextCompat.startForegroundService(ctx, i)
                } catch (_: Exception) {
                    // Background-start restrictions: user can retry from the foreground.
                }
            } else {
                ctx.stopService(i)
            }
        }
    }
}
