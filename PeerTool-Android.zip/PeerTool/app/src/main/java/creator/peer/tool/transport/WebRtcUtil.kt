package creator.peer.tool.transport

import android.content.Context
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy
import java.util.concurrent.atomic.AtomicBoolean

/** Helpers shared by the data transport and the call manager. */
object WebRtcUtil {
    private val initialized = AtomicBoolean(false)

    /** Native WebRTC globals must be initialised once per process. */
    fun ensureInit(context: Context) {
        if (initialized.compareAndSet(false, true)) {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions()
            )
        }
    }

    /**
     * Implements a WebRTC observer interface with a dynamic proxy, so we do not depend on which of its methods are
     * abstract or default in a given library build. Unknown methods are ignored.
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> proxyOf(cls: Class<T>, onError: (Throwable) -> Unit, handler: (String, Array<Any?>) -> Unit): T {
        val ih = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.getOrNull(0)
                "toString" -> "PeerToolObserver"
                else -> {
                    try {
                        handler(method.name, args ?: emptyArray())
                    } catch (e: Throwable) {
                        onError(e)
                    }
                    null
                }
            }
        }
        return Proxy.newProxyInstance(cls.classLoader, arrayOf(cls), ih) as T
    }

    fun sdpObserver(
        onError: (Throwable) -> Unit,
        onCreated: ((SessionDescription) -> Unit)? = null,
        onSet: (() -> Unit)? = null,
        onFailure: ((String) -> Unit)? = null,
    ): SdpObserver = proxyOf(SdpObserver::class.java, onError) { name, args ->
        when (name) {
            "onCreateSuccess" -> (args.getOrNull(0) as? SessionDescription)?.let { onCreated?.invoke(it) }
            "onSetSuccess" -> onSet?.invoke()
            "onCreateFailure", "onSetFailure" -> onFailure?.invoke((args.getOrNull(0) as? String) ?: "unknown")
        }
    }
}
