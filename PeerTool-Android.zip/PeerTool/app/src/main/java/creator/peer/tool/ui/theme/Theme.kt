package creator.peer.tool.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import creator.peer.tool.storage.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF2B3A8F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF),
    onPrimaryContainer = Color(0xFF0A1450),
    secondary = Color(0xFF00695C),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC8F1E8),
    onSecondaryContainer = Color(0xFF00201B),
    tertiary = Color(0xFF7A4B00),
    background = Color(0xFFFAFAFD),
    onBackground = Color(0xFF1A1B23),
    surface = Color(0xFFFAFAFD),
    onSurface = Color(0xFF1A1B23),
    surfaceVariant = Color(0xFFE6E7F2),
    onSurfaceVariant = Color(0xFF45464F),
    error = Color(0xFFB3261E),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB9C3FF),
    onPrimary = Color(0xFF0F1F72),
    primaryContainer = Color(0xFF29397C),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFF7FE3D4),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF005046),
    onSecondaryContainer = Color(0xFFC8F1E8),
    tertiary = Color(0xFFFFB95C),
    background = Color(0xFF121318),
    onBackground = Color(0xFFE4E1E9),
    surface = Color(0xFF121318),
    onSurface = Color(0xFFE4E1E9),
    surfaceVariant = Color(0xFF2B2D38),
    onSurfaceVariant = Color(0xFFC6C5D0),
    error = Color(0xFFF2B8B5),
)

private val AppTypography = Typography(
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp),
)

object StatusColors {
    val connected = Color(0xFF2E9E6B)
    val connecting = Color(0xFFE0A100)
    val degraded = Color(0xFFE5701A)
    val failed = Color(0xFFD13B3B)
    val discovered = Color(0xFF3B7BD1)
    val idle = Color(0xFF8A8D99)
}

@Composable
fun PeerToolTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
