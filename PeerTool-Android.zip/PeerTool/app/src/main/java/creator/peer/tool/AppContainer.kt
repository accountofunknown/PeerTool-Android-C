package creator.peer.tool

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.SystemClockImpl
import creator.peer.tool.crypto.IdentityKeys
import creator.peer.tool.crypto.KeystoreLocalCrypto
import creator.peer.tool.crypto.PeerCrypto
import creator.peer.tool.messaging.MessagingEngine
import creator.peer.tool.messaging.OutboxWorker
import creator.peer.tool.notifications.Notifier
import creator.peer.tool.storage.PeerToolDb
import creator.peer.tool.storage.SettingsHolder
import creator.peer.tool.storage.Store
import creator.peer.tool.transport.NearbyTransport
import creator.peer.tool.transport.WebRtcTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Manual dependency wiring; lives as long as the process. */
class AppContainer(private val app: Application) {
    val diag = DiagLog()
    private val local = KeystoreLocalCrypto()
    val store = Store(PeerToolDb(app), local)
    val settings = SettingsHolder(store, local)
    val notifier = Notifier(app, settings)

    private val _identity = MutableStateFlow<IdentityKeys?>(null)
    val identity: StateFlow<IdentityKeys?> = _identity

    private val webrtc = WebRtcTransport(
        context = app,
        settings = { settings.current },
        selfId = { _identity.value?.peerId },
        acceptFrom = { id -> settings.current.discoverable || store.contact(id) != null },
        diag = diag,
    )
    private val nearbyTransport = NearbyTransport(
        context = app,
        settings = { settings.current },
        selfId = { _identity.value?.peerId },
        diag = diag,
    )

    val engine = MessagingEngine(
        store = store,
        settingsHolder = settings,
        transports = listOf(webrtc, nearbyTransport),
        notifier = notifier,
        diag = diag,
        storageDir = app.filesDir,
        resolver = app.contentResolver,
        onOutboxQueued = { OutboxWorker.enqueueSoon(app) },
        clock = SystemClockImpl,
    )

    val webrtcInfo get() = webrtc.info
    val nearbyInfo get() = nearbyTransport.info

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready

    /** Set by notification taps / deep links; consumed by the UI. */
    val openChat = MutableStateFlow<String?>(null)
    val pendingLink = MutableStateFlow<String?>(null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun boot() {
        scope.launch {
            try {
                PeerCrypto.ensureInit()
                settings.load()
                val stored = store.loadIdentity()
                if (stored != null) {
                    try {
                        val keys = IdentityKeys.deserialize(local.open(stored.privSealed, "identity".toByteArray()))
                        _identity.value = keys
                        engine.attach(keys)
                    } catch (e: Exception) {
                        diag.add("identity could not be loaded")
                    }
                }
                notifier.ensureChannels()
                registerNetworkCallback()
                OutboxWorker.schedulePeriodic(app)
            } finally {
                _ready.value = true
            }
        }
    }

    /**
     * Searches for an identity whose ID starts with "pt" + [prefix] (a custom ID). Brute force: ~32^n attempts.
     * Blocks a background thread pool until found or [cancelled] returns true (then null).
     */
    suspend fun generateVanity(prefix: String, progress: (Long) -> Unit, cancelled: () -> Boolean): IdentityKeys? =
        withContext(Dispatchers.Default) {
            IdentityKeys.generateVanity(
                prefix,
                Runtime.getRuntime().availableProcessors().coerceIn(1, 6),
                progress,
                cancelled,
            )
        }

    /** Creates the first identity (keys never leave the device) and starts the engine. */
    suspend fun createIdentity(displayName: String, keys: IdentityKeys? = null) {
        withContext(Dispatchers.IO) {
            val k = keys ?: IdentityKeys.generate()
            val sealed = local.seal(k.serializePrivate(), "identity".toByteArray())
            store.saveIdentity(k.peerId, k.bundle, sealed, System.currentTimeMillis())
            settings.update { it.copy(displayName = displayName, onboardingDone = true) }
            _identity.value = k
            engine.attach(k)
        }
    }

    /** Swaps in a new identity (e.g. a custom-ID one). Erases contacts, messages and files; keeps settings. */
    suspend fun replaceIdentity(keys: IdentityKeys) {
        engine.replaceIdentity(keys) {
            val sealed = local.seal(keys.serializePrivate(), "identity".toByteArray())
            store.saveIdentity(keys.peerId, keys.bundle, sealed, System.currentTimeMillis())
            _identity.value = keys
        }
    }

    suspend fun resetEverything() {
        engine.wipeEverything()
        withContext(Dispatchers.IO) {
            _identity.value = null
            settings.load()
        }
    }

    private fun registerNetworkCallback() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java) ?: return
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    engine.onNetwork(true)
                }
            })
        } catch (e: Exception) {
            diag.add("network callback unavailable")
        }
    }
}
