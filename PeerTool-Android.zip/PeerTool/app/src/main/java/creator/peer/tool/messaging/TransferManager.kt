package creator.peer.tool.messaging

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import creator.peer.tool.core.Clock
import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.Hex
import creator.peer.tool.core.Ids
import creator.peer.tool.core.TextSafety
import creator.peer.tool.crypto.ChunkCrypto
import creator.peer.tool.protocol.Envelope
import creator.peer.tool.protocol.Inner
import creator.peer.tool.protocol.Kind
import creator.peer.tool.protocol.Limits
import creator.peer.tool.protocol.WireCodec
import creator.peer.tool.storage.SettingsHolder
import creator.peer.tool.storage.Store
import creator.peer.tool.storage.Transfer
import creator.peer.tool.storage.TransferState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.BitSet

/** What the transfer manager needs from the engine. All callbacks happen on the engine thread unless noted. */
interface TransferHost {
    fun myPeerId(): String?

    /** End-to-end encrypted, signed, best-effort control message. */
    fun sendControl(peerId: String, inner: Inner, preferLinkId: String?): Boolean

    /** Raw envelope bytes on a specific authenticated link. */
    fun sendOnLink(linkId: String, bytes: ByteArray): Boolean
    fun hasRoute(peerId: String): Boolean
    fun connect(peerId: String)
    fun notice(text: String)

    /** Runs [block] on a background IO thread. */
    fun runIo(block: () -> Unit)

    /** Runs [block] back on the engine thread. */
    fun postToEngine(block: () -> Unit)
}

class PreparedFile(val name: String, val mime: String, val size: Long, val sha256: String, val temp: File)

/**
 * Chunked, resumable, receiver-driven file transfer.
 *
 * Offer (key, size, SHA-256) travels as a normal persisted E2E message. After the receiver accepts, it pulls
 * 16 KiB chunks in a sliding window of requests; every chunk is AES-GCM encrypted with the per-transfer key and
 * bound to (transfer, index, total). The receiver writes chunks to a pre-sized partial file, persists a bitmap
 * checkpoint, and verifies the SHA-256 of the whole file before exposing it. Anything missing is simply requested
 * again, which is also how resume after a lost connection or app restart works.
 */
class TransferManager(
    private val store: Store,
    private val settingsHolder: SettingsHolder,
    storageDir: File,
    private val resolver: ContentResolver,
    private val host: TransferHost,
    private val diag: DiagLog,
    private val clock: Clock,
) {
    private val outDir = File(storageDir, "transfers/out").also { it.mkdirs() }
    private val inDir = File(storageDir, "transfers/in").also { it.mkdirs() }
    private val root = File(storageDir, "transfers")

    private class RecvState(val t: Transfer) {
        val have = BitSet(t.chunks)
        var count = 0
        val requested = HashMap<Int, Long>()
        var raf: RandomAccessFile? = null
        var sincePersist = 0
        var lastProgress = 0L
        var finishing = false
    }

    private class SendState(val t: Transfer) {
        val sent = BitSet(t.chunks)
        var raf: RandomAccessFile? = null
    }

    private val recv = HashMap<String, RecvState>()
    private val sending = HashMap<String, SendState>()

    private val _progress = MutableStateFlow<Map<String, Int>>(emptyMap())

    /** transfer id -> chunks done, for transfers moving right now (UI uses this for smooth progress bars). */
    val progress: StateFlow<Map<String, Int>> = _progress

    private fun publish(id: String, done: Int) = _progress.update { it + (id to done) }
    private fun unpublish(id: String) = _progress.update { it - id }

    // ------------------------------------------------------------------ files

    fun fileFor(t: Transfer): File? {
        val n = t.fileName ?: return null
        val f = File(if (t.outgoing) outDir else inDir, n)
        return if (f.isFile) f else null
    }

    private fun safeFileName(id: String, name: String): String =
        id + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)

    private fun chunkLen(t: Transfer, idx: Int): Int =
        if (idx == t.chunks - 1) (t.size - idx.toLong() * t.chunkSize).toInt() else t.chunkSize

    fun attachmentsBytes(): Long =
        (outDir.listFiles().orEmpty().toList() + inDir.listFiles().orEmpty().toList()).filter { it.isFile }.sumOf { it.length() }

    /** Blocking: copies and hashes a picked file. Call from an IO thread. Throws a user-readable exception on failure. */
    fun prepareOutgoing(uri: Uri, maxBytes: Long): PreparedFile {
        var name = "file"
        var declared = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (si >= 0 && !c.isNull(si)) declared = c.getLong(si)
            }
        }
        if (declared > maxBytes) throw IllegalArgumentException("File is larger than your ${maxBytes / (1024 * 1024)} MB limit")
        val rawMime = resolver.getType(uri) ?: "application/octet-stream"
        val mime = if (Regex("^[\\w.+-]{1,60}/[\\w.+-]{1,60}$").matches(rawMime)) rawMime else "application/octet-stream"
        val clean = TextSafety.sanitizeName(name.replace('/', '_').replace('\\', '_'), Limits.MAX_FILE_NAME).ifEmpty { "file" }
        val temp = File(outDir, "tmp_" + Hex.encode(Ids.randomBytes(8)))
        val md = ChunkCrypto.sha256()
        var total = 0L
        try {
            val input = resolver.openInputStream(uri) ?: throw IOException("Could not open the file")
            input.use { ins ->
                temp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > maxBytes) throw IllegalArgumentException("File is larger than your ${maxBytes / (1024 * 1024)} MB limit")
                        md.update(buf, 0, n)
                        out.write(buf, 0, n)
                    }
                }
            }
            if (total == 0L) throw IllegalArgumentException("The file is empty")
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
        return PreparedFile(clean, mime, total, Hex.encode(md.digest()), temp)
    }

    /** Moves a prepared temp file to its final name. Engine thread. */
    fun adopt(p: PreparedFile, id: String): String {
        val fn = safeFileName(id, p.name)
        if (!p.temp.renameTo(File(outDir, fn))) {
            p.temp.delete()
            throw IOException("Could not store the file")
        }
        return fn
    }

    fun incomingFileName(id: String, name: String): String = safeFileName(id, name)

    // ------------------------------------------------------------------ receiving: user actions

    fun accept(id: String) {
        val t0 = store.transfer(id) ?: return
        if (t0.outgoing) return
        if (t0.state != TransferState.OFFERED && t0.state != TransferState.FAILED) return
        val now = clock.now()
        if (recv.size >= MAX_ACTIVE_INCOMING) {
            host.notice("Too many downloads at once. Try again when one finishes.")
            return
        }
        if (t0.size + 32L * 1024 * 1024 > root.usableSpace) {
            store.setTransferState(id, TransferState.FAILED, "Not enough free storage", now)
            host.notice("Not enough free storage")
            return
        }
        if (t0.state == TransferState.FAILED) store.resetTransfer(id, now)
        val t = store.transfer(id) ?: return
        val part = File(inDir, "$id.part")
        try {
            part.delete()
            RandomAccessFile(part, "rw").use { it.setLength(t.size) }
        } catch (e: IOException) {
            store.setTransferState(id, TransferState.FAILED, "Could not create file", now)
            return
        }
        store.setTransferState(id, TransferState.ACTIVE, null, now)
        val rs = RecvState(t)
        rs.lastProgress = now
        recv[id] = rs
        publish(id, 0)
        requestMore(rs, null)
    }

    /** Cancel or decline from this device. Tells the peer. */
    fun cancel(id: String) {
        val t = store.transfer(id) ?: return
        if (t.state != TransferState.OFFERED && t.state != TransferState.ACTIVE) return
        cleanup(t)
        store.setTransferState(id, TransferState.CANCELLED, "Cancelled", clock.now())
        host.sendControl(t.peerId, Inner.FileCancel(id, "cancelled"), null)
    }

    /** The message is being deleted locally: stop and remove everything without leaving rows behind. */
    fun discard(id: String) {
        val t = store.transfer(id) ?: return
        if (t.state == TransferState.OFFERED || t.state == TransferState.ACTIVE) {
            host.sendControl(t.peerId, Inner.FileCancel(id, "deleted"), null)
        }
        cleanup(t)
        t.fileName?.let { File(if (t.outgoing) outDir else inDir, it).delete() }
    }

    fun discardPeer(peerId: String) {
        for (t in store.transfersForPeer(peerId)) {
            cleanup(t)
            t.fileName?.let { File(if (t.outgoing) outDir else inDir, it).delete() }
        }
    }

    private fun cleanup(t: Transfer) {
        recv.remove(t.id)?.raf?.let { runCatching { it.close() } }
        sending.remove(t.id)?.raf?.let { runCatching { it.close() } }
        unpublish(t.id)
        File(inDir, "${t.id}.part").delete()
        if (t.outgoing && t.state != TransferState.DONE) t.fileName?.let { File(outDir, it).delete() }
    }

    // ------------------------------------------------------------------ receiving: protocol

    private fun restore(t: Transfer) {
        val part = File(inDir, "${t.id}.part")
        if (!part.isFile || part.length() != t.size) {
            store.setTransferState(t.id, TransferState.FAILED, "Partial file was lost", clock.now())
            return
        }
        val rs = RecvState(t)
        t.bitmap?.let { rs.have.or(BitSet.valueOf(it)) }
        rs.count = rs.have.cardinality()
        rs.lastProgress = clock.now()
        recv[t.id] = rs
        publish(t.id, rs.count)
    }

    private fun requestMore(rs: RecvState, preferLinkId: String?) {
        if (rs.finishing) return
        val now = clock.now()
        rs.requested.values.removeAll { now - it > REQUEST_TIMEOUT_MS }
        val outstanding = rs.requested.size
        if (outstanding > WINDOW / 2) return
        val need = WINDOW - outstanding
        val want = ArrayList<Int>(need)
        var i = rs.have.nextClearBit(0)
        while (i < rs.t.chunks && want.size < need) {
            if (!rs.requested.containsKey(i)) want.add(i)
            i = rs.have.nextClearBit(i + 1)
        }
        if (want.isEmpty()) return
        for (batch in want.chunked(Limits.MAX_REQ_INDICES)) {
            if (!host.sendControl(rs.t.peerId, Inner.FileReq(rs.t.id, batch), preferLinkId)) {
                host.connect(rs.t.peerId)
                return
            }
            for (idx in batch) rs.requested[idx] = now
        }
    }

    fun onChunk(peerId: String, linkId: String, env: Envelope) {
        val rs = recv[env.id] ?: return
        if (rs.t.peerId != peerId || rs.finishing) return
        val t = rs.t
        val body = env.body
        if (body.size < 4 + ChunkCrypto.TAG_BYTES + 1 || body.size > 4 + t.chunkSize + ChunkCrypto.TAG_BYTES) return
        val idx = ByteBuffer.wrap(body, 0, 4).int
        if (idx < 0 || idx >= t.chunks) return
        if (rs.have.get(idx)) {
            rs.requested.remove(idx)
            return
        }
        val plain = try {
            ChunkCrypto.decrypt(t.key, t.id, idx, t.chunks, body.copyOfRange(4, body.size))
        } catch (e: Exception) {
            return
        }
        if (plain.size != chunkLen(t, idx)) return
        try {
            val raf = rs.raf ?: RandomAccessFile(File(inDir, "${t.id}.part"), "rw").also { rs.raf = it }
            raf.seek(idx.toLong() * t.chunkSize)
            raf.write(plain)
        } catch (e: IOException) {
            fail(rs, "Storage error")
            return
        }
        rs.have.set(idx)
        rs.count++
        rs.requested.remove(idx)
        rs.lastProgress = clock.now()
        publish(t.id, rs.count)
        if (++rs.sincePersist >= 16) {
            rs.sincePersist = 0
            store.saveTransferProgress(t.id, rs.count, rs.have.toByteArray(), clock.now())
        }
        if (rs.count >= t.chunks) finishReceive(rs) else requestMore(rs, linkId)
    }

    private fun finishReceive(rs: RecvState) {
        rs.finishing = true
        runCatching { rs.raf?.close() }
        rs.raf = null
        val t = rs.t
        host.runIo {
            val ok = try {
                val md = ChunkCrypto.sha256()
                File(inDir, "${t.id}.part").inputStream().use { ins ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        md.update(buf, 0, n)
                    }
                }
                Hex.encode(md.digest()) == t.sha256
            } catch (e: Exception) {
                false
            }
            host.postToEngine { completeReceive(rs, ok) }
        }
    }

    private fun completeReceive(rs: RecvState, ok: Boolean) {
        val t = rs.t
        if (recv[t.id] !== rs) return // cancelled meanwhile
        val now = clock.now()
        if (!ok) {
            fail(rs, "Integrity check failed")
            return
        }
        val fn = safeFileName(t.id, t.name)
        val part = File(inDir, "${t.id}.part")
        if (!part.renameTo(File(inDir, fn))) {
            fail(rs, "Could not store the file")
            return
        }
        recv.remove(t.id)
        unpublish(t.id)
        store.saveTransferProgress(t.id, t.chunks, null, now)
        store.setTransferFile(t.id, fn)
        store.setTransferState(t.id, TransferState.DONE, null, now)
        host.sendControl(t.peerId, Inner.FileDone(t.id), null)
        host.notice("Received ${t.name}")
    }

    private fun fail(rs: RecvState, reason: String) {
        val t = rs.t
        recv.remove(t.id)
        runCatching { rs.raf?.close() }
        unpublish(t.id)
        File(inDir, "${t.id}.part").delete()
        store.setTransferState(t.id, TransferState.FAILED, reason, clock.now())
        host.sendControl(t.peerId, Inner.FileCancel(t.id, reason), null)
        host.notice("Transfer failed: $reason")
    }

    // ------------------------------------------------------------------ sending

    fun onReq(peerId: String, linkId: String, req: Inner.FileReq) {
        val now = clock.now()
        val t = store.transfer(req.id)
        if (t == null || !t.outgoing || t.peerId != peerId ||
            (t.state != TransferState.OFFERED && t.state != TransferState.ACTIVE)
        ) {
            host.sendControl(peerId, Inner.FileCancel(req.id, "unavailable"), linkId)
            return
        }
        val file = fileFor(t)
        if (file == null) {
            store.setTransferState(t.id, TransferState.FAILED, "File is missing on this device", now)
            host.sendControl(peerId, Inner.FileCancel(req.id, "unavailable"), linkId)
            return
        }
        if (t.state == TransferState.OFFERED) store.setTransferState(t.id, TransferState.ACTIVE, null, now)
        val from = host.myPeerId() ?: return
        val ss = sending.getOrPut(t.id) { SendState(t) }
        try {
            val raf = ss.raf ?: RandomAccessFile(file, "r").also { ss.raf = it }
            for (idx in req.indices.distinct()) {
                if (idx < 0 || idx >= t.chunks) continue
                val buf = ByteArray(chunkLen(t, idx))
                raf.seek(idx.toLong() * t.chunkSize)
                raf.readFully(buf)
                val ct = ChunkCrypto.encrypt(t.key, t.id, idx, t.chunks, buf)
                val body = ByteBuffer.allocate(4 + ct.size).putInt(idx).put(ct).array()
                val env = Envelope(Kind.CHUNK, t.id, from, peerId, now, body)
                if (!host.sendOnLink(linkId, WireCodec.encode(env))) break // backpressure: receiver re-requests
                ss.sent.set(idx)
            }
        } catch (e: IOException) {
            sending.remove(t.id)?.raf?.let { runCatching { it.close() } }
            store.setTransferState(t.id, TransferState.FAILED, "Could not read the file", now)
            host.sendControl(peerId, Inner.FileCancel(req.id, "unavailable"), linkId)
            return
        }
        val done = ss.sent.cardinality()
        publish(t.id, done)
        store.saveTransferProgress(t.id, done, null, now)
    }

    fun onPeerDone(peerId: String, id: String) {
        val t = store.transfer(id) ?: return
        if (!t.outgoing || t.peerId != peerId) return
        if (t.state != TransferState.ACTIVE && t.state != TransferState.OFFERED) return
        sending.remove(id)?.raf?.let { runCatching { it.close() } }
        unpublish(id)
        store.saveTransferProgress(id, t.chunks, null, clock.now())
        store.setTransferState(id, TransferState.DONE, null, clock.now())
    }

    fun onPeerCancel(peerId: String, id: String, reason: String) {
        val t = store.transfer(id) ?: return
        if (t.peerId != peerId) return
        if (t.state != TransferState.OFFERED && t.state != TransferState.ACTIVE) return
        cleanup(t)
        store.setTransferState(id, TransferState.CANCELLED, "Cancelled by contact", clock.now())
        host.notice("A file transfer was cancelled")
    }

    // ------------------------------------------------------------------ periodic

    fun tick(now: Long) {
        for (t in store.transfersInStates(listOf(TransferState.ACTIVE))) {
            if (!t.outgoing && !recv.containsKey(t.id)) restore(t)
        }
        for (rs in recv.values.toList()) {
            if (rs.finishing) continue
            if (host.hasRoute(rs.t.peerId)) {
                requestMore(rs, null)
                if (now - rs.lastProgress > STALL_MS) fail(rs, "Sender is not responding")
            } else {
                rs.lastProgress = now
                host.connect(rs.t.peerId)
            }
        }
    }

    fun maintenance(now: Long) {
        for (t in store.expireTransfers(now - OFFER_TTL_MS, now)) cleanup(t)
        sweep()
    }

    /** Deletes files that no transfer row refers to (orphans after deletions) and stale temp files. */
    fun sweep() {
        val keep = HashSet<String>(store.transferFileNames())
        for (t in store.transfersInStates(listOf(TransferState.ACTIVE))) if (!t.outgoing) keep.add("${t.id}.part")
        val now = clock.now()
        for (dir in listOf(outDir, inDir)) {
            for (f in dir.listFiles().orEmpty()) {
                if (!f.isFile || f.name in keep) continue
                if (f.name.startsWith("tmp_") && now - f.lastModified() < 3_600_000L) continue
                f.delete()
            }
        }
    }

    fun deleteAllFiles(): Long {
        var freed = 0L
        for (t in store.allTransfers()) {
            if (t.state == TransferState.ACTIVE) continue
            val f = fileFor(t) ?: continue
            freed += f.length()
            f.delete()
            store.setTransferFile(t.id, null)
            if (t.state == TransferState.DONE) {
                store.setTransferState(t.id, TransferState.EXPIRED, "File removed from this device", clock.now())
            }
        }
        sweep()
        return freed
    }

    fun deleteAll() {
        recv.values.forEach { runCatching { it.raf?.close() } }
        sending.values.forEach { runCatching { it.raf?.close() } }
        recv.clear()
        sending.clear()
        _progress.value = emptyMap()
        root.deleteRecursively()
        outDir.mkdirs()
        inDir.mkdirs()
    }

    /** Copies the stored file to a user-chosen destination (blocking, IO thread). */
    fun exportTo(t: Transfer, dest: Uri): Boolean {
        val src = fileFor(t) ?: return false
        return try {
            resolver.openOutputStream(dest)?.use { out -> src.inputStream().use { it.copyTo(out) } } != null
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private const val WINDOW = 32
        private const val REQUEST_TIMEOUT_MS = 10_000L
        private const val STALL_MS = 120_000L
        private const val MAX_ACTIVE_INCOMING = 4
        private const val OFFER_TTL_MS = 7L * 24 * 3_600_000L
    }
}
