package creator.peer.tool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import creator.peer.tool.notifications.Notifier
import creator.peer.tool.ui.PeerToolRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as PeerToolApp).container
        handle(intent)
        setContent { PeerToolRoot(container) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val c = (application as PeerToolApp).container
        i?.getStringExtra(Notifier.EXTRA_PEER_ID)?.let { c.openChat.value = it }
        val data = i?.data
        if (data != null && data.scheme == "peertool") c.pendingLink.value = data.toString()
    }
}
