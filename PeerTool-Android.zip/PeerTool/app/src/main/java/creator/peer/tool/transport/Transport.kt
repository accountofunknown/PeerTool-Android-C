package creator.peer.tool.transport

import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.flow.StateFlow

enum class TransportKind { WEBRTC, NEARBY }

enum class TransportStatus { OFF, STARTING, READY, ERROR }

data class TransportInfo(val status: TransportStatus, val detail: String = "")

sealed interface TransportEvent {
    data class LinkConnecting(val linkId: String, val kind: TransportKind, val hint: String?, val incoming: Boolean) : TransportEvent
    data class LinkUp(val linkId: String, val kind: TransportKind, val hint: String?, val incoming: Boolean) : TransportEvent
    data class LinkDown(val linkId: String, val kind: TransportKind, val reason: String) : TransportEvent
    class Data(val linkId: String, val kind: TransportKind, val bytes: ByteArray) : TransportEvent
    /** A nearby device became visible (or disappeared). [key] is transport specific. */
    data class Discovered(val kind: TransportKind, val key: String, val hint: String?, val present: Boolean) : TransportEvent
}

/**
 * A transport only moves opaque bytes over "links". Identity, authentication, encryption and
 * delivery guarantees are handled above it, so transports are interchangeable.
 */
interface Transport {
    val kind: TransportKind
    val info: StateFlow<TransportInfo>
    val events: ReceiveChannel<TransportEvent>

    /** Idempotent. Reads the current settings. */
    fun start()
    fun stop()

    /** Starts (or joins) an attempt to reach the peer with this ID. Returns true if an attempt is under way. */
    fun connect(hint: String): Boolean

    /** Hands bytes to the link. true = accepted by the transport (NOT delivered). */
    fun send(linkId: String, bytes: ByteArray): Boolean

    fun close(linkId: String)

    /** Hint that conditions changed (network back, app foregrounded): retry cheaply if currently failing. */
    fun kick() {}
}
