package creator.peer.tool.crypto

import creator.peer.tool.core.Base32
import creator.peer.tool.core.Ids
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Short, single-use invite codes ("K7M4-QX2P").
 *
 * The code is a shared secret (40 bits). It is stretched with PBKDF2-HMAC-SHA256 (150,000 iterations), and the result
 * is split into (a) a temporary rendezvous ID on the signaling server where the inviter waits and (b) a MAC key.
 * Both sides must prove knowledge of that key inside the contact handshake, so a signaling server or bystander who
 * only sees the rendezvous ID cannot join as the invitee or pose as the inviter without brute-forcing the stretched code.
 */
object InviteCode {
    const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // 32 symbols, no I, O, 0, 1
    const val LENGTH = 8
    const val ITERATIONS = 150_000
    const val LIFETIME_MS = 10 * 60_000L
    private val SALT = "PeerTool-invite-v1".toByteArray(Charsets.UTF_8)
    private val RENDEZVOUS = Regex("^ptc[a-z2-7]{24}$")

    class Derived(val rendezvousId: String, val key: ByteArray)

    fun isRendezvousId(s: String): Boolean = RENDEZVOUS.matches(s)

    /** New random code, 8 symbols (no separator). */
    fun generate(): String {
        val sb = StringBuilder()
        val rnd = Ids.randomBytes(LENGTH)
        for (b in rnd) sb.append(ALPHABET[b.toInt() and 31])
        return sb.toString()
    }

    fun format(code: String): String = code.chunked(4).joinToString("-")

    /** Accepts any case, spaces and dashes. Returns the canonical 8 symbols or null if invalid. */
    fun normalize(input: String): String? {
        val c = input.uppercase().filter { it != '-' && !it.isWhitespace() }
        return if (c.length == LENGTH && c.all { it in ALPHABET }) c else null
    }

    /** CPU heavy (about a fraction of a second). Call from a background thread. */
    fun derive(code: String): Derived {
        val spec = PBEKeySpec(code.toCharArray(), SALT, ITERATIONS, 256)
        val out = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        val id = "ptc" + Base32.encode(out.copyOf(15))
        return Derived(id, hmac(out, "PT-INV-KEY".toByteArray()))
    }

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    /** Invitee -> inviter proof, bound to both peer IDs. */
    fun proofRequest(key: ByteArray, inviteeId: String, inviterId: String): ByteArray =
        hmac(key, "PT-INV-REQ|$inviteeId|$inviterId".toByteArray(Charsets.UTF_8))

    /** Inviter -> invitee proof, bound to both peer IDs. */
    fun proofAccept(key: ByteArray, inviterId: String, inviteeId: String): ByteArray =
        hmac(key, "PT-INV-ACC|$inviterId|$inviteeId".toByteArray(Charsets.UTF_8))

    fun same(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)
}
