package creator.peer.tool.core

import java.security.MessageDigest

/**
 * Pronounceable label derived from a peer ID, e.g. "brave-otter-42". It is only a reading aid for comparing IDs
 * aloud (about 18 bits): different IDs can share a label, and a label cannot be typed in to add someone.
 */
object FriendlyName {
    private val adjectives = listOf(
        "brave", "calm", "clever", "bright", "bold", "cosmic", "crisp", "daring",
        "eager", "fancy", "gentle", "golden", "happy", "jolly", "keen", "lively",
        "lucky", "mellow", "mighty", "noble", "quick", "quiet", "rapid", "royal",
        "shiny", "silent", "smooth", "solar", "speedy", "steady", "sunny", "swift",
        "tidy", "vivid", "warm", "witty", "wild", "young", "zesty", "amber",
        "azure", "coral", "crimson", "frosty", "glossy", "hazel", "indigo", "ivory",
        "jade", "lunar", "maple", "misty", "olive", "pearl", "rusty", "sandy",
        "silver", "snowy", "stormy", "velvet", "violet", "windy", "woody", "zen"
    )
    private val nouns = listOf(
        "otter", "falcon", "panda", "tiger", "eagle", "dolphin", "koala", "lynx",
        "heron", "badger", "beaver", "bison", "cobra", "condor", "coyote", "crane",
        "dingo", "ferret", "finch", "gecko", "gopher", "hawk", "ibis", "jaguar",
        "kiwi", "lemur", "llama", "marten", "newt", "ocelot", "osprey", "owl",
        "parrot", "pelican", "puffin", "quokka", "raven", "salmon", "seal", "sparrow",
        "squid", "stork", "swan", "tapir", "toucan", "turtle", "viper", "walrus",
        "weasel", "whale", "wolf", "wombat", "yak", "zebra", "antelope", "bobcat",
        "camel", "cheetah", "gazelle", "giraffe", "hedgehog", "mongoose", "narwhal", "penguin"
    )

    fun of(peerId: String): String {
        val h = MessageDigest.getInstance("SHA-256").digest(("PT1-friendly|" + peerId).toByteArray(Charsets.UTF_8))
        val a = adjectives[h[0].toInt() and 63]
        val n = nouns[h[1].toInt() and 63]
        val num = (h[2].toInt() and 0xff) % 100
        return "$a-$n-" + num.toString().padStart(2, '0')
    }
}
