package creator.peer.tool.storage

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import creator.peer.tool.crypto.LocalCrypto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

/**
 * Single persistence facade. Authoritative message/delivery state lives here; UI and transports never keep their own copy.
 * Message bodies are sealed with a Keystore-backed key (AAD = message id).
 */
class Store(private val helper: PeerToolDb, private val local: LocalCrypto) {
    private val db: SQLiteDatabase get() = helper.writableDatabase

    val changes = MutableStateFlow(0L)

    private fun bump() {
        changes.update { it + 1 }
    }

    fun <T> observe(query: () -> T): Flow<T> =
        changes.map { query() }.flowOn(Dispatchers.IO).distinctUntilChanged()

    private inline fun <T> tx(block: () -> T): T {
        val d = db
        d.beginTransaction()
        try {
            val r = block()
            d.setTransactionSuccessful()
            return r
        } finally {
            d.endTransaction()
        }
    }

    // ---------------------------------------------------------------- identity

    fun loadIdentity(): StoredIdentity? =
        db.rawQuery("SELECT peer_id, bundle, priv_blob, created_at FROM identity WHERE id = 1", null).use { c ->
            if (c.moveToFirst()) StoredIdentity(c.getString(0), c.getBlob(1), c.getBlob(2), c.getLong(3)) else null
        }

    fun saveIdentity(peerId: String, bundle: ByteArray, privSealed: ByteArray, now: Long) {
        val cv = ContentValues()
        cv.put("id", 1)
        cv.put("peer_id", peerId)
        cv.put("bundle", bundle)
        cv.put("priv_blob", privSealed)
        cv.put("created_at", now)
        db.insertWithOnConflict("identity", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        bump()
    }

    fun wipeAll() {
        tx {
            for (t in listOf("transfers", "outbox", "processed", "messages", "contacts", "identity", "settings")) {
                db.delete(t, null, null)
            }
        }
        bump()
    }

    /** Deletes contacts, messages and transfers but keeps settings (used when the identity is replaced). */
    fun wipeUserData() {
        tx {
            for (t in listOf("transfers", "outbox", "processed", "messages", "contacts", "identity")) {
                db.delete(t, null, null)
            }
        }
        bump()
    }

    // ---------------------------------------------------------------- contacts

    private val contactCols = "peer_id, name, custom_name, bundle, state, verified, muted, created_at, last_seen_at, handle"

    private fun readContact(c: Cursor) = Contact(
        peerId = c.getString(0),
        name = c.getString(1),
        customName = if (c.isNull(2)) null else c.getString(2),
        bundle = if (c.isNull(3)) null else c.getBlob(3),
        state = ContactState.valueOf(c.getString(4)),
        verified = c.getInt(5) != 0,
        muted = c.getInt(6) != 0,
        createdAt = c.getLong(7),
        lastSeenAt = if (c.isNull(8)) null else c.getLong(8),
        handle = if (c.isNull(9)) null else c.getString(9),
    )

    fun contacts(): List<Contact> =
        db.rawQuery("SELECT $contactCols FROM contacts ORDER BY LOWER(COALESCE(custom_name, name))", null).use { c ->
            val out = ArrayList<Contact>()
            while (c.moveToNext()) out.add(readContact(c))
            out
        }

    fun contact(peerId: String): Contact? =
        db.rawQuery("SELECT $contactCols FROM contacts WHERE peer_id = ?", arrayOf(peerId)).use { c ->
            if (c.moveToFirst()) readContact(c) else null
        }

    fun countContacts(state: ContactState): Int =
        db.rawQuery("SELECT COUNT(*) FROM contacts WHERE state = ?", arrayOf(state.name)).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }

    fun insertContact(ct: Contact) {
        val cv = ContentValues()
        cv.put("peer_id", ct.peerId)
        cv.put("name", ct.name)
        cv.put("custom_name", ct.customName)
        cv.put("bundle", ct.bundle)
        cv.put("state", ct.state.name)
        cv.put("verified", if (ct.verified) 1 else 0)
        cv.put("muted", if (ct.muted) 1 else 0)
        cv.put("created_at", ct.createdAt)
        cv.put("handle", ct.handle)
        db.insertWithOnConflict("contacts", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        bump()
    }

    fun acceptContact(peerId: String, bundle: ByteArray, name: String?) {
        val cv = ContentValues()
        cv.put("state", ContactState.ACCEPTED.name)
        cv.put("bundle", bundle)
        if (!name.isNullOrBlank()) cv.put("name", name)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun setContactState(peerId: String, state: ContactState) {
        val cv = ContentValues()
        cv.put("state", state.name)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun updateContactName(peerId: String, name: String) {
        val cv = ContentValues()
        cv.put("name", name)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun setHandle(peerId: String, handle: String?) {
        val cv = ContentValues()
        cv.put("handle", handle?.takeIf { it.isNotEmpty() })
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun setCustomName(peerId: String, name: String?) {
        val cv = ContentValues()
        cv.put("custom_name", name?.takeIf { it.isNotBlank() })
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun setVerified(peerId: String, v: Boolean) {
        val cv = ContentValues()
        cv.put("verified", if (v) 1 else 0)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun setMuted(peerId: String, v: Boolean) {
        val cv = ContentValues()
        cv.put("muted", if (v) 1 else 0)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
        bump()
    }

    fun touchSeen(peerId: String, now: Long) {
        val cv = ContentValues()
        cv.put("last_seen_at", now)
        db.update("contacts", cv, "peer_id = ?", arrayOf(peerId))
    }

    /** Removes the contact, its messages, its outbox rows and replay records. */
    fun deleteContact(peerId: String) {
        tx {
            db.delete("outbox", "peer_id = ?", arrayOf(peerId))
            db.delete("messages", "peer_id = ?", arrayOf(peerId))
            db.delete("processed", "peer_id = ?", arrayOf(peerId))
            db.delete("contacts", "peer_id = ?", arrayOf(peerId))
        }
        bump()
    }

    // ---------------------------------------------------------------- messages

    private val msgCols =
        "id, peer_id, direction, body, reply_to, created_at, received_at, state, read, read_at, pinned, my_reaction, their_reaction"

    private fun readMessage(c: Cursor): Message? {
        val id = c.getString(0)
        val body = try {
            String(local.open(c.getBlob(3), id.toByteArray(Charsets.UTF_8)), Charsets.UTF_8)
        } catch (e: Exception) {
            return null
        }
        return Message(
            id = id,
            peerId = c.getString(1),
            outgoing = c.getInt(2) == 1,
            body = body,
            replyTo = if (c.isNull(4)) null else c.getString(4),
            createdAt = c.getLong(5),
            receivedAt = if (c.isNull(6)) null else c.getLong(6),
            state = MsgState.valueOf(c.getString(7)),
            read = c.getInt(8) != 0,
            readByPeerAt = if (c.isNull(9)) null else c.getLong(9),
            pinned = c.getInt(10) != 0,
            myReaction = if (c.isNull(11)) null else c.getString(11),
            theirReaction = if (c.isNull(12)) null else c.getString(12),
        )
    }

    private fun messageValues(m: Message): ContentValues {
        val cv = ContentValues()
        cv.put("id", m.id)
        cv.put("peer_id", m.peerId)
        cv.put("direction", if (m.outgoing) 1 else 0)
        cv.put("body", local.seal(m.body.toByteArray(Charsets.UTF_8), m.id.toByteArray(Charsets.UTF_8)))
        cv.put("reply_to", m.replyTo)
        cv.put("created_at", m.createdAt)
        cv.put("received_at", m.receivedAt)
        cv.put("state", m.state.name)
        cv.put("read", if (m.read) 1 else 0)
        cv.put("pinned", if (m.pinned) 1 else 0)
        cv.put("my_reaction", m.myReaction)
        cv.put("their_reaction", m.theirReaction)
        return cv
    }

    fun setReaction(id: String, mine: Boolean, emoji: String?) {
        val cv = ContentValues()
        cv.put(if (mine) "my_reaction" else "their_reaction", emoji?.takeIf { it.isNotEmpty() })
        db.update("messages", cv, "id = ?", arrayOf(id))
        bump()
    }

    fun message(id: String): Message? =
        db.rawQuery("SELECT $msgCols FROM messages WHERE id = ?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) readMessage(c) else null
        }

    fun messagesFor(peerId: String, limit: Int = 500): List<Message> =
        db.rawQuery(
            "SELECT $msgCols FROM (SELECT * FROM messages WHERE peer_id = ? ORDER BY created_at DESC LIMIT ?) ORDER BY created_at ASC",
            arrayOf(peerId, limit.toString())
        ).use { c ->
            val out = ArrayList<Message>()
            while (c.moveToNext()) readMessage(c)?.let { out.add(it) }
            out
        }

    fun messagesInStates(states: List<MsgState>): List<Message> {
        val marks = states.joinToString(",") { "?" }
        return db.rawQuery(
            "SELECT $msgCols FROM messages WHERE direction = 1 AND state IN ($marks) ORDER BY created_at ASC",
            states.map { it.name }.toTypedArray()
        ).use { c ->
            val out = ArrayList<Message>()
            while (c.moveToNext()) readMessage(c)?.let { out.add(it) }
            out
        }
    }

    /** Case-insensitive substring search. Bodies are encrypted at rest, so matching happens after decryption. */
    fun search(query: String, peerId: String? = null, limit: Int = 100): List<Message> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val sql = if (peerId == null) {
            "SELECT $msgCols FROM messages ORDER BY created_at DESC LIMIT 5000"
        } else {
            "SELECT $msgCols FROM messages WHERE peer_id = ? ORDER BY created_at DESC LIMIT 5000"
        }
        return db.rawQuery(sql, if (peerId == null) null else arrayOf(peerId)).use { c ->
            val out = ArrayList<Message>()
            while (c.moveToNext() && out.size < limit) {
                val m = readMessage(c) ?: continue
                if (m.body.contains(q, ignoreCase = true)) out.add(m)
            }
            out
        }
    }

    fun conversations(): List<ConversationSummary> {
        val sql = """
            SELECT m.peer_id, m.id, m.body, m.created_at, m.direction, m.state,
              (SELECT COUNT(*) FROM messages u WHERE u.peer_id = m.peer_id AND u.direction = 0 AND u.read = 0) AS unread
            FROM messages m
            WHERE m.created_at = (SELECT MAX(x.created_at) FROM messages x WHERE x.peer_id = m.peer_id)
            GROUP BY m.peer_id
            ORDER BY m.created_at DESC
        """.trimIndent()
        return db.rawQuery(sql, null).use { c ->
            val out = ArrayList<ConversationSummary>()
            while (c.moveToNext()) {
                val id = c.getString(1)
                val body = try {
                    String(local.open(c.getBlob(2), id.toByteArray(Charsets.UTF_8)), Charsets.UTF_8)
                } catch (e: Exception) {
                    ""
                }
                out.add(
                    ConversationSummary(
                        peerId = c.getString(0),
                        lastBody = body,
                        lastAt = c.getLong(3),
                        lastOutgoing = c.getInt(4) == 1,
                        lastState = MsgState.valueOf(c.getString(5)),
                        unread = c.getInt(6),
                    )
                )
            }
            out
        }
    }

    /** Atomically persists an outgoing message and its outbox job. */
    fun insertOutgoing(m: Message, o: OutboxRow) {
        tx {
            db.insertOrThrow("messages", null, messageValues(m))
            db.insertOrThrow("outbox", null, outboxValues(o))
        }
        bump()
    }

    /** Re-queues an existing failed/expired message with a freshly built envelope. */
    fun requeue(msgId: String, o: OutboxRow) {
        tx {
            val cv = ContentValues()
            cv.put("state", MsgState.QUEUED.name)
            db.update("messages", cv, "id = ?", arrayOf(msgId))
            db.insertWithOnConflict("outbox", null, outboxValues(o), SQLiteDatabase.CONFLICT_REPLACE)
        }
        bump()
    }

    /**
     * Atomically records a received message together with its dedup record.
     * Returns false if this (peer, id) pair was already processed.
     */
    fun insertIncoming(m: Message): Boolean {
        val isNew = tx {
            val p = ContentValues()
            p.put("peer_id", m.peerId)
            p.put("msg_id", m.id)
            p.put("at", m.receivedAt ?: m.createdAt)
            val r = db.insertWithOnConflict("processed", null, p, SQLiteDatabase.CONFLICT_IGNORE)
            if (r == -1L) {
                false
            } else {
                db.insertWithOnConflict("messages", null, messageValues(m), SQLiteDatabase.CONFLICT_IGNORE)
                true
            }
        }
        if (isNew) bump()
        return isNew
    }

    fun markSending(msgId: String) {
        val cv = ContentValues()
        cv.put("state", MsgState.SENDING.name)
        db.update("messages", cv, "id = ? AND state = ?", arrayOf(msgId, MsgState.QUEUED.name))
        bump()
    }

    fun markDelivered(peerId: String, ids: List<String>) {
        tx {
            for (id in ids) {
                val cv = ContentValues()
                cv.put("state", MsgState.DELIVERED.name)
                db.update(
                    "messages", cv,
                    "id = ? AND peer_id = ? AND direction = 1 AND state IN ('QUEUED','SENDING')",
                    arrayOf(id, peerId)
                )
                db.delete("outbox", "msg_id = ? AND peer_id = ?", arrayOf(id, peerId))
            }
        }
        bump()
    }

    fun markReadByPeer(peerId: String, ids: List<String>, now: Long) {
        tx {
            for (id in ids) {
                val cv = ContentValues()
                cv.put("read_at", now)
                db.update("messages", cv, "id = ? AND peer_id = ? AND direction = 1", arrayOf(id, peerId))
            }
        }
        bump()
    }

    /** Marks all unread incoming messages read and returns the ids that changed. */
    fun markConversationRead(peerId: String): List<String> {
        val ids = ArrayList<String>()
        tx {
            db.rawQuery("SELECT id FROM messages WHERE peer_id = ? AND direction = 0 AND read = 0", arrayOf(peerId)).use { c ->
                while (c.moveToNext()) ids.add(c.getString(0))
            }
            if (ids.isNotEmpty()) {
                val cv = ContentValues()
                cv.put("read", 1)
                db.update("messages", cv, "peer_id = ? AND direction = 0 AND read = 0", arrayOf(peerId))
            }
        }
        if (ids.isNotEmpty()) bump()
        return ids
    }

    fun setPinned(id: String, pinned: Boolean) {
        val cv = ContentValues()
        cv.put("pinned", if (pinned) 1 else 0)
        db.update("messages", cv, "id = ?", arrayOf(id))
        bump()
    }

    fun deleteMessage(id: String) {
        db.delete("messages", "id = ?", arrayOf(id)) // outbox row cascades
        bump()
    }

    fun deleteIncoming(peerId: String, id: String) {
        db.delete("messages", "id = ? AND peer_id = ? AND direction = 0", arrayOf(id, peerId))
        bump()
    }

    fun clearConversation(peerId: String) {
        tx {
            db.delete("outbox", "peer_id = ?", arrayOf(peerId))
            db.delete("messages", "peer_id = ?", arrayOf(peerId))
        }
        bump()
    }

    fun messageCount(): Int =
        db.rawQuery("SELECT COUNT(*) FROM messages", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    // ---------------------------------------------------------------- outbox

    private fun outboxValues(o: OutboxRow): ContentValues {
        val cv = ContentValues()
        cv.put("msg_id", o.msgId)
        cv.put("peer_id", o.peerId)
        cv.put("envelope", o.envelope)
        cv.put("attempts", o.attempts)
        cv.put("next_attempt_at", o.nextAttemptAt)
        cv.put("created_at", o.createdAt)
        cv.put("expires_at", o.expiresAt)
        cv.put("last_error", o.lastError)
        return cv
    }

    private val outboxCols = "msg_id, peer_id, envelope, attempts, next_attempt_at, created_at, expires_at, last_error"

    private fun readOutbox(c: Cursor) = OutboxRow(
        c.getString(0), c.getString(1), c.getBlob(2), c.getInt(3), c.getLong(4), c.getLong(5), c.getLong(6),
        if (c.isNull(7)) null else c.getString(7)
    )

    fun dueOutbox(now: Long, limit: Int = 50): List<OutboxRow> =
        db.rawQuery(
            "SELECT $outboxCols FROM outbox WHERE next_attempt_at <= ? ORDER BY created_at ASC LIMIT ?",
            arrayOf(now.toString(), limit.toString())
        ).use { c ->
            val out = ArrayList<OutboxRow>()
            while (c.moveToNext()) out.add(readOutbox(c))
            out
        }

    fun outboxFor(peerId: String): List<OutboxRow> =
        db.rawQuery("SELECT $outboxCols FROM outbox WHERE peer_id = ? ORDER BY created_at ASC", arrayOf(peerId)).use { c ->
            val out = ArrayList<OutboxRow>()
            while (c.moveToNext()) out.add(readOutbox(c))
            out
        }

    fun outboxPeers(): List<String> =
        db.rawQuery("SELECT DISTINCT peer_id FROM outbox", null).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out.add(c.getString(0))
            out
        }

    fun outboxCount(peerId: String? = null): Int {
        val sql = if (peerId == null) "SELECT COUNT(*) FROM outbox" else "SELECT COUNT(*) FROM outbox WHERE peer_id = ?"
        return db.rawQuery(sql, if (peerId == null) null else arrayOf(peerId)).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun updateOutbox(msgId: String, attempts: Int, nextAt: Long, error: String?) {
        val cv = ContentValues()
        cv.put("attempts", attempts)
        cv.put("next_attempt_at", nextAt)
        cv.put("last_error", error)
        db.update("outbox", cv, "msg_id = ?", arrayOf(msgId))
    }

    fun resetOutboxNext(peerId: String, now: Long) {
        val cv = ContentValues()
        cv.put("next_attempt_at", now)
        db.update("outbox", cv, "peer_id = ?", arrayOf(peerId))
    }

    /** Marks messages whose outbox job passed its expiry as EXPIRED and removes the job. Returns count. */
    fun expireOutbox(now: Long): Int {
        var n = 0
        tx {
            val ids = ArrayList<String>()
            db.rawQuery("SELECT msg_id FROM outbox WHERE expires_at <= ?", arrayOf(now.toString())).use { c ->
                while (c.moveToNext()) ids.add(c.getString(0))
            }
            for (id in ids) {
                val cv = ContentValues()
                cv.put("state", MsgState.EXPIRED.name)
                db.update("messages", cv, "id = ? AND state IN ('QUEUED','SENDING')", arrayOf(id))
                db.delete("outbox", "msg_id = ?", arrayOf(id))
                n++
            }
        }
        if (n > 0) bump()
        return n
    }

    /** Permanent failure for everything still queued to a peer (e.g. contact removed/blocked). */
    fun failOutboxForPeer(peerId: String) {
        tx {
            val cv = ContentValues()
            cv.put("state", MsgState.FAILED.name)
            db.update("messages", cv, "peer_id = ? AND direction = 1 AND state IN ('QUEUED','SENDING')", arrayOf(peerId))
            db.delete("outbox", "peer_id = ?", arrayOf(peerId))
        }
        bump()
    }

    fun cancelOutbox(msgId: String) {
        db.delete("outbox", "msg_id = ?", arrayOf(msgId))
    }


    // ---------------------------------------------------------------- transfers

    private val trCols =
        "id, peer_id, outgoing, name, mime, size, chunk_size, chunks, sha256, key, state, file_name, done_chunks, bitmap, updated_at, error"

    private fun readTransfer(c: Cursor): Transfer? {
        val id = c.getString(0)
        val key = try {
            local.open(c.getBlob(9), id.toByteArray(Charsets.UTF_8))
        } catch (e: Exception) {
            return null
        }
        return Transfer(
            id = id,
            peerId = c.getString(1),
            outgoing = c.getInt(2) == 1,
            name = c.getString(3),
            mime = c.getString(4),
            size = c.getLong(5),
            chunkSize = c.getInt(6),
            chunks = c.getInt(7),
            sha256 = c.getString(8),
            key = key,
            state = TransferState.valueOf(c.getString(10)),
            fileName = if (c.isNull(11)) null else c.getString(11),
            doneChunks = c.getInt(12),
            bitmap = if (c.isNull(13)) null else c.getBlob(13),
            updatedAt = c.getLong(14),
            error = if (c.isNull(15)) null else c.getString(15),
        )
    }

    private fun transferValues(t: Transfer): ContentValues {
        val cv = ContentValues()
        cv.put("id", t.id)
        cv.put("peer_id", t.peerId)
        cv.put("outgoing", if (t.outgoing) 1 else 0)
        cv.put("name", t.name)
        cv.put("mime", t.mime)
        cv.put("size", t.size)
        cv.put("chunk_size", t.chunkSize)
        cv.put("chunks", t.chunks)
        cv.put("sha256", t.sha256)
        cv.put("key", local.seal(t.key, t.id.toByteArray(Charsets.UTF_8)))
        cv.put("state", t.state.name)
        cv.put("file_name", t.fileName)
        cv.put("done_chunks", t.doneChunks)
        cv.put("bitmap", t.bitmap)
        cv.put("updated_at", t.updatedAt)
        cv.put("error", t.error)
        return cv
    }

    fun transfer(id: String): Transfer? =
        db.rawQuery("SELECT $trCols FROM transfers WHERE id = ?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) readTransfer(c) else null
        }

    fun transfersForPeer(peerId: String): List<Transfer> =
        db.rawQuery("SELECT $trCols FROM transfers WHERE peer_id = ?", arrayOf(peerId)).use { c ->
            val out = ArrayList<Transfer>()
            while (c.moveToNext()) readTransfer(c)?.let { out.add(it) }
            out
        }

    fun transfersInStates(states: List<TransferState>): List<Transfer> {
        val marks = states.joinToString(",") { "?" }
        return db.rawQuery(
            "SELECT $trCols FROM transfers WHERE state IN ($marks)",
            states.map { it.name }.toTypedArray()
        ).use { c ->
            val out = ArrayList<Transfer>()
            while (c.moveToNext()) readTransfer(c)?.let { out.add(it) }
            out
        }
    }

    fun allTransfers(): List<Transfer> =
        db.rawQuery("SELECT $trCols FROM transfers", null).use { c ->
            val out = ArrayList<Transfer>()
            while (c.moveToNext()) readTransfer(c)?.let { out.add(it) }
            out
        }

    fun transferFileNames(): Set<String> =
        db.rawQuery("SELECT file_name FROM transfers WHERE file_name IS NOT NULL", null).use { c ->
            val out = HashSet<String>()
            while (c.moveToNext()) out.add(c.getString(0))
            out
        }

    /** Atomically persists an outgoing file offer: message row, outbox job and transfer row. */
    fun insertOutgoingFile(m: Message, o: OutboxRow, t: Transfer) {
        tx {
            db.insertOrThrow("messages", null, messageValues(m))
            db.insertOrThrow("outbox", null, outboxValues(o))
            db.insertOrThrow("transfers", null, transferValues(t))
        }
        bump()
    }

    /** Atomically persists a received file offer with its dedup record. False if already processed. */
    fun insertIncomingFile(m: Message, t: Transfer): Boolean {
        val isNew = tx {
            val p = ContentValues()
            p.put("peer_id", m.peerId)
            p.put("msg_id", m.id)
            p.put("at", m.receivedAt ?: m.createdAt)
            val r = db.insertWithOnConflict("processed", null, p, SQLiteDatabase.CONFLICT_IGNORE)
            if (r == -1L) {
                false
            } else {
                db.insertWithOnConflict("messages", null, messageValues(m), SQLiteDatabase.CONFLICT_IGNORE)
                db.insertWithOnConflict("transfers", null, transferValues(t), SQLiteDatabase.CONFLICT_IGNORE)
                true
            }
        }
        if (isNew) bump()
        return isNew
    }

    fun setTransferState(id: String, state: TransferState, error: String?, now: Long) {
        val cv = ContentValues()
        cv.put("state", state.name)
        cv.put("error", error)
        cv.put("updated_at", now)
        db.update("transfers", cv, "id = ?", arrayOf(id))
        bump()
    }

    fun setTransferFile(id: String, fileName: String?) {
        val cv = ContentValues()
        cv.put("file_name", fileName)
        db.update("transfers", cv, "id = ?", arrayOf(id))
        bump()
    }

    fun saveTransferProgress(id: String, done: Int, bitmap: ByteArray?, now: Long) {
        val cv = ContentValues()
        cv.put("done_chunks", done)
        cv.put("bitmap", bitmap)
        cv.put("updated_at", now)
        db.update("transfers", cv, "id = ?", arrayOf(id))
    }

    /** Clears progress so a failed incoming transfer can be requested again from the start. */
    fun resetTransfer(id: String, now: Long) {
        val cv = ContentValues()
        cv.put("state", TransferState.OFFERED.name)
        cv.put("done_chunks", 0)
        cv.putNull("bitmap")
        cv.putNull("error")
        cv.put("updated_at", now)
        db.update("transfers", cv, "id = ?", arrayOf(id))
        bump()
    }

    /** Marks never-finished transfers older than [before] as expired; returns their rows (files must be deleted by the caller). */
    fun expireTransfers(before: Long, now: Long): List<Transfer> {
        val expired = transfersInStates(listOf(TransferState.OFFERED, TransferState.ACTIVE)).filter { it.updatedAt < before }
        if (expired.isEmpty()) return expired
        tx {
            for (t in expired) {
                val cv = ContentValues()
                cv.put("state", TransferState.EXPIRED.name)
                cv.put("error", "Expired")
                cv.put("updated_at", now)
                db.update("transfers", cv, "id = ?", arrayOf(t.id))
            }
        }
        bump()
        return expired
    }

    // ---------------------------------------------------------------- retention

    /** Deletes messages older than [before] that are not waiting in the outbox, plus stale dedup records. */
    fun purge(before: Long, dedupBefore: Long): Int {
        var n = 0
        tx {
            n = db.delete("messages", "created_at < ? AND id NOT IN (SELECT msg_id FROM outbox)", arrayOf(before.toString()))
            db.delete("processed", "at < ?", arrayOf(dedupBefore.toString()))
        }
        if (n > 0) bump()
        return n
    }

    fun pruneProcessed(dedupBefore: Long) {
        db.delete("processed", "at < ?", arrayOf(dedupBefore.toString()))
    }

    // ---------------------------------------------------------------- settings

    fun allSettings(): Map<String, String> =
        db.rawQuery("SELECT key, value FROM settings", null).use { c ->
            val m = HashMap<String, String>()
            while (c.moveToNext()) m[c.getString(0)] = c.getString(1)
            m
        }

    fun putSettings(values: Map<String, String>) {
        tx {
            for ((k, v) in values) {
                val cv = ContentValues()
                cv.put("key", k)
                cv.put("value", v)
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
        }
    }
}
