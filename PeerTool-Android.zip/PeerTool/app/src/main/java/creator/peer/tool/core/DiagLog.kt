package creator.peer.tool.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * In-memory diagnostics ring buffer. Never receives message content, keys or credentials;
 * peer IDs are shortened. Cleared when the process dies.
 */
class DiagLog(private val max: Int = 200) {
    private val buf = ArrayDeque<String>()
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines

    @Synchronized
    fun add(line: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        buf.addLast("$ts $line")
        while (buf.size > max) buf.removeFirst()
        _lines.value = buf.toList()
    }

    companion object {
        fun short(id: String?): String = if (id == null) "-" else if (id.length > 8) id.substring(0, 8) + "…" else id
    }
}
