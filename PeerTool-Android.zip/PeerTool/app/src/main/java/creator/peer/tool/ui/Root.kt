package creator.peer.tool.ui

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.os.SystemClock
import android.view.WindowManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.material3.OutlinedButton
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.platform.LocalContext
import creator.peer.tool.crypto.PeerCrypto
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.storage.TextLimits
import creator.peer.tool.ui.theme.PeerToolTheme
import kotlinx.coroutines.launch

enum class SettingsPage { MAIN, PROFILE, PRIVACY, NETWORK, NOTIFICATIONS, STORAGE, APPEARANCE, OUTBOX, DIAGNOSTICS, ABOUT }

sealed interface Route {
    data object Home : Route
    data class Chat(val peerId: String) : Route
    data object AddContact : Route
    data object MyIdentity : Route
    data class ContactDetail(val peerId: String) : Route
    data class Settings(val page: SettingsPage) : Route
}

class Nav(val stack: SnapshotStateList<Route>) {
    val current: Route get() = stack.last()
    fun push(r: Route) {
        if (stack.last() != r) stack.add(r)
    }
    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }
    fun popToHome() {
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
    }
}

@Composable
fun PeerToolRoot(c: AppContainer) {
    val settings by c.settings.flow.collectAsStateWithLifecycle()
    val ready by c.ready.collectAsStateWithLifecycle()
    val identity by c.identity.collectAsStateWithLifecycle()
    val activity = LocalContext.current as? Activity
    val secure = settings.blockScreenshots || settings.appLock
    LaunchedEffect(secure) {
        val w = activity?.window
        if (w != null) {
            if (secure) w.addFlags(WindowManager.LayoutParams.FLAG_SECURE) else w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    PeerToolTheme(settings.theme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when {
                !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                identity == null -> OnboardingFlow(c)
                else -> AppLockGate(settings.appLock) { AppNav(c) }
            }
        }
    }
}

/**
 * Optional app lock: asks for the phone's own screen-lock credential on cold start and after the app
 * has been in the background for more than 30 seconds. The app UI stays composed underneath (so you keep your place)
 * but is fully covered while locked.
 */
@Composable
fun AppLockGate(enabled: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var locked by remember { mutableStateOf(enabled) }
    var awaiting by remember { mutableStateOf(false) }
    var lastStop by remember { mutableLongStateOf(0L) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        awaiting = false
        if (r.resultCode == Activity.RESULT_OK) locked = false
    }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        if (!awaiting) lastStop = SystemClock.elapsedRealtime()
    }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        if (enabled && !awaiting && lastStop != 0L && SystemClock.elapsedRealtime() - lastStop > 30_000L) locked = true
    }
    LaunchedEffect(enabled) {
        if (!enabled) locked = false
    }
    val prompt = {
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val i = km?.createConfirmDeviceCredentialIntent("Unlock PeerTool", null)
        if (i == null) {
            locked = false
        } else {
            awaiting = true
            launcher.launch(i)
        }
    }
    Box(Modifier.fillMaxSize()) {
        content()
        if (locked && enabled) {
            LaunchedEffect(Unit) { prompt() }
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                ) {
                    Text("PeerTool is locked", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { prompt() }) { Text("Unlock") }
                }
            }
        }
    }
}

@Composable
fun AppNav(c: AppContainer) {
    val stack = remember { mutableStateListOf<Route>(Route.Home) }
    val nav = remember { Nav(stack) }
    BackHandler(enabled = stack.size > 1) { nav.pop() }

    val open by c.openChat.collectAsStateWithLifecycle()
    LaunchedEffect(open) {
        val id = open
        if (id != null) {
            nav.popToHome()
            nav.push(Route.Chat(id))
            c.openChat.value = null
        }
    }
    val link by c.pendingLink.collectAsStateWithLifecycle()
    LaunchedEffect(link) {
        if (link != null) nav.push(Route.AddContact)
    }

    when (val r = nav.current) {
        Route.Home -> HomeScreen(c, nav)
        is Route.Chat -> ChatScreen(c, r.peerId, nav)
        Route.AddContact -> AddContactScreen(c, nav)
        Route.MyIdentity -> MyIdentityScreen(c, nav)
        is Route.ContactDetail -> ContactDetailScreen(c, r.peerId, nav)
        is Route.Settings -> SettingsScreens(c, r.page, nav)
    }
}

// ------------------------------------------------------------------ onboarding

@Composable
fun OnboardingFlow(c: AppContainer) {
    var step by rememberSaveable { mutableStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var prefix by rememberSaveable { mutableStateOf("") }
    var attempts by remember { mutableLongStateOf(0L) }
    val cancelFlag = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    val scope = rememberCoroutineScope()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        if (step == 0) {
            Avatar("P", 72.dp, "peertool")
            Spacer(Modifier.height(24.dp))
            Text("Welcome to PeerTool", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Text(
                "Private messages that go straight from your phone to your contact's phone — over the internet or, when you're close, offline via Bluetooth/Wi-Fi.",
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(20.dp))
            Bullet("Messages are end-to-end encrypted and signed on your device.")
            Bullet("Your identity is a key pair created here. There is no account and no phone number.")
            Bullet("Both people need the app running to talk live; unsent messages wait in a queue and retry.")
            Bullet("End-to-end encryption does not hide who is online, IP addresses, timing or message sizes from the network and the signaling server.")
            Spacer(Modifier.height(28.dp))
            Button(onClick = { step = 1 }, modifier = Modifier.fillMaxWidth()) { Text("Get started") }
        } else {
            Text("Create your identity", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            Text(
                "Pick a display name. Contacts see it when you connect. Your keys are generated now and stay on this device.",
                style = MaterialTheme.typography.bodyLarge,
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { if (it.length <= TextLimits.NAME) name = it },
                label = { Text("Display name") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            val prefixOk = prefix.isEmpty() || PeerCrypto.isValidVanityPrefix(prefix)
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it.lowercase().take(4) },
                label = { Text("Custom ID letters (optional)") },
                supportingText = {
                    Text("Your ID will start with “pt” + these letters (a–z, 2–7, max 4). 2 letters ≈ seconds, 3 ≈ a minute or two. Leave empty for a random ID.")
                },
                isError = !prefixOk,
                singleLine = true,
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    busy = true
                    cancelFlag.set(false)
                    attempts = 0
                    scope.launch {
                        val clean = creator.peer.tool.core.TextSafety.sanitizeName(name).ifEmpty { "PeerTool user" }
                        val keys = if (prefix.isNotEmpty()) c.generateVanity(prefix, { n -> attempts = n }, { cancelFlag.get() }) else null
                        if (prefix.isNotEmpty() && keys == null) {
                            busy = false
                            return@launch
                        }
                        c.createIdentity(clean, keys)
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                },
                enabled = !busy && name.isNotBlank() && prefixOk,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (busy) CircularProgressIndicator(Modifier.height(20.dp)) else Text("Create identity")
            }
            if (busy && prefix.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Searching… $attempts keys tried", style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { cancelFlag.set(true) }) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun Bullet(text: String) {
    Text("•  $text", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 4.dp))
}
