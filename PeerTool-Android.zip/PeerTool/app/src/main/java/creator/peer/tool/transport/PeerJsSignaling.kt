package creator.peer.tool.transport

import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.Hex
import creator.peer.tool.core.Ids
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class SignalingConfig(
    val host: String,
    val port: Int,
    val path: String,
    val key: String,
    val secure: Boolean,
) {
    fun url(id: String, token: String): String {
        var p = path.trim()
        if (!p.startsWith("/")) p = "/$p"
        if (!p.endsWith("/")) p = "$p/"
        val scheme = if (secure) "wss" else "ws"
        return "$scheme://$host:$port${p}peerjs?key=$key&id=$id&token=$token"
    }
}

interface SignalingListener {
    fun onOpen()
    fun onMessage(type: String, src: String, payload: JSONObject)
    fun onClosed(reason: String)
}

/**
 * Minimal client for the PeerJS signaling protocol (WebSocket, JSON messages OFFER / ANSWER / CANDIDATE / HEARTBEAT).
 * It is only used to exchange WebRTC session descriptions; message content never passes through it.
 * Works with the public PeerJS cloud or any self-hosted peerjs-server.
 */
class PeerJsSignaling(
    private val diag: DiagLog,
    private val listener: SignalingListener,
) {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var opened = false
    @Volatile private var generation = 0
    private val lock = Any()

    val isOpen: Boolean get() = opened && socket != null

    fun open(cfg: SignalingConfig, id: String) {
        close()
        val gen: Int
        synchronized(lock) {
            generation++
            gen = generation
        }
        val token = Hex.encode(Ids.randomBytes(8))
        val req = try {
            Request.Builder().url(cfg.url(id, token)).build()
        } catch (e: IllegalArgumentException) {
            listener.onClosed("Invalid signaling URL")
            return
        }
        socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // PeerJS server sends {"type":"OPEN"} when the ID is registered.
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation || text.length > 65_536) return
                try {
                    val o = JSONObject(text)
                    when (val type = o.optString("type")) {
                        "OPEN" -> {
                            opened = true
                            listener.onOpen()
                        }
                        "ID-TAKEN" -> listener.onClosed("ID already registered on signaling server")
                        "ERROR" -> listener.onClosed("Signaling error")
                        "OFFER", "ANSWER", "CANDIDATE", "LEAVE", "EXPIRE" -> {
                            val src = o.optString("src", "")
                            val payload = o.optJSONObject("payload") ?: JSONObject()
                            listener.onMessage(type, src, payload)
                        }
                        else -> Unit
                    }
                } catch (e: Exception) {
                    diag.add("signaling: bad message")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen != generation) return
                opened = false
                listener.onClosed("Signaling closed ($code)")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen != generation) return
                opened = false
                listener.onClosed("Signaling failed: ${t.javaClass.simpleName}")
            }
        })
    }

    fun send(type: String, dst: String, payload: JSONObject?): Boolean {
        val s = socket ?: return false
        if (!opened) return false
        val o = JSONObject()
        o.put("type", type)
        o.put("dst", dst)
        if (payload != null) o.put("payload", payload)
        return s.send(o.toString())
    }

    fun heartbeat() {
        val s = socket ?: return
        if (opened) s.send("{\"type\":\"HEARTBEAT\"}")
    }

    fun close() {
        synchronized(lock) { generation++ }
        opened = false
        socket?.close(1000, "bye")
        socket = null
    }
}
