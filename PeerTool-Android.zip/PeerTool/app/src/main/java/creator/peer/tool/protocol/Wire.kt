package creator.peer.tool.protocol

import creator.peer.tool.core.B64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.ByteBuffer

object Kind {
    const val MSG = "msg"
    const val REQ = "req"
    const val ACC = "acc"
    const val CHAL = "chal"
    const val RESP = "resp"
    const val CHUNK = "chunk"
    val all = setOf(MSG, REQ, ACC, CHAL, RESP, CHUNK)
}

object Limits {
    const val PROTOCOL_VERSION = 1
    const val MAX_ENVELOPE_BYTES = 65_536
    const val MAX_TEXT_BYTES = 8_000
    const val MAX_IDS_PER_RECEIPT = 100
    const val CLOCK_SKEW_MS = 10 * 60_000L
    const val MAX_MESSAGE_AGE_MS = 8 * 24 * 3_600_000L
    const val MAX_NAME_CHARS = 40
    const val MAX_FIELD = 64
    const val CHUNK_SIZE = 16_384
    const val MAX_FILE_BYTES = 100L * 1024 * 1024
    const val MAX_REQ_INDICES = 64
    const val MAX_EMOJI_CHARS = 16
    const val MAX_FILE_NAME = 120
}

/** Outer, transport-level envelope. Only [Kind.MSG] bodies are encrypted; the rest carry public data. */
class Envelope(
    val kind: String,
    val id: String,
    val from: String,
    val to: String,
    val ts: Long,
    val body: ByteArray,
    val sig: ByteArray? = null,
    val bundle: ByteArray? = null,
) {
    fun withSignature(signature: ByteArray): Envelope = Envelope(kind, id, from, to, ts, body, signature, bundle)
}

object WireCodec {
    fun encode(e: Envelope): ByteArray {
        val o = JSONObject()
        o.put("v", Limits.PROTOCOL_VERSION)
        o.put("k", e.kind)
        o.put("id", e.id)
        o.put("f", e.from)
        o.put("t", e.to)
        o.put("ts", e.ts)
        o.put("c", B64.enc(e.body))
        e.sig?.let { o.put("s", B64.enc(it)) }
        e.bundle?.let { o.put("b", B64.enc(it)) }
        return o.toString().toByteArray(Charsets.UTF_8)
    }

    /** Returns null for anything malformed, oversized or of an unknown version/kind. */
    fun decode(bytes: ByteArray): Envelope? {
        if (bytes.isEmpty() || bytes.size > Limits.MAX_ENVELOPE_BYTES) return null
        return try {
            val o = JSONObject(String(bytes, Charsets.UTF_8))
            if (o.getInt("v") != Limits.PROTOCOL_VERSION) return null
            val kind = o.getString("k")
            if (kind !in Kind.all) return null
            val id = o.getString("id")
            val from = o.getString("f")
            val to = o.optString("t", "")
            if (id.isEmpty() || id.length > Limits.MAX_FIELD) return null
            if (from.length > Limits.MAX_FIELD || to.length > Limits.MAX_FIELD) return null
            val body = B64.dec(o.getString("c"))
            val sig = if (o.has("s")) B64.dec(o.getString("s")) else null
            val bundle = if (o.has("b")) B64.dec(o.getString("b")) else null
            Envelope(kind, id, from, to, o.getLong("ts"), body, sig, bundle)
        } catch (e: Exception) {
            null
        }
    }

    /** Domain-separated bytes covered by the sender's signature. */
    fun signingInput(e: Envelope): ByteArray {
        val out = ByteArrayOutputStream()
        fun field(s: String) {
            out.write(s.toByteArray(Charsets.UTF_8))
            out.write(0)
        }
        field("PT1")
        field(e.kind)
        field(e.id)
        field(e.from)
        field(e.to)
        out.write(ByteBuffer.allocate(8).putLong(e.ts).array())
        out.write(0)
        out.write(e.body)
        return out.toByteArray()
    }

    /** Associated data bound into the hybrid encryption of a message body. */
    fun contextInfo(kind: String, id: String, from: String, to: String): ByteArray =
        "PT1|$kind|$id|$from|$to".toByteArray(Charsets.UTF_8)
}

/** Decrypted payload of a [Kind.MSG] envelope. */
sealed interface Inner {
    data class Text(val body: String, val replyTo: String?, val ts: Long) : Inner
    data class Ack(val ids: List<String>) : Inner
    data class Read(val ids: List<String>) : Inner
    data class Delete(val id: String) : Inner

    /** Offer of a file. The transfer id is the id of the envelope that carries this offer. [key] is the AES-256 chunk key. */
    class File(
        val name: String,
        val mime: String,
        val size: Long,
        val sha256: String,
        val chunkSize: Int,
        val key: ByteArray,
        val ts: Long,
    ) : Inner

    /** Receiver asks the sender for specific chunk indices. */
    data class FileReq(val id: String, val indices: List<Int>) : Inner
    data class FileDone(val id: String) : Inner
    data class FileCancel(val id: String, val reason: String) : Inner

    /** Empty [emoji] clears the reaction. */
    data class React(val id: String, val emoji: String) : Inner
}

object InnerCodec {
    fun encode(i: Inner): ByteArray {
        val o = JSONObject()
        when (i) {
            is Inner.Text -> {
                o.put("t", "text")
                o.put("b", i.body)
                o.put("ts", i.ts)
                if (i.replyTo != null) o.put("re", i.replyTo)
            }
            is Inner.Ack -> {
                o.put("t", "ack")
                o.put("i", JSONArray(i.ids))
            }
            is Inner.Read -> {
                o.put("t", "read")
                o.put("i", JSONArray(i.ids))
            }
            is Inner.Delete -> {
                o.put("t", "del")
                o.put("d", i.id)
            }
            is Inner.File -> {
                o.put("t", "file")
                o.put("n", i.name)
                o.put("m", i.mime)
                o.put("sz", i.size)
                o.put("h", i.sha256)
                o.put("cs", i.chunkSize)
                o.put("k", B64.enc(i.key))
                o.put("ts", i.ts)
            }
            is Inner.FileReq -> {
                o.put("t", "freq")
                o.put("d", i.id)
                o.put("i", JSONArray(i.indices))
            }
            is Inner.FileDone -> {
                o.put("t", "fdone")
                o.put("d", i.id)
            }
            is Inner.FileCancel -> {
                o.put("t", "fcancel")
                o.put("d", i.id)
                o.put("r", i.reason)
            }
            is Inner.React -> {
                o.put("t", "react")
                o.put("d", i.id)
                o.put("e", i.emoji)
            }
        }
        return o.toString().toByteArray(Charsets.UTF_8)
    }

    fun decode(bytes: ByteArray): Inner? {
        return try {
            val o = JSONObject(String(bytes, Charsets.UTF_8))
            when (o.getString("t")) {
                "text" -> {
                    val b = o.getString("b")
                    if (b.isBlank() || b.toByteArray(Charsets.UTF_8).size > Limits.MAX_TEXT_BYTES) return null
                    val re = o.optString("re", "")
                    if (re.length > Limits.MAX_FIELD) return null
                    Inner.Text(b, if (re.isEmpty()) null else re, o.optLong("ts", 0L))
                }
                "ack" -> Inner.Ack(readIds(o.getJSONArray("i")) ?: return null)
                "read" -> Inner.Read(readIds(o.getJSONArray("i")) ?: return null)
                "del" -> {
                    val d = o.getString("d")
                    if (d.isEmpty() || d.length > Limits.MAX_FIELD) return null
                    Inner.Delete(d)
                }
                "file" -> {
                    val name = o.getString("n")
                    val mime = o.getString("m")
                    val size = o.getLong("sz")
                    val h = o.getString("h")
                    val cs = o.getInt("cs")
                    val key = B64.dec(o.getString("k"))
                    if (name.isBlank() || name.length > Limits.MAX_FILE_NAME) return null
                    if (!MIME_REGEX.matches(mime)) return null
                    if (size < 1 || size > Limits.MAX_FILE_BYTES) return null
                    if (!HEX64.matches(h)) return null
                    if (cs != Limits.CHUNK_SIZE || key.size != 32) return null
                    Inner.File(name, mime, size, h, cs, key, o.optLong("ts", 0L))
                }
                "freq" -> {
                    val id = o.getString("d")
                    val arr = o.getJSONArray("i")
                    if (id.isEmpty() || id.length > Limits.MAX_FIELD) return null
                    if (arr.length() == 0 || arr.length() > Limits.MAX_REQ_INDICES) return null
                    val idx = ArrayList<Int>(arr.length())
                    for (k in 0 until arr.length()) {
                        val v = arr.getInt(k)
                        if (v < 0) return null
                        idx.add(v)
                    }
                    Inner.FileReq(id, idx)
                }
                "fdone" -> {
                    val id = o.getString("d")
                    if (id.isEmpty() || id.length > Limits.MAX_FIELD) return null
                    Inner.FileDone(id)
                }
                "fcancel" -> {
                    val id = o.getString("d")
                    if (id.isEmpty() || id.length > Limits.MAX_FIELD) return null
                    Inner.FileCancel(id, o.optString("r", "").take(80))
                }
                "react" -> {
                    val id = o.getString("d")
                    val e = o.optString("e", "")
                    if (id.isEmpty() || id.length > Limits.MAX_FIELD || e.length > Limits.MAX_EMOJI_CHARS) return null
                    Inner.React(id, e)
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private val MIME_REGEX = Regex("^[\\w.+-]{1,60}/[\\w.+-]{1,60}$")
    private val HEX64 = Regex("^[0-9a-f]{64}$")

    private fun readIds(arr: JSONArray): List<String>? {
        if (arr.length() == 0 || arr.length() > Limits.MAX_IDS_PER_RECEIPT) return null
        val out = ArrayList<String>(arr.length())
        for (k in 0 until arr.length()) {
            val s = arr.getString(k)
            if (s.isEmpty() || s.length > Limits.MAX_FIELD) return null
            out.add(s)
        }
        return out
    }
}

object NameBody {
    fun encode(name: String): ByteArray =
        JSONObject().put("n", name).toString().toByteArray(Charsets.UTF_8)

    fun decode(bytes: ByteArray): String {
        return try {
            JSONObject(String(bytes, Charsets.UTF_8)).optString("n", "")
        } catch (e: Exception) {
            ""
        }
    }
}

/** peertool://add?b=<base64url bundle>&n=<name> */
object ShareLink {
    private const val PREFIX = "peertool://add?"

    fun build(bundle: ByteArray, name: String): String =
        PREFIX + "b=" + B64.encUrl(bundle) + "&n=" + URLEncoder.encode(name, "UTF-8")

    fun parse(text: String): Pair<ByteArray, String>? {
        val t = text.trim()
        if (!t.startsWith(PREFIX) || t.length > 4096) return null
        return try {
            var bundle: ByteArray? = null
            var name = ""
            for (part in t.removePrefix(PREFIX).split("&")) {
                val i = part.indexOf('=')
                if (i <= 0) continue
                val k = part.substring(0, i)
                val v = part.substring(i + 1)
                when (k) {
                    "b" -> bundle = B64.decUrl(v)
                    "n" -> name = URLDecoder.decode(v, "UTF-8")
                }
            }
            val b = bundle ?: return null
            b to name
        } catch (e: Exception) {
            null
        }
    }
}
