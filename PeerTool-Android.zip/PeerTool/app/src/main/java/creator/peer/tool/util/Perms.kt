package creator.peer.tool.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object Perms {
    /** Runtime permissions needed by the Nearby (Bluetooth / Wi-Fi) transport on this Android version. */
    fun nearbyRequired(): List<String> {
        val out = ArrayList<String>()
        when {
            Build.VERSION.SDK_INT >= 33 -> {
                out.add(Manifest.permission.BLUETOOTH_SCAN)
                out.add(Manifest.permission.BLUETOOTH_ADVERTISE)
                out.add(Manifest.permission.BLUETOOTH_CONNECT)
                out.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            Build.VERSION.SDK_INT >= 31 -> {
                out.add(Manifest.permission.BLUETOOTH_SCAN)
                out.add(Manifest.permission.BLUETOOTH_ADVERTISE)
                out.add(Manifest.permission.BLUETOOTH_CONNECT)
                out.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            Build.VERSION.SDK_INT >= 29 -> out.add(Manifest.permission.ACCESS_FINE_LOCATION)
            else -> out.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        return out
    }

    fun missing(ctx: Context, perms: List<String>): List<String> =
        perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }

    fun notificationsGranted(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}
