package creator.peer.tool.messaging

import creator.peer.tool.transport.TransportKind

enum class ConnState { DISCOVERED, CONNECTING, CONNECTED, DEGRADED, RECONNECTING, DISCONNECTED, FAILED }

data class PeerConn(val state: ConnState, val transport: TransportKind? = null, val detail: String = "")

data class NearbyPeer(val key: String, val advertisedId: String, val kind: TransportKind)

internal class LinkRec(
    val id: String,
    val kind: TransportKind,
    var hint: String?,
    val incoming: Boolean,
    val createdAt: Long,
) {
    var up = false
    var authed = false
    var peerId: String? = null
    var bundle: ByteArray? = null
    var nonce: ByteArray? = null
    var challengeAt = 0L
    var missed = 0
    var rxWindowStart = 0L
    var rxCount = 0
    var chunkWindowStart = 0L
    var chunkCount = 0
}

internal class ConnectTrack {
    var attempts = 0
    var nextAllowedAt = 0L
    var lastFailureAt = 0L
    var lastDownAt = 0L
    var lastError = ""
}
