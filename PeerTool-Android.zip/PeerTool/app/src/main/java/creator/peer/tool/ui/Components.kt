package creator.peer.tool.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import creator.peer.tool.AppContainer
import creator.peer.tool.messaging.ConnState
import creator.peer.tool.messaging.PeerConn
import creator.peer.tool.storage.Contact
import creator.peer.tool.storage.ConversationSummary
import creator.peer.tool.storage.Message
import creator.peer.tool.transport.TransportKind
import creator.peer.tool.ui.theme.StatusColors
import java.text.DateFormat
import java.util.Date

// ---------------------------------------------------------------- data helpers

@Composable
fun rememberContacts(c: AppContainer): State<List<Contact>> {
    val flow = remember(c) { c.store.observe { c.store.contacts() } }
    return flow.collectAsStateWithLifecycle(initialValue = emptyList())
}

@Composable
fun rememberConversations(c: AppContainer): State<List<ConversationSummary>> {
    val flow = remember(c) { c.store.observe { c.store.conversations() } }
    return flow.collectAsStateWithLifecycle(initialValue = emptyList())
}

@Composable
fun rememberMessages(c: AppContainer, peerId: String): State<List<Message>> {
    val flow = remember(c, peerId) { c.store.observe { c.store.messagesFor(peerId) } }
    return flow.collectAsStateWithLifecycle(initialValue = emptyList())
}

// ---------------------------------------------------------------- formatting

fun connLabel(p: PeerConn?): String {
    if (p == null) return "Offline"
    val via = when (p.transport) {
        TransportKind.WEBRTC -> " · Internet"
        TransportKind.NEARBY -> " · Nearby"
        null -> ""
    }
    return when (p.state) {
        ConnState.DISCOVERED -> "Discovered nearby"
        ConnState.CONNECTING -> "Connecting$via…"
        ConnState.CONNECTED -> "Connected$via"
        ConnState.DEGRADED -> "Unstable$via"
        ConnState.RECONNECTING -> "Reconnecting…"
        ConnState.DISCONNECTED -> "Offline"
        ConnState.FAILED -> if (p.detail.isNotBlank()) "Failed · ${p.detail}" else "Connection failed"
    }
}

fun connColor(p: PeerConn?): Color = when (p?.state) {
    ConnState.CONNECTED -> StatusColors.connected
    ConnState.CONNECTING, ConnState.RECONNECTING -> StatusColors.connecting
    ConnState.DEGRADED -> StatusColors.degraded
    ConnState.FAILED -> StatusColors.failed
    ConnState.DISCOVERED -> StatusColors.discovered
    else -> StatusColors.idle
}

fun formatTime(ts: Long): String {
    val now = System.currentTimeMillis()
    val date = Date(ts)
    return if (now - ts < 20 * 3_600_000L) DateFormat.getTimeInstance(DateFormat.SHORT).format(date)
    else DateFormat.getDateInstance(DateFormat.MEDIUM).format(date)
}

fun formatFull(ts: Long): String = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ts))

fun copyToClipboard(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java) ?: return
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

// ---------------------------------------------------------------- widgets

private val avatarPalette = listOf(
    Color(0xFF5C6BC0), Color(0xFF00897B), Color(0xFFEF6C00), Color(0xFF8E24AA),
    Color(0xFF3949AB), Color(0xFF6D4C41), Color(0xFF00838F), Color(0xFFC2185B),
)

@Composable
fun Avatar(name: String, size: Dp = 44.dp, seed: String = name) {
    val color = avatarPalette[(seed.hashCode() and 0x7fffffff) % avatarPalette.size]
    val initial = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(color)
            .semantics { contentDescription = "Avatar for $name" },
        contentAlignment = Alignment.Center,
    ) {
        Text(initial, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
fun StatusDot(p: PeerConn?, size: Dp = 10.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(connColor(p))
            .semantics { contentDescription = connLabel(p) }
    )
}

@Composable
fun ConnBadge(p: PeerConn?, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        StatusDot(p, 8.dp)
        Spacer(Modifier.width(6.dp))
        Text(
            connLabel(p),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp),
    )
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier, action: @Composable (() -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            action()
        }
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = if (subtitle != null) ({ Text(subtitle) }) else null,
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange, enabled = enabled) },
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
