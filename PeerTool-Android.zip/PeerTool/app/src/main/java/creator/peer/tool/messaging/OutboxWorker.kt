package creator.peer.tool.messaging

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import creator.peer.tool.PeerToolApp
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

/**
 * Safety net for deferrable work: wakes the engine so pending outbox jobs are retried.
 * Android may delay or skip this under Doze / battery optimization; it never guarantees delivery.
 */
class OutboxWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as? PeerToolApp ?: return Result.success()
        val c = app.container
        if (!c.ready.value || c.engine.myPeerId() == null) return Result.success()
        c.engine.kick()
        delay(20_000) // give links a chance to come up and acks to return
        return Result.success()
    }

    companion object {
        private val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        fun schedulePeriodic(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<OutboxWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("outbox-periodic", ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun enqueueSoon(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<OutboxWorker>()
                .setConstraints(constraints)
                .setInitialDelay(30, TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork("outbox-soon", ExistingWorkPolicy.REPLACE, req)
        }
    }
}
