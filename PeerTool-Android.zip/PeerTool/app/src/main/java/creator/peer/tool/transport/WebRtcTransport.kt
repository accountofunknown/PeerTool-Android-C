package creator.peer.tool.transport

import android.content.Context
import creator.peer.tool.core.Backoff
import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.Hex
import creator.peer.tool.core.Ids
import creator.peer.tool.crypto.InviteCode
import creator.peer.tool.crypto.PeerCrypto
import creator.peer.tool.storage.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Internet transport: native WebRTC data channels, signaled through a PeerJS-protocol server
 * (public PeerJS cloud by default, self-hosted supported). Messages travel peer-to-peer (or via the
 * configured TURN relay, still end-to-end encrypted by the layer above).
 *
 * Observers are created through dynamic proxies so this class does not depend on the exact set of
 * abstract/default methods of the WebRTC observer interfaces in a given library build.
 */
class WebRtcTransport(
    private val context: Context,
    private val settings: () -> Settings,
    private val selfId: () -> String?,
    private val acceptFrom: (String) -> Boolean,
    private val diag: DiagLog,
) : Transport {

    override val kind = TransportKind.WEBRTC
    private val _info = MutableStateFlow(TransportInfo(TransportStatus.OFF))
    override val info: StateFlow<TransportInfo> = _info
    private val channel = Channel<TransportEvent>(Channel.UNLIMITED)
    override val events: ReceiveChannel<TransportEvent> = channel

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "peertool-webrtc") }
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())
    private val started = AtomicBoolean(false)
    private val signaling = PeerJsSignaling(diag, MainListener())
    private val inviteSig = PeerJsSignaling(diag, InviteListener())
    @Volatile private var inviteId: String? = null
    private var inviteAttempts = 0
    private var inviteJob: Job? = null

    private inner class MainListener : SignalingListener {
        override fun onOpen() = mainOpened()
        override fun onMessage(type: String, src: String, payload: JSONObject) = onSignal(type, src, payload, false)
        override fun onClosed(reason: String) = mainClosed(reason)
    }

    private inner class InviteListener : SignalingListener {
        override fun onOpen() {
            scope.launch {
                inviteAttempts = 0
                diag.add("webrtc: invite rendezvous open")
            }
        }
        override fun onMessage(type: String, src: String, payload: JSONObject) = onSignal(type, src, payload, true)
        override fun onClosed(reason: String) {
            scope.launch {
                val id = inviteId ?: return@launch
                if (!started.get() || ++inviteAttempts > 5) return@launch
                diag.add("webrtc: invite rendezvous lost, retrying")
                inviteJob?.cancel()
                inviteJob = launch {
                    delay(3_000)
                    if (inviteId == id) openInviteSocket(id)
                }
            }
        }
    }
    private val reconnectBackoff = Backoff(baseMs = 3_000, capMs = 120_000)
    private var reconnectAttempts = 0
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null

    private val byId = ConcurrentHashMap<String, RtcLink>()
    private val byRemote = ConcurrentHashMap<String, RtcLink>()
    private val offerRate = HashMap<String, Long>()

    private class RtcLink(
        val remote: String,
        val connId: String,
        val offerer: Boolean,
        val via: PeerJsSignaling,
        val invite: Boolean,
    ) {
        val linkId = (if (invite) "rtcinv:" else "rtc:") + "$remote:$connId"
        @Volatile var pc: PeerConnection? = null
        @Volatile var dc: DataChannel? = null
        @Volatile var remoteSet = false
        @Volatile var up = false
        @Volatile var closed = false
        val pending = ArrayList<IceCandidate>()
    }

    private val factory: PeerConnectionFactory by lazy {
        WebRtcUtil.ensureInit(context)
        PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    // ------------------------------------------------------------------ lifecycle

    override fun start() {
        if (!started.compareAndSet(false, true)) return
        _info.value = TransportInfo(TransportStatus.STARTING, "Connecting to signaling server")
        scope.launch {
            try {
                factory // force native init
            } catch (e: Throwable) {
                started.set(false)
                _info.value = TransportInfo(TransportStatus.ERROR, "WebRTC unavailable: ${e.javaClass.simpleName}")
                diag.add("webrtc: init failed ${e.javaClass.simpleName}")
                return@launch
            }
            openSignaling()
        }
    }

    override fun stop() {
        if (!started.compareAndSet(true, false)) {
            _info.value = TransportInfo(TransportStatus.OFF)
            return
        }
        heartbeatJob?.cancel()
        reconnectJob?.cancel()
        inviteJob?.cancel()
        inviteId = null
        signaling.close()
        inviteSig.close()
        scope.launch {
            for (l in byId.values.toList()) teardown(l, "transport stopped")
        }
        _info.value = TransportInfo(TransportStatus.OFF)
    }

    override fun kick() {
        if (!started.get()) return
        if (!signaling.isOpen) {
            reconnectAttempts = 0
            reconnectJob?.cancel()
            scope.launch { openSignaling() }
        }
    }

    private fun openSignaling() {
        if (!started.get()) return
        val id = selfId()
        if (id == null) {
            _info.value = TransportInfo(TransportStatus.ERROR, "No identity yet")
            return
        }
        val s = settings()
        if (s.sigHost.isBlank()) {
            _info.value = TransportInfo(TransportStatus.ERROR, "Signaling host not set")
            return
        }
        _info.value = TransportInfo(TransportStatus.STARTING, "Connecting to ${s.sigHost}")
        signaling.open(SignalingConfig(s.sigHost.trim(), s.sigPort, s.sigPath, s.sigKey.trim(), s.sigSecure), id)
    }

    private fun mainOpened() {
        scope.launch {
            reconnectAttempts = 0
            _info.value = TransportInfo(TransportStatus.READY, "Signaling connected")
            diag.add("webrtc: signaling open")
            heartbeatJob?.cancel()
            heartbeatJob = launch {
                while (started.get()) {
                    delay(5_000)
                    signaling.heartbeat()
                    inviteSig.heartbeat()
                }
            }
        }
    }

    private fun mainClosed(reason: String) {
        scope.launch {
            if (!started.get()) return@launch
            heartbeatJob?.cancel()
            _info.value = TransportInfo(TransportStatus.ERROR, reason)
            diag.add("webrtc: $reason")
            reconnectAttempts++
            if (reconnectAttempts > 8) {
                _info.value = TransportInfo(TransportStatus.ERROR, "$reason — will retry when the network changes")
                return@launch
            }
            val wait = reconnectBackoff.delayMs(reconnectAttempts)
            reconnectJob?.cancel()
            reconnectJob = launch {
                delay(wait)
                openSignaling()
            }
        }
    }

    // ------------------------------------------------------------------ invite rendezvous

    override fun openInvite(rendezvousId: String): Boolean {
        if (!started.get() || !InviteCode.isRendezvousId(rendezvousId)) return false
        inviteId = rendezvousId
        inviteAttempts = 0
        scope.launch { openInviteSocket(rendezvousId) }
        return true
    }

    private fun openInviteSocket(id: String) {
        val s = settings()
        inviteSig.open(SignalingConfig(s.sigHost.trim(), s.sigPort, s.sigPath, s.sigKey.trim(), s.sigSecure), id)
    }

    override fun closeInvite() {
        inviteId = null
        inviteJob?.cancel()
        inviteSig.close()
        scope.launch {
            for (l in byId.values.toList()) if (l.invite && !l.up) teardown(l, "invite closed")
        }
    }

    // ------------------------------------------------------------------ outgoing connections

    override fun connect(hint: String): Boolean {
        if (!started.get() || !signaling.isOpen) return false
        if (!(PeerCrypto.isValidPeerId(hint) || InviteCode.isRendezvousId(hint)) || hint == selfId()) return false
        val existing = byRemote[hint]
        if (existing != null && !existing.closed) return true
        scope.launch { startOffer(hint) }
        return true
    }

    private fun newConnId(): String = "pt_" + Hex.encode(Ids.randomBytes(6))

    private fun startOffer(remote: String) {
        val cur = byRemote[remote]
        if (cur != null && !cur.closed) return
        val link = RtcLink(remote, newConnId(), true, signaling, false)
        register(link)
        channel.trySend(TransportEvent.LinkConnecting(link.linkId, kind, remote, false))
        val pc = createPc(link)
        if (pc == null) {
            teardown(link, "could not create peer connection")
            return
        }
        link.pc = pc
        val dc = pc.createDataChannel("peertool", DataChannel.Init())
        if (dc == null) {
            teardown(link, "could not create data channel")
            return
        }
        attachChannel(link, dc)
        pc.createOffer(sdpObserver(
            onCreated = { sdp ->
                pc.setLocalDescription(sdpObserver(onSet = {
                    sendSdp("OFFER", link, pc.localDescription ?: sdp)
                }, onFailure = { e -> scope.launch { teardown(link, "setLocal failed: $e") } }), sdp)
            },
            onFailure = { e -> scope.launch { teardown(link, "createOffer failed: $e") } }
        ), MediaConstraints())
        watchTimeout(link)
    }

    private fun watchTimeout(link: RtcLink) {
        scope.launch {
            delay(25_000)
            if (!link.up && !link.closed) teardown(link, "connect timeout")
        }
    }

    private fun register(link: RtcLink) {
        byId[link.linkId] = link
        byRemote[link.remote] = link
    }

    // ------------------------------------------------------------------ signaling input

    private fun onSignal(type: String, src: String, payload: JSONObject, invite: Boolean) {
        scope.launch {
            try {
                handleSignal(type, src, payload, invite)
            } catch (e: Exception) {
                diag.add("webrtc: signal error ${e.javaClass.simpleName}")
            }
        }
    }

    private fun handleSignal(type: String, src: String, payload: JSONObject, invite: Boolean) {
        if (!(PeerCrypto.isValidPeerId(src) || InviteCode.isRendezvousId(src)) || src == selfId()) return
        val connId = payload.optString("connectionId", "")
        if (connId.isEmpty() || connId.length > 40) return
        when (type) {
            "OFFER" -> handleOffer(src, connId, payload, invite)
            "ANSWER" -> {
                val l = byRemote[src] ?: return
                if (!l.offerer || l.connId != connId || l.closed || l.remoteSet) return
                val sd = parseSdp(payload, "answer") ?: return
                val pc = l.pc ?: return
                pc.setRemoteDescription(sdpObserver(onSet = {
                    scope.launch { onRemoteSet(l) }
                }, onFailure = { e -> scope.launch { teardown(l, "setRemote failed: $e") } }), sd)
            }
            "CANDIDATE" -> {
                val l = byRemote[src] ?: return
                if (l.connId != connId || l.closed) return
                val c = payload.optJSONObject("candidate") ?: return
                val cand = IceCandidate(
                    c.optString("sdpMid", ""), c.optInt("sdpMLineIndex", 0), c.optString("candidate", "")
                )
                if (cand.sdp.isEmpty() || cand.sdp.length > 2048) return
                if (l.remoteSet) l.pc?.addIceCandidate(cand) else if (l.pending.size < 64) l.pending.add(cand)
            }
            "EXPIRE", "LEAVE" -> {
                val l = byRemote[src] ?: return
                if (!l.up) teardown(l, if (type == "EXPIRE") "peer not online" else "peer left")
            }
        }
    }

    private fun parseSdp(payload: JSONObject, expected: String): SessionDescription? {
        val o = payload.optJSONObject("sdp") ?: return null
        val sdp = o.optString("sdp", "")
        if (o.optString("type") != expected || sdp.isEmpty() || sdp.length > 32_768) return null
        return SessionDescription(SessionDescription.Type.fromCanonicalForm(expected), sdp)
    }

    private fun handleOffer(src: String, connId: String, payload: JSONObject, invite: Boolean) {
        if (!PeerCrypto.isValidPeerId(src)) return
        if (invite) {
            if (inviteId == null) return
        } else if (!settings().internetEnabled || !acceptFrom(src)) {
            return
        }
        val now = System.currentTimeMillis()
        val last = offerRate[src] ?: 0L
        if (now - last < 1_500) return
        offerRate[src] = now
        if (offerRate.size > 256) offerRate.clear()
        if (byId.size >= 24) return

        val sd = parseSdp(payload, "offer") ?: return
        val existing = byRemote[src]
        if (existing != null && !existing.closed) {
            if (existing.connId == connId) return
            if (!invite && !existing.up && existing.offerer) {
                // Glare: both sides offered. The lexicographically smaller ID keeps its offer.
                val me = selfId() ?: return
                if (me < src) return
            }
            teardown(existing, "replaced by new offer")
        }
        val link = RtcLink(src, connId, false, if (invite) inviteSig else signaling, invite)
        register(link)
        channel.trySend(TransportEvent.LinkConnecting(link.linkId, kind, src, true))
        val pc = createPc(link)
        if (pc == null) {
            teardown(link, "could not create peer connection")
            return
        }
        link.pc = pc
        pc.setRemoteDescription(sdpObserver(onSet = {
            scope.launch {
                onRemoteSet(link)
                pc.createAnswer(sdpObserver(
                    onCreated = { ans ->
                        pc.setLocalDescription(sdpObserver(onSet = {
                            sendSdp("ANSWER", link, pc.localDescription ?: ans)
                        }, onFailure = { e -> scope.launch { teardown(link, "setLocal failed: $e") } }), ans)
                    },
                    onFailure = { e -> scope.launch { teardown(link, "createAnswer failed: $e") } }
                ), MediaConstraints())
            }
        }, onFailure = { e -> scope.launch { teardown(link, "setRemote failed: $e") } }), sd)
        watchTimeout(link)
    }

    private fun onRemoteSet(l: RtcLink) {
        l.remoteSet = true
        val pc = l.pc ?: return
        for (c in l.pending) pc.addIceCandidate(c)
        l.pending.clear()
    }

    private fun sendSdp(type: String, link: RtcLink, sd: SessionDescription) {
        val sdp = JSONObject().put("type", sd.type.canonicalForm()).put("sdp", sd.description)
        val payload = JSONObject()
            .put("sdp", sdp)
            .put("type", "data")
            .put("connectionId", link.connId)
            .put("label", "peertool")
            .put("reliable", true)
            .put("serialization", "raw")
            .put("browser", "android")
        link.via.send(type, link.remote, payload)
    }

    // ------------------------------------------------------------------ peer connection plumbing

    private fun iceServers(): List<PeerConnection.IceServer> {
        val s = settings()
        val list = ArrayList<PeerConnection.IceServer>()
        if (s.stunUrl.isNotBlank()) {
            list.add(PeerConnection.IceServer.builder(s.stunUrl.trim()).createIceServer())
        }
        if (s.turnUrl.isNotBlank()) {
            list.add(
                PeerConnection.IceServer.builder(s.turnUrl.trim())
                    .setUsername(s.turnUser)
                    .setPassword(s.turnCred)
                    .createIceServer()
            )
        }
        return list
    }

    private fun createPc(link: RtcLink): PeerConnection? {
        val cfg = PeerConnection.RTCConfiguration(iceServers())
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val obs = proxyOf(PeerConnection.Observer::class.java) { name, args ->
            when (name) {
                "onIceCandidate" -> {
                    val c = args.getOrNull(0) as? IceCandidate
                    if (c != null) {
                        val cand = JSONObject()
                            .put("candidate", c.sdp)
                            .put("sdpMid", c.sdpMid ?: "")
                            .put("sdpMLineIndex", c.sdpMLineIndex)
                        val payload = JSONObject()
                            .put("candidate", cand)
                            .put("type", "data")
                            .put("connectionId", link.connId)
                        link.via.send("CANDIDATE", link.remote, payload)
                    }
                }
                "onDataChannel" -> {
                    val dc = args.getOrNull(0) as? DataChannel
                    if (dc != null) scope.launch { attachChannel(link, dc) }
                }
                "onConnectionChange" -> {
                    val st = args.getOrNull(0) as? PeerConnection.PeerConnectionState
                    when (st) {
                        PeerConnection.PeerConnectionState.FAILED,
                        PeerConnection.PeerConnectionState.CLOSED ->
                            scope.launch { teardown(link, "connection ${st.name.lowercase()}") }
                        PeerConnection.PeerConnectionState.DISCONNECTED -> scope.launch {
                            delay(15_000)
                            if (!link.closed && link.pc?.connectionState() != PeerConnection.PeerConnectionState.CONNECTED) {
                                teardown(link, "connection lost")
                            }
                        }
                        else -> Unit
                    }
                }
            }
        }
        return factory.createPeerConnection(cfg, obs)
    }

    private fun attachChannel(link: RtcLink, dc: DataChannel) {
        if (link.closed) {
            dc.close()
            return
        }
        link.dc = dc
        val obs = proxyOf(DataChannel.Observer::class.java) { name, args ->
            when (name) {
                "onStateChange" -> scope.launch {
                    when (dc.state()) {
                        DataChannel.State.OPEN -> markUp(link)
                        DataChannel.State.CLOSING, DataChannel.State.CLOSED -> teardown(link, "channel closed")
                        else -> Unit
                    }
                }
                "onMessage" -> {
                    val buf = args.getOrNull(0) as? DataChannel.Buffer
                    if (buf != null && buf.binary && !link.closed) {
                        val bb = buf.data
                        if (bb.remaining() in 1..70_000) {
                            val arr = ByteArray(bb.remaining())
                            bb.get(arr)
                            channel.trySend(TransportEvent.Data(link.linkId, kind, arr))
                        }
                    }
                }
            }
        }
        dc.registerObserver(obs)
        if (dc.state() == DataChannel.State.OPEN) markUp(link)
    }

    private fun markUp(link: RtcLink) {
        if (link.up || link.closed) return
        link.up = true
        channel.trySend(TransportEvent.LinkUp(link.linkId, kind, link.remote, !link.offerer))
    }

    private fun teardown(link: RtcLink, reason: String) {
        if (link.closed) return
        link.closed = true
        byId.remove(link.linkId)
        byRemote.remove(link.remote, link)
        try {
            link.dc?.close()
        } catch (_: Throwable) {
        }
        try {
            link.pc?.close()
        } catch (_: Throwable) {
        }
        try {
            link.dc?.dispose()
            link.pc?.dispose()
        } catch (_: Throwable) {
        }
        link.dc = null
        link.pc = null
        diag.add("webrtc: link ${DiagLog.short(link.remote)} down ($reason)")
        channel.trySend(TransportEvent.LinkDown(link.linkId, kind, reason))
    }

    // ------------------------------------------------------------------ data

    override fun send(linkId: String, bytes: ByteArray): Boolean {
        val l = byId[linkId] ?: return false
        val dc = l.dc ?: return false
        if (!l.up || l.closed || bytes.size > 60_000) return false
        return try {
            if (dc.state() != DataChannel.State.OPEN || dc.bufferedAmount() > 1_000_000L) false
            else dc.send(DataChannel.Buffer(ByteBuffer.wrap(bytes), true))
        } catch (e: Throwable) {
            false
        }
    }

    override fun close(linkId: String) {
        scope.launch { byId[linkId]?.let { teardown(it, "closed locally") } }
    }

    // ------------------------------------------------------------------ helpers

    private fun sdpObserver(
        onCreated: ((SessionDescription) -> Unit)? = null,
        onSet: (() -> Unit)? = null,
        onFailure: ((String) -> Unit)? = null,
    ): SdpObserver = proxyOf(SdpObserver::class.java) { name, args ->
        when (name) {
            "onCreateSuccess" -> (args.getOrNull(0) as? SessionDescription)?.let { onCreated?.invoke(it) }
            "onSetSuccess" -> onSet?.invoke()
            "onCreateFailure", "onSetFailure" -> onFailure?.invoke((args.getOrNull(0) as? String) ?: "unknown")
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> proxyOf(cls: Class<T>, handler: (String, Array<Any?>) -> Unit): T {
        val ih = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.getOrNull(0)
                "toString" -> "PeerToolObserver"
                else -> {
                    try {
                        handler(method.name, args ?: emptyArray())
                    } catch (e: Throwable) {
                        diag.add("webrtc: observer error ${e.javaClass.simpleName}")
                    }
                    null
                }
            }
        }
        return Proxy.newProxyInstance(cls.classLoader, arrayOf(cls), ih) as T
    }
}
