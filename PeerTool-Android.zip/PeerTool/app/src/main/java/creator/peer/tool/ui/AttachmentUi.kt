package creator.peer.tool.ui

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import creator.peer.tool.AppContainer
import creator.peer.tool.storage.Transfer
import creator.peer.tool.storage.TransferState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun decodeThumb(f: File, target: Int = 640): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap()
}

@Composable
private fun Thumbnail(file: File) {
    val bmp: State<ImageBitmap?> = produceState<ImageBitmap?>(null, file.path, file.lastModified()) {
        value = withContext(Dispatchers.IO) { decodeThumb(file) }
    }
    val b = bmp.value
    if (b != null) {
        Image(
            bitmap = b,
            contentDescription = "Image attachment",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp).clip(RoundedCornerShape(10.dp)).padding(bottom = 6.dp),
        )
    }
}

private fun stateLabel(t: Transfer, done: Int): String {
    val pct = if (t.chunks > 0) (done * 100L / t.chunks).toInt() else 0
    return if (t.outgoing) {
        when (t.state) {
            TransferState.OFFERED -> "Waiting for contact to accept"
            TransferState.ACTIVE -> "Sending $pct%"
            TransferState.DONE -> "Sent ✓"
            TransferState.CANCELLED -> t.error ?: "Cancelled"
            TransferState.FAILED -> "Failed" + (t.error?.let { " · $it" } ?: "")
            TransferState.EXPIRED -> t.error ?: "Expired"
        }
    } else {
        when (t.state) {
            TransferState.OFFERED -> "Not downloaded"
            TransferState.ACTIVE -> "Receiving $pct%"
            TransferState.DONE -> "Downloaded ✓"
            TransferState.CANCELLED -> t.error ?: "Cancelled"
            TransferState.FAILED -> "Failed" + (t.error?.let { " · $it" } ?: "")
            TransferState.EXPIRED -> t.error ?: "Expired"
        }
    }
}

/** Card shown inside a chat bubble for a file offer / transfer. [live] is the in-memory chunk count while moving. */
@Composable
fun AttachmentCard(c: AppContainer, t: Transfer, live: Int?, onMessage: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val done = if (t.state == TransferState.ACTIVE) (live ?: t.doneChunks) else if (t.state == TransferState.DONE) t.chunks else t.doneChunks
    val file = remember(t.id, t.state, t.fileName) { c.engine.fileFor(t) }
    val isImage = t.mime.startsWith("image/")
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(t.mime)) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = c.engine.exportFile(t, uri)
                onMessage(if (ok) "Saved" else "Could not save the file")
            }
        }
    }

    Column(Modifier.widthIn(min = 220.dp)) {
        if (isImage && file != null) Thumbnail(file)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isImage) "\uD83D\uDDBC" else "\uD83D\uDCC4", fontSize = 26.sp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(t.name, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    formatSize(t.size) + " · " + stateLabel(t, done),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (t.state == TransferState.ACTIVE) {
            LinearProgressIndicator(
                progress = { if (t.chunks > 0) done.toFloat() / t.chunks else 0f },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            when {
                !t.outgoing && t.state == TransferState.OFFERED -> {
                    TextButton(onClick = { scope.launch { c.engine.acceptTransfer(t.id) } }) { Text("Download") }
                    TextButton(onClick = { scope.launch { c.engine.cancelTransfer(t.id) } }) { Text("Decline") }
                }
                !t.outgoing && t.state == TransferState.FAILED && t.error?.startsWith("Larger") != true -> {
                    TextButton(onClick = { scope.launch { c.engine.acceptTransfer(t.id) } }) { Text("Retry") }
                }
                t.state == TransferState.ACTIVE || (t.outgoing && t.state == TransferState.OFFERED) -> {
                    TextButton(onClick = { scope.launch { c.engine.cancelTransfer(t.id) } }) { Text("Cancel") }
                }
            }
            if (file != null && (t.state == TransferState.DONE)) {
                TextButton(onClick = {
                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, t.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try {
                        ctx.startActivity(i)
                    } catch (e: Exception) {
                        onMessage("No app can open this file type")
                    }
                }) { Text("Open") }
                TextButton(onClick = { saveLauncher.launch(t.name) }) { Text("Save as…") }
            }
        }
        if (!t.outgoing && t.state == TransferState.FAILED && t.error?.startsWith("Larger") == true) {
            Text(
                "Raise the limit in Settings → Storage, then ask your contact to send it again.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
