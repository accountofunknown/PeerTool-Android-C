package creator.peer.tool.crypto

import creator.peer.tool.core.Base32
import com.google.crypto.tink.BinaryKeysetReader
import com.google.crypto.tink.BinaryKeysetWriter
import com.google.crypto.tink.CleartextKeysetHandle
import com.google.crypto.tink.HybridDecrypt
import com.google.crypto.tink.HybridEncrypt
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.KeysetHandle
import com.google.crypto.tink.PublicKeySign
import com.google.crypto.tink.PublicKeyVerify
import com.google.crypto.tink.RegistryConfiguration
import com.google.crypto.tink.hybrid.HybridConfig
import com.google.crypto.tink.signature.SignatureConfig
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.MessageDigest

/**
 * Public identity bundle: [magic][len][Tink public keyset for ECIES][len][Tink public keyset for Ed25519].
 * The peer ID is derived from the SHA-256 of the exact bundle bytes, so an ID authenticates its keys.
 */
object BundleCodec {
    private val MAGIC = byteArrayOf('P'.code.toByte(), 'T'.code.toByte(), 1)

    fun build(enc: ByteArray, sig: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(MAGIC)
        for (b in listOf(enc, sig)) {
            out.write(b.size ushr 8)
            out.write(b.size and 0xff)
            out.write(b)
        }
        return out.toByteArray()
    }

    fun parse(raw: ByteArray): Pair<ByteArray, ByteArray>? {
        if (raw.size < 9 || raw.size > 2048) return null
        if (!raw.copyOfRange(0, 3).contentEquals(MAGIC)) return null
        var p = 3
        fun readBlock(): ByteArray? {
            if (p + 2 > raw.size) return null
            val n = ((raw[p].toInt() and 0xff) shl 8) or (raw[p + 1].toInt() and 0xff)
            p += 2
            if (n == 0 || p + n > raw.size) return null
            val b = raw.copyOfRange(p, p + n)
            p += n
            return b
        }
        val enc = readBlock() ?: return null
        val sig = readBlock() ?: return null
        if (p != raw.size) return null
        return enc to sig
    }
}

object PeerCrypto {
    private val registered: Boolean by lazy {
        HybridConfig.register()
        SignatureConfig.register()
        true
    }

    fun ensureInit() {
        check(registered)
    }

    private val PEER_ID_REGEX = Regex("^pt[a-z2-7]{26}$")

    fun isValidPeerId(s: String): Boolean = PEER_ID_REGEX.matches(s)

    fun peerIdOf(bundle: ByteArray): String {
        val h = MessageDigest.getInstance("SHA-256").digest(bundle)
        return "pt" + Base32.encode(h.copyOf(16))
    }

    /** Human comparable fingerprint (8 groups of 4 hex chars). */
    fun fingerprint(bundle: ByteArray): String {
        val h = MessageDigest.getInstance("SHA-256").digest(bundle)
        val hex = creator.peer.tool.core.Hex.encode(h.copyOf(16))
        return hex.chunked(4).joinToString(" ")
    }

    private fun readKeyset(bytes: ByteArray): KeysetHandle =
        CleartextKeysetHandle.read(BinaryKeysetReader.withBytes(bytes))

    private fun writeKeyset(h: KeysetHandle): ByteArray {
        val out = ByteArrayOutputStream()
        CleartextKeysetHandle.write(h, BinaryKeysetWriter.withOutputStream(out))
        return out.toByteArray()
    }

    fun validateBundle(bundle: ByteArray): Boolean {
        return try {
            ensureInit()
            val (enc, sig) = BundleCodec.parse(bundle) ?: return false
            val eh = readKeyset(enc)
            val sh = readKeyset(sig)
            if (eh.size() != 1 || sh.size() != 1) return false
            eh.getPrimitive(RegistryConfiguration.get(), HybridEncrypt::class.java)
            sh.getPrimitive(RegistryConfiguration.get(), PublicKeyVerify::class.java)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun encryptFor(bundle: ByteArray, plaintext: ByteArray, context: ByteArray): ByteArray? {
        return try {
            ensureInit()
            val (enc, _) = BundleCodec.parse(bundle) ?: return null
            val he = readKeyset(enc).getPrimitive(RegistryConfiguration.get(), HybridEncrypt::class.java)
            he.encrypt(plaintext, context)
        } catch (e: Exception) {
            null
        }
    }

    fun verify(bundle: ByteArray, signature: ByteArray, data: ByteArray): Boolean {
        return try {
            ensureInit()
            val (_, sig) = BundleCodec.parse(bundle) ?: return false
            val v = readKeyset(sig).getPrimitive(RegistryConfiguration.get(), PublicKeyVerify::class.java)
            v.verify(signature, data)
            true
        } catch (e: Exception) {
            false
        }
    }

    internal fun publicBytes(h: KeysetHandle): ByteArray = writeKeyset(h.publicKeysetHandle)
    internal fun privateBytes(h: KeysetHandle): ByteArray = writeKeyset(h)
    internal fun readPrivate(bytes: ByteArray): KeysetHandle = readKeyset(bytes)
}

/** The local identity: private keysets live only in memory; persisted form is sealed by [LocalCrypto]. */
class IdentityKeys private constructor(
    private val encPrivate: KeysetHandle,
    private val sigPrivate: KeysetHandle,
    val bundle: ByteArray,
) {
    val peerId: String = PeerCrypto.peerIdOf(bundle)
    val fingerprint: String get() = PeerCrypto.fingerprint(bundle)

    private val signer: PublicKeySign =
        sigPrivate.getPrimitive(RegistryConfiguration.get(), PublicKeySign::class.java)
    private val decryptor: HybridDecrypt =
        encPrivate.getPrimitive(RegistryConfiguration.get(), HybridDecrypt::class.java)

    fun sign(data: ByteArray): ByteArray = signer.sign(data)

    fun decrypt(ciphertext: ByteArray, context: ByteArray): ByteArray = decryptor.decrypt(ciphertext, context)

    /** Cleartext serialization of the private material. Callers MUST seal this before persisting. */
    fun serializePrivate(): ByteArray {
        val out = ByteArrayOutputStream()
        val d = DataOutputStream(out)
        for (b in listOf(PeerCrypto.privateBytes(encPrivate), PeerCrypto.privateBytes(sigPrivate), bundle)) {
            d.writeInt(b.size)
            d.write(b)
        }
        d.flush()
        return out.toByteArray()
    }

    companion object {
        fun generate(): IdentityKeys {
            PeerCrypto.ensureInit()
            val enc = KeysetHandle.generateNew(KeyTemplates.get("ECIES_P256_HKDF_HMAC_SHA256_AES128_GCM"))
            val sig = KeysetHandle.generateNew(KeyTemplates.get("ED25519"))
            val bundle = BundleCodec.build(PeerCrypto.publicBytes(enc), PeerCrypto.publicBytes(sig))
            return IdentityKeys(enc, sig, bundle)
        }

        fun deserialize(bytes: ByteArray): IdentityKeys {
            PeerCrypto.ensureInit()
            val d = DataInputStream(ByteArrayInputStream(bytes))
            fun block(): ByteArray {
                val n = d.readInt()
                require(n in 1..8192) { "bad block" }
                val b = ByteArray(n)
                d.readFully(b)
                return b
            }
            val enc = PeerCrypto.readPrivate(block())
            val sig = PeerCrypto.readPrivate(block())
            val bundle = block()
            return IdentityKeys(enc, sig, bundle)
        }
    }
}
