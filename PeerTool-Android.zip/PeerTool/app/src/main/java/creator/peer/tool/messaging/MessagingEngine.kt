package creator.peer.tool.messaging

import creator.peer.tool.core.Backoff
import creator.peer.tool.core.Clock
import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.Ids
import creator.peer.tool.core.SystemClockImpl
import creator.peer.tool.core.TextSafety
import creator.peer.tool.crypto.IdentityKeys
import creator.peer.tool.crypto.PeerCrypto
import creator.peer.tool.notifications.Notifier
import creator.peer.tool.protocol.Envelope
import creator.peer.tool.protocol.Inner
import creator.peer.tool.protocol.InnerCodec
import creator.peer.tool.protocol.Kind
import creator.peer.tool.protocol.Limits
import creator.peer.tool.protocol.HelloBody
import creator.peer.tool.crypto.InviteCode
import creator.peer.tool.transport.TransportStatus
import creator.peer.tool.protocol.ShareLink
import creator.peer.tool.protocol.WireCodec
import creator.peer.tool.routing.LinkView
import creator.peer.tool.routing.Router
import android.content.ContentResolver
import android.net.Uri
import creator.peer.tool.storage.Transfer
import creator.peer.tool.storage.TransferState
import kotlinx.coroutines.Dispatchers
import java.io.File
import creator.peer.tool.storage.Contact
import creator.peer.tool.storage.ContactState
import creator.peer.tool.storage.Message
import creator.peer.tool.storage.MsgState
import creator.peer.tool.storage.OutboxRow
import creator.peer.tool.storage.SettingsHolder
import creator.peer.tool.storage.Store
import creator.peer.tool.transport.Transport
import creator.peer.tool.transport.TransportEvent
import creator.peer.tool.transport.TransportKind
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Core messaging engine. Transport-agnostic: it authenticates links with a signed challenge,
 * encrypts/signs envelopes, persists everything before sending, retries from a durable outbox
 * and only reports "delivered" after an authenticated acknowledgment from the recipient.
 *
 * All mutable state is confined to a single engine thread.
 */
class MessagingEngine(
    private val store: Store,
    private val settingsHolder: SettingsHolder,
    private val transports: List<Transport>,
    private val notifier: Notifier,
    private val diag: DiagLog,
    storageDir: File,
    resolver: ContentResolver,
    private val onOutboxQueued: () -> Unit = {},
    private val clock: Clock = SystemClockImpl,
) {
    private val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "peertool-engine") }.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val started = AtomicBoolean(false)

    @Volatile private var me: IdentityKeys? = null

    private val links = LinkedHashMap<String, LinkRec>()
    private val connectState = HashMap<String, ConnectTrack>()
    private val nearbyFound = LinkedHashMap<String, NearbyPeer>()
    private val reqRate = HashMap<String, Long>()
    private val backoff = Backoff()

    // ---- invite codes (this phone as inviter / as joiner)
    private class ActiveInvite(val code: String, val derived: InviteCode.Derived, val expiresAt: Long) {
        var requesterId: String? = null
        var requesterName: String? = null
    }

    private class PendingJoin(val derived: InviteCode.Derived, val startedAt: Long) {
        var inviterId: String? = null
    }

    private var activeInvite: ActiveInvite? = null
    private var pendingJoin: PendingJoin? = null
    private val acceptedInvites = HashMap<String, Pair<ByteArray, Long>>()
    private val _invite = MutableStateFlow<InviteInfo?>(null)
    val invite: StateFlow<InviteInfo?> = _invite.asStateFlow()
    private val _join = MutableStateFlow(JoinInfo(JoinStatus.IDLE))
    val join: StateFlow<JoinInfo> = _join.asStateFlow()

    private val transferHost = object : TransferHost {
        override fun myPeerId(): String? = me?.peerId
        override fun sendControl(peerId: String, inner: Inner, preferLinkId: String?): Boolean =
            sendEphemeral(peerId, inner, preferLinkId?.let { links[it] })
        override fun sendOnLink(linkId: String, bytes: ByteArray): Boolean {
            val l = links[linkId] ?: return false
            if (!l.up || !l.authed) return false
            return transportFor(l.kind).send(l.id, bytes)
        }
        override fun hasRoute(peerId: String): Boolean = pickLink(peerId) != null
        override fun connect(peerId: String) {
            requestConnect(peerId)
        }
        override fun notice(text: String) {
            _notices.tryEmit(text)
        }
        override fun runIo(block: () -> Unit) {
            scope.launch(Dispatchers.IO) { block() }
        }
        override fun postToEngine(block: () -> Unit) {
            scope.launch { block() }
        }
    }
    private val transfers = TransferManager(store, settingsHolder, storageDir, resolver, transferHost, diag, clock)

    /** Chunks moving right now: transfer id -> chunks done. */
    val transferProgress: StateFlow<Map<String, Int>> get() = transfers.progress

    private val _peerStates = MutableStateFlow<Map<String, PeerConn>>(emptyMap())
    val peerStates: StateFlow<Map<String, PeerConn>> = _peerStates.asStateFlow()
    private val _linkViews = MutableStateFlow<List<LinkView>>(emptyList())
    val linkViews: StateFlow<List<LinkView>> = _linkViews.asStateFlow()
    private val _nearby = MutableStateFlow<List<NearbyPeer>>(emptyList())
    val nearby: StateFlow<List<NearbyPeer>> = _nearby.asStateFlow()
    private val _notices = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val notices: SharedFlow<String> = _notices

    val activeChat = MutableStateFlow<String?>(null)
    val appVisible = MutableStateFlow(false)

    private val settings get() = settingsHolder.current

    // ------------------------------------------------------------------ lifecycle

    fun attach(identity: IdentityKeys) {
        me = identity
        if (!started.get()) start() else scope.launch { applyTransports() }
    }

    fun myPeerId(): String? = me?.peerId

    fun myShareLink(): String? {
        val id = me ?: return null
        return ShareLink.build(id.bundle, settings.displayName.ifBlank { "PeerTool user" }, settings.handle)
    }

    fun myFingerprint(): String? = me?.fingerprint

    private fun start() {
        if (!started.compareAndSet(false, true)) return
        for (t in transports) {
            scope.launch {
                for (e in t.events) {
                    try {
                        handleTransportEvent(e)
                    } catch (ex: Exception) {
                        diag.add("event error ${ex.javaClass.simpleName}")
                    }
                }
            }
        }
        scope.launch {
            settingsHolder.flow.map { it.transportKey() }.distinctUntilChanged().collect { applyTransports() }
        }
        scope.launch {
            while (true) {
                delay(5_000)
                try {
                    tick()
                } catch (ex: Exception) {
                    diag.add("tick error ${ex.javaClass.simpleName}")
                }
            }
        }
        scope.launch {
            while (true) {
                try {
                    maintenance()
                } catch (ex: Exception) {
                    diag.add("maintenance error ${ex.javaClass.simpleName}")
                }
                delay(6 * 3_600_000L)
            }
        }
    }

    private fun applyTransports() {
        val s = settings
        for (t in transports) {
            val want = when (t.kind) {
                TransportKind.WEBRTC -> s.internetEnabled
                TransportKind.NEARBY -> s.nearbyEnabled
            }
            t.stop()
            if (want) t.start()
        }
    }

    /** Re-evaluates transports (e.g. after a permission was granted) and retries pending work. */
    fun kick() {
        scope.launch {
            for (t in transports) t.kick()
            // A nearby transport that failed for missing permissions needs a fresh start.
            val s = settings
            for (t in transports) {
                if (t.kind == TransportKind.NEARBY && s.nearbyEnabled &&
                    t.info.value.status == creator.peer.tool.transport.TransportStatus.OFF
                ) t.start()
            }
            connectState.values.forEach { it.nextAllowedAt = 0L }
            tick()
        }
    }

    fun onNetwork(available: Boolean) {
        if (available) kick()
    }

    fun transportInfos() = transports.associate { it.kind to it.info }

    private suspend fun <T> onEngine(block: () -> T): T = withContext(dispatcher) { block() }

    // ------------------------------------------------------------------ transport events

    private fun transportFor(kind: TransportKind): Transport = transports.first { it.kind == kind }

    private fun handleTransportEvent(e: TransportEvent) {
        val now = clock.now()
        when (e) {
            is TransportEvent.LinkConnecting -> {
                if (links.size >= MAX_LINKS) {
                    transportFor(e.kind).close(e.linkId)
                    return
                }
                links.getOrPut(e.linkId) { LinkRec(e.linkId, e.kind, e.hint, e.incoming, now) }
                publish()
            }
            is TransportEvent.LinkUp -> {
                if (links.size >= MAX_LINKS && !links.containsKey(e.linkId)) {
                    transportFor(e.kind).close(e.linkId)
                    return
                }
                val l = links.getOrPut(e.linkId) { LinkRec(e.linkId, e.kind, e.hint, e.incoming, now) }
                if (l.hint == null) l.hint = e.hint
                l.up = true
                sendChallenge(l)
                publish()
            }
            is TransportEvent.LinkDown -> {
                val l = links.remove(e.linkId)
                if (l != null) onLinkLost(l, e.reason)
                publish()
            }
            is TransportEvent.Data -> {
                val l = links[e.linkId] ?: return
                onData(l, e.bytes)
            }
            is TransportEvent.Discovered -> {
                if (e.present && e.hint != null) {
                    nearbyFound[e.key] = NearbyPeer(e.key, e.hint, e.kind)
                } else {
                    nearbyFound.remove(e.key)
                }
                publish()
            }
        }
    }

    private fun onLinkLost(l: LinkRec, reason: String) {
        val now = clock.now()
        val j = pendingJoin
        if (j != null && !l.authed && l.hint == j.derived.rendezvousId && j.inviterId == null) {
            failJoin("Code not found. It may have expired, or the other phone isn't online.")
        }
        val pid = l.peerId ?: l.hint ?: return
        val t = connectState.getOrPut(pid) { ConnectTrack() }
        if (l.authed) {
            t.lastDownAt = now
        } else {
            t.lastFailureAt = now
            t.lastError = reason
        }
        diag.add("link ${DiagLog.short(pid)} ${l.kind.name.lowercase()} lost: $reason")
    }

    private fun closeLink(l: LinkRec, reason: String) {
        links.remove(l.id)
        try {
            transportFor(l.kind).close(l.id)
        } catch (_: Exception) {
        }
        onLinkLost(l, reason)
        publish()
    }

    // ------------------------------------------------------------------ link authentication

    private fun sendChallenge(l: LinkRec) {
        val id = me ?: return
        val nonce = Ids.randomBytes(16)
        l.nonce = nonce
        l.challengeAt = clock.now()
        rawSend(l, Envelope(Kind.CHAL, Ids.newMessageId(), id.peerId, "", clock.now(), nonce))
    }

    private fun rawSend(l: LinkRec, e: Envelope): Boolean =
        transportFor(l.kind).send(l.id, WireCodec.encode(e))

    private fun signed(e: Envelope): Envelope? {
        val id = me ?: return null
        return e.withSignature(id.sign(WireCodec.signingInput(e)))
    }

    private fun onData(l: LinkRec, bytes: ByteArray) {
        val now = clock.now()
        if (bytes.size > Limits.MAX_ENVELOPE_BYTES) return
        val env = WireCodec.decode(bytes) ?: return
        if (env.kind == Kind.CHUNK) {
            if (!l.authed || l.peerId != env.from) return
            if (now - l.chunkWindowStart > 10_000) {
                l.chunkWindowStart = now
                l.chunkCount = 0
            }
            if (++l.chunkCount > 4_000) return
            transfers.onChunk(env.from, l.id, env)
            return
        }
        if (now - l.rxWindowStart > 10_000) {
            l.rxWindowStart = now
            l.rxCount = 0
        }
        l.rxCount++
        if (l.rxCount > 1_500) {
            closeLink(l, "rate limit exceeded")
            return
        }
        if (l.rxCount > 600) return
        when (env.kind) {
            Kind.CHAL -> handleChallenge(l, env)
            Kind.RESP -> handleResponse(l, env, now)
            Kind.REQ -> if (l.authed && l.peerId == env.from) handleRequest(l, env, now)
            Kind.ACC -> if (l.authed && l.peerId == env.from) handleAccept(l, env, now)
            Kind.MSG -> if (l.authed && l.peerId == env.from) handleMessage(l, env, now)
        }
    }

    private fun handleChallenge(l: LinkRec, env: Envelope) {
        val id = me ?: return
        if (env.body.size !in 16..32) return
        val resp = Envelope(Kind.RESP, Ids.newMessageId(), id.peerId, "", clock.now(), env.body, null, id.bundle)
        val s = signed(resp) ?: return
        rawSend(l, s)
    }

    private fun handleResponse(l: LinkRec, env: Envelope, now: Long) {
        val id = me ?: return
        val nonce = l.nonce ?: return
        if (!nonce.contentEquals(env.body)) return
        val bundle = env.bundle ?: return
        val sig = env.sig ?: return
        if (!PeerCrypto.validateBundle(bundle)) return
        if (PeerCrypto.peerIdOf(bundle) != env.from) return
        if (!PeerCrypto.verify(bundle, sig, WireCodec.signingInput(env))) return
        if (abs(now - env.ts) > Limits.CLOCK_SKEW_MS) return
        if (env.from == id.peerId) {
            closeLink(l, "connected to self")
            return
        }
        if (l.authed && l.peerId != env.from) {
            closeLink(l, "identity changed on link")
            return
        }
        l.nonce = null
        l.missed = 0
        if (!l.authed) {
            val hint = l.hint
            val rendezvous = hint != null && InviteCode.isRendezvousId(hint)
            if (rendezvous) {
                val j = pendingJoin
                if (j == null || j.derived.rendezvousId != hint) {
                    closeLink(l, "unexpected invite link")
                    return
                }
                j.inviterId = env.from
            } else if (l.kind == TransportKind.WEBRTC && hint != null && hint != env.from) {
                closeLink(l, "signaling identity mismatch")
                return
            }
            l.authed = true
            l.peerId = env.from
            l.bundle = bundle
            diag.add("authenticated ${DiagLog.short(env.from)} via ${l.kind.name.lowercase()}")
            onPeerAuthed(l)
        }
        publish()
    }

    private fun onPeerAuthed(l: LinkRec) {
        val pid = l.peerId ?: return
        val now = clock.now()
        connectState[pid]?.let {
            it.attempts = 0
            it.nextAllowedAt = 0L
            it.lastFailureAt = 0L
        }
        if (isInviteeLink(l)) {
            handleInviteeAuthed(l)
            return
        }
        if (isInviterLink(l)) {
            val inv = activeInvite
            if (inv == null || now > inv.expiresAt || (inv.requesterId != null && inv.requesterId != pid)) {
                closeLink(l, "invite not available")
            }
            return
        }
        val c = store.contact(pid)
        when {
            c == null -> {
                val strangers = links.values.count { it.authed && it.peerId != null && store.contact(it.peerId!!) == null }
                if (!settings.discoverable || strangers > MAX_STRANGER_LINKS) closeLink(l, "unknown peer not allowed")
            }
            c.state == ContactState.BLOCKED -> closeLink(l, "blocked contact")
            c.state == ContactState.OUT_PENDING -> sendRequest(l)
            c.state == ContactState.ACCEPTED -> {
                store.touchSeen(pid, now)
                store.resetOutboxNext(pid, now)
                flushPeer(pid)
            }
        }
    }

    // ------------------------------------------------------------------ contact handshake

    private fun sendRequest(l: LinkRec, proof: ByteArray? = null) {
        val id = me ?: return
        val name = settings.displayName.ifBlank { "PeerTool user" }
        val env = Envelope(
            Kind.REQ, Ids.newMessageId(), id.peerId, l.peerId ?: "", clock.now(),
            HelloBody.encode(name, settings.handle, proof), null, id.bundle
        )
        signed(env)?.let { rawSend(l, it) }
    }

    private fun sendAccept(l: LinkRec, proof: ByteArray? = null) {
        val id = me ?: return
        val name = settings.displayName.ifBlank { "PeerTool user" }
        val env = Envelope(
            Kind.ACC, Ids.newMessageId(), id.peerId, l.peerId ?: "", clock.now(),
            HelloBody.encode(name, settings.handle, proof), null, id.bundle
        )
        signed(env)?.let { rawSend(l, it) }
    }

    private fun isInviteeLink(l: LinkRec): Boolean = l.hint?.let { InviteCode.isRendezvousId(it) } == true
    private fun isInviterLink(l: LinkRec): Boolean = l.id.startsWith("rtcinv:")

    /** Proof that we hold the invite code, attached to an acceptance (also re-sent for a while after the invite ended). */
    private fun inviteAcceptProof(peerId: String): ByteArray? {
        val id = me ?: return null
        val inv = activeInvite
        if (inv != null && inv.requesterId == peerId) return InviteCode.proofAccept(inv.derived.key, id.peerId, peerId)
        val k = acceptedInvites[peerId] ?: return null
        return InviteCode.proofAccept(k.first, id.peerId, peerId)
    }

    /** Joiner side: the link to the rendezvous ID is authenticated, so we now know the inviter's real identity. */
    private fun handleInviteeAuthed(l: LinkRec) {
        val j = pendingJoin
        val id = me
        val pid = l.peerId
        if (j == null || id == null || pid == null) {
            closeLink(l, "no pending join")
            return
        }
        val c = store.contact(pid)
        if (c != null && c.state == ContactState.BLOCKED) {
            failJoin("You blocked this contact.")
            closeLink(l, "blocked contact")
            return
        }
        if (c == null) {
            store.insertContact(Contact(pid, shortName(pid), null, l.bundle, ContactState.OUT_PENDING, false, false, clock.now(), null))
        }
        _join.value = JoinInfo(JoinStatus.WAITING_APPROVAL, "Waiting for them to accept…")
        sendRequest(l, InviteCode.proofRequest(j.derived.key, id.peerId, pid))
        publish()
    }

    /** Inviter side: a request that arrived through the rendezvous ID. Must carry proof of the code. */
    private fun handleInviteRequest(l: LinkRec, env: Envelope, bundle: ByteArray, hello: creator.peer.tool.protocol.Hello, name: String, handle: String?, now: Long) {
        val inv = activeInvite ?: return
        val id = me ?: return
        if (now > inv.expiresAt) return
        if (inv.requesterId != null && inv.requesterId != env.from) return
        val proof = hello.proof ?: return
        if (!InviteCode.same(proof, InviteCode.proofRequest(inv.derived.key, env.from, id.peerId))) {
            closeLink(l, "bad invite proof")
            return
        }
        val existing = store.contact(env.from)
        when (existing?.state) {
            null -> store.insertContact(
                Contact(env.from, name, null, bundle, ContactState.IN_REQUEST, false, false, now, null, handle)
            )
            ContactState.BLOCKED -> {
                closeLink(l, "blocked contact")
                return
            }
            ContactState.ACCEPTED, ContactState.OUT_PENDING -> {
                // Already known (or they asked us too): the code proves who they are, so finish right away.
                store.acceptContact(env.from, bundle, name)
                store.setHandle(env.from, handle)
                store.setVerified(env.from, true)
                inv.requesterId = env.from
                inv.requesterName = name
                sendAccept(l, InviteCode.proofAccept(inv.derived.key, id.peerId, env.from))
                endInvite(InviteStatus.ACCEPTED)
                store.resetOutboxNext(env.from, now)
                flushPeer(env.from)
                publish()
                return
            }
            ContactState.IN_REQUEST -> {
                store.updateContactName(env.from, name)
                store.setHandle(env.from, handle)
            }
        }
        inv.requesterId = env.from
        inv.requesterName = name
        publishInvite()
        notifier.newRequest(name, env.from)
        _notices.tryEmit("$name used your code — tap Accept to finish")
        publish()
    }

    private fun publishInvite() {
        val inv = activeInvite ?: return
        val status = if (inv.requesterId != null) InviteStatus.REQUESTED else InviteStatus.WAITING
        _invite.value = InviteInfo(InviteCode.format(inv.code), inv.expiresAt, status, inv.requesterName, inv.requesterId)
    }

    private fun endInvite(status: InviteStatus) {
        val inv = activeInvite ?: return
        activeInvite = null
        val rid = inv.requesterId
        if (rid != null && status == InviteStatus.ACCEPTED) {
            acceptedInvites[rid] = inv.derived.key to (clock.now() + InviteCode.LIFETIME_MS)
        }
        transports.firstOrNull { it.kind == TransportKind.WEBRTC }?.closeInvite()
        if (status != InviteStatus.ACCEPTED) {
            for (l in links.values.filter { isInviterLink(it) && store.contact(it.peerId ?: "")?.state != ContactState.ACCEPTED }.toList()) {
                closeLink(l, "invite ended")
            }
        }
        _invite.value = InviteInfo(InviteCode.format(inv.code), inv.expiresAt, status, inv.requesterName, rid)
    }

    private fun failJoin(message: String) {
        pendingJoin = null
        _join.value = JoinInfo(JoinStatus.FAILED, message)
    }

    private fun verifyHandshake(l: LinkRec, env: Envelope, now: Long): ByteArray? {
        val bundle = env.bundle ?: return null
        val known = l.bundle ?: return null
        if (!known.contentEquals(bundle)) return null
        val sig = env.sig ?: return null
        if (!PeerCrypto.verify(bundle, sig, WireCodec.signingInput(env))) return null
        if (abs(now - env.ts) > Limits.CLOCK_SKEW_MS) return null
        return bundle
    }

    private fun handleRequest(l: LinkRec, env: Envelope, now: Long) {
        val bundle = verifyHandshake(l, env, now) ?: return
        val last = reqRate[env.from] ?: 0L
        if (now - last < 5_000) return
        reqRate[env.from] = now
        if (reqRate.size > 512) reqRate.clear()
        val hello = HelloBody.decode(env.body)
        val name = TextSafety.sanitizeName(hello.name).ifEmpty { shortName(env.from) }
        val handle = hello.handle.ifEmpty { null }
        if (isInviterLink(l)) {
            handleInviteRequest(l, env, bundle, hello, name, handle, now)
            return
        }
        val c = store.contact(env.from)
        when (c?.state) {
            null -> {
                if (!settings.discoverable || store.countContacts(ContactState.IN_REQUEST) >= 50) return
                store.insertContact(
                    Contact(env.from, name, null, bundle, ContactState.IN_REQUEST, false, false, now, null, handle)
                )
                notifier.newRequest(name, env.from)
                _notices.tryEmit("Contact request from $name")
            }
            ContactState.OUT_PENDING -> {
                store.acceptContact(env.from, bundle, name)
                store.setHandle(env.from, handle)
                sendAccept(l, inviteAcceptProof(env.from))
                store.resetOutboxNext(env.from, now)
                flushPeer(env.from)
                _notices.tryEmit("$name accepted")
            }
            ContactState.ACCEPTED -> {
                store.setHandle(env.from, handle)
                sendAccept(l, inviteAcceptProof(env.from))
            }
            ContactState.IN_REQUEST -> {
                store.updateContactName(env.from, name)
                store.setHandle(env.from, handle)
            }
            ContactState.BLOCKED -> Unit
        }
        publish()
    }

    private fun handleAccept(l: LinkRec, env: Envelope, now: Long) {
        val bundle = verifyHandshake(l, env, now) ?: return
        val c = store.contact(env.from) ?: return
        if (c.state != ContactState.OUT_PENDING) return
        if (c.bundle != null && !c.bundle.contentEquals(bundle)) return
        val id = me ?: return
        val hello = HelloBody.decode(env.body)
        val j = pendingJoin
        val viaInvite = j != null && j.inviterId == env.from
        if (viaInvite) {
            val proof = hello.proof
            if (proof == null || !InviteCode.same(proof, InviteCode.proofAccept(j!!.derived.key, env.from, id.peerId))) {
                failJoin("The other phone could not prove it has your code, so nothing was added.")
                store.deleteContact(env.from)
                closeLink(l, "invite proof invalid")
                publish()
                return
            }
        }
        val name = TextSafety.sanitizeName(hello.name).ifEmpty { c.name }
        store.acceptContact(env.from, bundle, name)
        store.setHandle(env.from, hello.handle.ifEmpty { null })
        if (viaInvite) {
            store.setVerified(env.from, true)
            pendingJoin = null
            _join.value = JoinInfo(JoinStatus.DONE, name)
        }
        store.resetOutboxNext(env.from, now)
        flushPeer(env.from)
        _notices.tryEmit("$name accepted your request")
        publish()
    }

    private fun shortName(peerId: String) = "Peer " + peerId.takeLast(4)

    // ------------------------------------------------------------------ receiving messages

    private fun handleMessage(l: LinkRec, env: Envelope, now: Long) {
        val id = me ?: return
        if (env.to != id.peerId) return
        val c = store.contact(env.from) ?: return
        val bundle = c.bundle ?: return
        if (c.state != ContactState.ACCEPTED) return
        if (env.ts > now + Limits.CLOCK_SKEW_MS || env.ts < now - Limits.MAX_MESSAGE_AGE_MS) return
        val sig = env.sig ?: return
        if (!PeerCrypto.verify(bundle, sig, WireCodec.signingInput(env))) return
        val plain = try {
            id.decrypt(env.body, WireCodec.contextInfo(env.kind, env.id, env.from, env.to))
        } catch (e: Exception) {
            return
        }
        when (val inner = InnerCodec.decode(plain) ?: return) {
            is Inner.Text -> {
                val msg = Message(
                    id = env.id, peerId = env.from, outgoing = false, body = inner.body, replyTo = inner.replyTo,
                    createdAt = minOf(env.ts, now), receivedAt = now, state = MsgState.RECEIVED,
                    read = false, readByPeerAt = null, pinned = false,
                )
                val isNew = try {
                    store.insertIncoming(msg)
                } catch (e: Exception) {
                    diag.add("storage error on receive")
                    return // no ack: sender will retry
                }
                // Ack only after the commit above, and also for duplicates (the first ack may have been lost).
                sendEphemeral(env.from, Inner.Ack(listOf(env.id)), l)
                if (isNew) {
                    val watching = appVisible.value && activeChat.value == env.from
                    if (!watching) notifier.newMessage(c, inner.body)
                }
            }
            is Inner.Ack -> store.markDelivered(env.from, inner.ids)
            is Inner.Read -> store.markReadByPeer(env.from, inner.ids, now)
            is Inner.Delete -> {
                transfers.discard(inner.id)
                store.deleteIncoming(env.from, inner.id)
            }
            is Inner.File -> handleFileOffer(l, env, inner, c, now)
            is Inner.FileReq -> transfers.onReq(env.from, l.id, inner)
            is Inner.FileDone -> transfers.onPeerDone(env.from, inner.id)
            is Inner.FileCancel -> transfers.onPeerCancel(env.from, inner.id, inner.reason)
            is Inner.React -> {
                val m = store.message(inner.id)
                if (m != null && m.peerId == env.from) store.setReaction(inner.id, false, inner.emoji)
            }
        }
    }

    private fun handleFileOffer(l: LinkRec, env: Envelope, inner: Inner.File, c: Contact, now: Long) {
        val name = TextSafety.sanitizeName(inner.name.replace('/', '_').replace('\\', '_'), Limits.MAX_FILE_NAME).ifEmpty { "file" }
        val chunks = ((inner.size + inner.chunkSize - 1) / inner.chunkSize).toInt()
        val tooBig = inner.size > settings.maxFileMb * 1024L * 1024L
        val t = Transfer(
            id = env.id, peerId = env.from, outgoing = false, name = name, mime = inner.mime, size = inner.size,
            chunkSize = inner.chunkSize, chunks = chunks, sha256 = inner.sha256, key = inner.key,
            state = if (tooBig) TransferState.FAILED else TransferState.OFFERED,
            fileName = null, doneChunks = 0, bitmap = null, updatedAt = now,
            error = if (tooBig) "Larger than your file size limit" else null,
        )
        val msg = Message(
            id = env.id, peerId = env.from, outgoing = false, body = "\uD83D\uDCCE $name", replyTo = null,
            createdAt = minOf(env.ts, now), receivedAt = now, state = MsgState.RECEIVED,
            read = false, readByPeerAt = null, pinned = false,
        )
        val isNew = try {
            store.insertIncomingFile(msg, t)
        } catch (e: Exception) {
            diag.add("storage error on receive")
            return
        }
        sendEphemeral(env.from, Inner.Ack(listOf(env.id)), l)
        if (!isNew) return
        if (tooBig) {
            sendEphemeral(env.from, Inner.FileCancel(env.id, "too large"), l)
            return
        }
        val watching = appVisible.value && activeChat.value == env.from
        if (!watching) notifier.newMessage(c, "\uD83D\uDCCE $name")
        if (settings.autoDownloadImages && c.verified && inner.mime.startsWith("image/") && inner.size <= 5L * 1024 * 1024) {
            transfers.accept(env.id)
        }
    }

    // ------------------------------------------------------------------ sending

    private fun buildMsgEnvelope(c: Contact, inner: Inner, msgId: String, ts: Long): ByteArray? {
        val id = me ?: return null
        val bundle = c.bundle ?: return null
        val ctx = WireCodec.contextInfo(Kind.MSG, msgId, id.peerId, c.peerId)
        val ct = PeerCrypto.encryptFor(bundle, InnerCodec.encode(inner), ctx) ?: return null
        val env = Envelope(Kind.MSG, msgId, id.peerId, c.peerId, ts, ct)
        val s = signed(env) ?: return null
        return WireCodec.encode(s)
    }

    private fun linksFor(peerId: String): List<LinkView> {
        val now = clock.now()
        return links.values.filter { it.peerId == peerId }.map {
            LinkView(it.id, it.kind, it.peerId, it.hint, it.up, it.authed, it.missed, now - it.createdAt)
        }
    }

    private fun pickLink(peerId: String): LinkRec? {
        val v = Router.pick(linksFor(peerId), settings.routePref) ?: return null
        return links[v.id]
    }

    /** Best-effort, non-persistent send (acks, read receipts, deletions). */
    private fun sendEphemeral(peerId: String, inner: Inner, prefer: LinkRec? = null): Boolean {
        val c = store.contact(peerId) ?: return false
        if (c.state != ContactState.ACCEPTED) return false
        val bytes = buildMsgEnvelope(c, inner, Ids.newMessageId(), clock.now()) ?: return false
        val link = prefer?.takeIf { it.up && it.authed } ?: pickLink(peerId) ?: return false
        return transportFor(link.kind).send(link.id, bytes)
    }

    suspend fun sendText(peerId: String, text: String, replyTo: String?): Result<String> = onEngine {
        val id = me ?: return@onEngine Result.failure(IllegalStateException("No identity"))
        val clean = text.trim()
        if (clean.isEmpty()) return@onEngine Result.failure(IllegalArgumentException("Message is empty"))
        if (TextSafety.utf8Size(clean) > Limits.MAX_TEXT_BYTES) {
            return@onEngine Result.failure(IllegalArgumentException("Message too long"))
        }
        val c = store.contact(peerId)
        if (c == null || c.state != ContactState.ACCEPTED || c.bundle == null) {
            return@onEngine Result.failure(IllegalStateException("Contact is not accepted yet"))
        }
        if (store.outboxCount() >= MAX_OUTBOX_TOTAL || store.outboxCount(peerId) >= MAX_OUTBOX_PEER) {
            return@onEngine Result.failure(IllegalStateException("Too many unsent messages"))
        }
        val msgId = Ids.newMessageId()
        val now = clock.now()
        val bytes = buildMsgEnvelope(c, Inner.Text(clean, replyTo, now), msgId, now)
            ?: return@onEngine Result.failure(IllegalStateException("Encryption failed"))
        val msg = Message(
            msgId, peerId, true, clean, replyTo, now, null, MsgState.QUEUED,
            read = true, readByPeerAt = null, pinned = false
        )
        val row = OutboxRow(msgId, peerId, bytes, 0, now, now, now + settings.expiryHours * 3_600_000L, null)
        try {
            store.insertOutgoing(msg, row)
        } catch (e: Exception) {
            return@onEngine Result.failure(IllegalStateException("Storage error"))
        }
        onOutboxQueued()
        flushPeer(peerId)
        publish()
        Result.success(msgId)
    }

    suspend fun resend(msgId: String): Result<Unit> = onEngine {
        val m = store.message(msgId) ?: return@onEngine Result.failure(IllegalStateException("Message not found"))
        if (!m.outgoing || (m.state != MsgState.FAILED && m.state != MsgState.EXPIRED)) {
            return@onEngine Result.failure(IllegalStateException("Nothing to resend"))
        }
        val c = store.contact(m.peerId)
        if (c == null || c.state != ContactState.ACCEPTED) {
            return@onEngine Result.failure(IllegalStateException("Contact is not accepted"))
        }
        val now = clock.now()
        val tr = store.transfer(m.id)
        val inner: Inner = if (tr != null && tr.outgoing) {
            if (transfers.fileFor(tr) == null) return@onEngine Result.failure(IllegalStateException("The file is no longer on this device"))
            Inner.File(tr.name, tr.mime, tr.size, tr.sha256, tr.chunkSize, tr.key, now)
        } else {
            Inner.Text(m.body, m.replyTo, now)
        }
        val bytes = buildMsgEnvelope(c, inner, m.id, now)
            ?: return@onEngine Result.failure(IllegalStateException("Encryption failed"))
        if (tr != null && tr.outgoing && tr.state != TransferState.DONE) store.resetTransfer(tr.id, now)
        store.requeue(m.id, OutboxRow(m.id, m.peerId, bytes, 0, now, now, now + settings.expiryHours * 3_600_000L, null))
        onOutboxQueued()
        flushPeer(m.peerId)
        Result.success(Unit)
    }

    suspend fun deleteMessage(msgId: String, forEveryone: Boolean) = onEngine {
        val m = store.message(msgId) ?: return@onEngine
        if (forEveryone && m.outgoing && m.state == MsgState.DELIVERED) {
            sendEphemeral(m.peerId, Inner.Delete(m.id))
        }
        transfers.discard(msgId)
        store.deleteMessage(msgId)
    }

    suspend fun markRead(peerId: String) = onEngine {
        val ids = store.markConversationRead(peerId)
        notifier.cancelFor(peerId)
        if (ids.isNotEmpty() && settings.readReceipts) {
            for (chunk in ids.chunked(Limits.MAX_IDS_PER_RECEIPT)) sendEphemeral(peerId, Inner.Read(chunk))
        }
    }

    // ------------------------------------------------------------------ files (UI API)

    /** Copies, hashes and offers a file to a contact. The offer is a normal persisted message; the bytes flow after the contact accepts. */
    suspend fun sendFile(peerId: String, uri: Uri): Result<String> {
        val err = onEngine {
            val c = store.contact(peerId)
            when {
                me == null -> "No identity"
                c == null || c.state != ContactState.ACCEPTED || c.bundle == null -> "Contact is not accepted yet"
                store.outboxCount() >= MAX_OUTBOX_TOTAL || store.outboxCount(peerId) >= MAX_OUTBOX_PEER -> "Too many unsent messages"
                else -> null
            }
        }
        if (err != null) return Result.failure(IllegalStateException(err))
        val maxBytes = minOf(settings.maxFileMb * 1024L * 1024L, Limits.MAX_FILE_BYTES)
        val prepared = try {
            withContext(Dispatchers.IO) { transfers.prepareOutgoing(uri, maxBytes) }
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException(e.message ?: "Could not read the file"))
        }
        return onEngine {
            val c = store.contact(peerId)
            if (c == null || c.state != ContactState.ACCEPTED || c.bundle == null) {
                prepared.temp.delete()
                return@onEngine Result.failure<String>(IllegalStateException("Contact is not accepted"))
            }
            val id = Ids.newMessageId()
            val now = clock.now()
            val fileName = try {
                transfers.adopt(prepared, id)
            } catch (e: Exception) {
                return@onEngine Result.failure<String>(IllegalStateException("Could not store the file"))
            }
            val key = Ids.randomBytes(32)
            val chunks = ((prepared.size + Limits.CHUNK_SIZE - 1) / Limits.CHUNK_SIZE).toInt()
            val inner = Inner.File(prepared.name, prepared.mime, prepared.size, prepared.sha256, Limits.CHUNK_SIZE, key, now)
            val bytes = buildMsgEnvelope(c, inner, id, now)
            if (bytes == null) {
                File(fileDirOut(), fileName).delete()
                return@onEngine Result.failure<String>(IllegalStateException("Encryption failed"))
            }
            val msg = Message(
                id, peerId, true, "\uD83D\uDCCE ${prepared.name}", null, now, null, MsgState.QUEUED,
                read = true, readByPeerAt = null, pinned = false
            )
            val row = OutboxRow(id, peerId, bytes, 0, now, now, now + settings.expiryHours * 3_600_000L, null)
            val t = Transfer(
                id, peerId, true, prepared.name, prepared.mime, prepared.size, Limits.CHUNK_SIZE, chunks,
                prepared.sha256, key, TransferState.OFFERED, fileName, 0, null, now, null
            )
            try {
                store.insertOutgoingFile(msg, row, t)
            } catch (e: Exception) {
                File(fileDirOut(), fileName).delete()
                return@onEngine Result.failure<String>(IllegalStateException("Storage error"))
            }
            onOutboxQueued()
            flushPeer(peerId)
            publish()
            Result.success(id)
        }
    }

    private val outDirRef = File(storageDir, "transfers/out")
    private fun fileDirOut(): File = outDirRef

    suspend fun acceptTransfer(id: String) = onEngine { transfers.accept(id) }

    suspend fun cancelTransfer(id: String) = onEngine { transfers.cancel(id) }

    fun fileFor(t: Transfer): File? = transfers.fileFor(t)

    suspend fun exportFile(t: Transfer, dest: Uri): Boolean = withContext(Dispatchers.IO) { transfers.exportTo(t, dest) }

    suspend fun attachmentsBytes(): Long = withContext(Dispatchers.IO) { transfers.attachmentsBytes() }

    suspend fun deleteAllAttachments(): Long = onEngine { transfers.deleteAllFiles() }

    suspend fun react(msgId: String, emoji: String?) = onEngine {
        val m = store.message(msgId) ?: return@onEngine
        val e = emoji?.take(Limits.MAX_EMOJI_CHARS)?.takeIf { it.isNotEmpty() }
        store.setReaction(msgId, true, e)
        sendEphemeral(m.peerId, Inner.React(msgId, e ?: ""))
        Unit
    }

    suspend fun clearConversation(peerId: String) = onEngine {
        transfers.discardPeer(peerId)
        store.clearConversation(peerId)
        transfers.sweep()
    }

    // ------------------------------------------------------------------ outbox processing

    private fun tick() {
        val now = clock.now()
        activeInvite?.let { if (now > it.expiresAt) endInvite(InviteStatus.EXPIRED) }
        pendingJoin?.let { j ->
            val limit = if (j.inviterId != null) 600_000L else 60_000L
            if (now - j.startedAt > limit) {
                failJoin(
                    if (j.inviterId != null) "They didn't accept in time."
                    else "No answer. Check the code and make sure the other phone has the invite screen open."
                )
            }
        }
        acceptedInvites.entries.removeAll { it.value.second < now }
        // link supervision
        val toClose = ArrayList<LinkRec>()
        for (l in links.values) {
            if (!l.up) {
                if (now - l.createdAt > 60_000) toClose.add(l)
                continue
            }
            if (!l.authed) {
                if (now - l.createdAt > AUTH_TIMEOUT_MS) toClose.add(l)
                continue
            }
            if (l.nonce != null) {
                if (now - l.challengeAt > RESP_TIMEOUT_MS) {
                    l.missed++
                    l.nonce = null
                    if (l.missed >= 2) toClose.add(l)
                }
            } else if (now - l.challengeAt > LIVENESS_INTERVAL_MS) {
                sendChallenge(l)
            }
        }
        toClose.forEach { closeLink(it, "no response") }

        // pending contact requests
        for (c in store.contacts()) {
            if (c.state == ContactState.OUT_PENDING && pickLink(c.peerId) == null) requestConnect(c.peerId)
        }
        // outbox
        store.expireOutbox(now)
        val due = store.dueOutbox(now)
        for (peer in due.map { it.peerId }.distinct()) flushPeer(peer)
        transfers.tick(now)
        publish()
    }

    private fun flushPeer(peerId: String) {
        val now = clock.now()
        val rows = store.outboxFor(peerId).filter { it.nextAttemptAt <= now }
        if (rows.isEmpty()) return
        val c = store.contact(peerId)
        if (c == null || c.state != ContactState.ACCEPTED) {
            if (c == null || c.state == ContactState.BLOCKED) store.failOutboxForPeer(peerId)
            return
        }
        val link = pickLink(peerId)
        if (link == null) {
            requestConnect(peerId)
            return
        }
        val t = transportFor(link.kind)
        for (row in rows) {
            val ok = t.send(link.id, row.envelope)
            val attempts = row.attempts + 1
            if (ok) {
                store.markSending(row.msgId)
                store.updateOutbox(row.msgId, attempts, now + maxOf(ACK_WAIT_MS, backoff.delayMs(attempts)), null)
            } else {
                store.updateOutbox(row.msgId, attempts, now + backoff.delayMs(attempts), "send failed")
            }
        }
    }

    private fun requestConnect(peerId: String, force: Boolean = false): Boolean {
        val now = clock.now()
        val t = connectState.getOrPut(peerId) { ConnectTrack() }
        if (!force && now < t.nextAllowedAt) return false
        val inProgress = links.values.any {
            (it.peerId == peerId || it.hint == peerId) && !(it.authed && it.up) && now - it.createdAt < 30_000
        }
        if (inProgress) return true
        var started = false
        for (tr in transports) {
            if (!Router.allows(tr.kind, settings.routePref)) continue
            if (tr.info.value.status == creator.peer.tool.transport.TransportStatus.OFF) continue
            if (tr.connect(peerId)) started = true
        }
        t.attempts++
        t.nextAllowedAt = now + backoff.delayMs(t.attempts)
        if (!started) {
            t.lastFailureAt = now
            t.lastError = "No transport ready"
        }
        publish()
        return started
    }

    private fun maintenance() {
        val now = clock.now()
        val days = settings.retentionDays
        val before = if (days > 0) now - days * 86_400_000L else 0L
        store.purge(before, now - 14 * 86_400_000L)
        transfers.maintenance(now)
    }

    // ------------------------------------------------------------------ state publishing

    private fun publish() {
        val now = clock.now()
        val views = links.values.map {
            LinkView(it.id, it.kind, it.peerId, it.hint, it.up, it.authed, it.missed, now - it.createdAt)
        }
        _linkViews.value = views
        val map = HashMap<String, PeerConn>()
        for (c in store.contacts()) {
            if (c.state == ContactState.BLOCKED) continue
            map[c.peerId] = stateFor(c.peerId, views, now)
        }
        _peerStates.value = map
        _nearby.value = nearbyFound.values.toList()
    }

    private fun stateFor(peerId: String, views: List<LinkView>, now: Long): PeerConn {
        val mine = views.filter { it.peerId == peerId || (!it.authed && it.hint == peerId) }
        val live = mine.filter { it.authed && it.up }
        if (live.isNotEmpty()) {
            val best = Router.pick(live, creator.peer.tool.storage.RoutePref.AUTO) ?: live.first()
            return if (live.all { it.missed > 0 }) PeerConn(ConnState.DEGRADED, best.kind, "Slow or no replies")
            else PeerConn(ConnState.CONNECTED, best.kind)
        }
        if (mine.isNotEmpty()) return PeerConn(ConnState.CONNECTING, mine.first().kind)
        val t = connectState[peerId]
        if (t != null && t.lastDownAt > 0 && now - t.lastDownAt < 90_000) {
            return PeerConn(ConnState.RECONNECTING)
        }
        if (nearbyFound.values.any { it.advertisedId == peerId }) {
            return PeerConn(ConnState.DISCOVERED, TransportKind.NEARBY)
        }
        if (t != null && t.lastFailureAt > 0 && now - t.lastFailureAt < 10 * 60_000) {
            return PeerConn(ConnState.FAILED, null, t.lastError)
        }
        return PeerConn(ConnState.DISCONNECTED)
    }

    // ------------------------------------------------------------------ contact management (UI)

    suspend fun addContactFromLink(text: String): Result<String> = onEngine {
        val id = me ?: return@onEngine Result.failure(IllegalStateException("No identity"))
        val parsed = ShareLink.parseFull(text)
            ?: return@onEngine Result.failure(IllegalArgumentException("Not a valid PeerTool link"))
        val bundle = parsed.bundle
        val rawName = parsed.name
        if (!PeerCrypto.validateBundle(bundle)) {
            return@onEngine Result.failure(IllegalArgumentException("Invalid identity data"))
        }
        val pid = PeerCrypto.peerIdOf(bundle)
        if (pid == id.peerId) return@onEngine Result.failure(IllegalArgumentException("That is your own code"))
        val name = TextSafety.sanitizeName(rawName).ifEmpty { shortName(pid) }
        val existing = store.contact(pid)
        when (existing?.state) {
            null -> store.insertContact(
                Contact(pid, name, null, bundle, ContactState.OUT_PENDING, true, false, clock.now(), null, parsed.handle.ifEmpty { null })
            )
            ContactState.IN_REQUEST -> {
                store.acceptContact(pid, bundle, null)
                store.setVerified(pid, true)
            }
            ContactState.BLOCKED -> return@onEngine Result.failure(IllegalStateException("Contact is blocked"))
            else -> store.setVerified(pid, true)
        }
        requestConnect(pid, force = true)
        publish()
        Result.success(pid)
    }

    suspend fun addContactById(peerId: String): Result<String> = onEngine {
        val id = me ?: return@onEngine Result.failure(IllegalStateException("No identity"))
        val pid = peerId.trim().lowercase()
        if (!PeerCrypto.isValidPeerId(pid)) {
            return@onEngine Result.failure(IllegalArgumentException("That doesn't look like a PeerTool ID"))
        }
        if (pid == id.peerId) return@onEngine Result.failure(IllegalArgumentException("That is your own ID"))
        val existing = store.contact(pid)
        if (existing == null) {
            store.insertContact(Contact(pid, shortName(pid), null, null, ContactState.OUT_PENDING, false, false, clock.now(), null))
        } else if (existing.state == ContactState.BLOCKED) {
            return@onEngine Result.failure(IllegalStateException("Contact is blocked"))
        }
        requestConnect(pid, force = true)
        publish()
        Result.success(pid)
    }

    suspend fun acceptRequest(peerId: String) = onEngine {
        val c = store.contact(peerId) ?: return@onEngine
        val bundle = c.bundle ?: return@onEngine
        if (c.state != ContactState.IN_REQUEST) return@onEngine
        store.acceptContact(peerId, bundle, null)
        val inv = activeInvite
        val viaInvite = inv != null && inv.requesterId == peerId
        val proof = inviteAcceptProof(peerId)
        pickLink(peerId)?.let { sendAccept(it, proof) } ?: requestConnect(peerId, force = true)
        if (viaInvite) {
            store.setVerified(peerId, true)
            endInvite(InviteStatus.ACCEPTED)
        }
        publish()
    }

    suspend fun declineRequest(peerId: String, block: Boolean) = onEngine {
        val inv = activeInvite
        if (inv != null && inv.requesterId == peerId) {
            inv.requesterId = null
            inv.requesterName = null
            publishInvite()
            links.values.filter { it.peerId == peerId && isInviterLink(it) }.toList().forEach { closeLink(it, "declined") }
        }
        if (block) setBlockedInternal(peerId, true) else removeInternal(peerId)
    }

    // ------------------------------------------------------------------ invite codes (UI API)

    private fun webrtcReady(): creator.peer.tool.transport.Transport? =
        transports.firstOrNull { it.kind == TransportKind.WEBRTC && it.info.value.status == TransportStatus.READY }

    /** Creates a single-use code (valid 10 minutes) and waits for someone to enter it. */
    suspend fun createInvite(): Result<InviteInfo> {
        val code = InviteCode.generate()
        val derived = withContext(Dispatchers.IO) { InviteCode.derive(code) }
        return onEngine {
            val t = webrtcReady()
                ?: return@onEngine Result.failure<InviteInfo>(IllegalStateException("Not connected to the signaling server yet. Check your internet and Settings → Network."))
            if (me == null) return@onEngine Result.failure<InviteInfo>(IllegalStateException("No identity"))
            if (activeInvite != null) endInvite(InviteStatus.CANCELLED)
            val inv = ActiveInvite(code, derived, clock.now() + InviteCode.LIFETIME_MS)
            activeInvite = inv
            if (!t.openInvite(derived.rendezvousId)) {
                activeInvite = null
                return@onEngine Result.failure<InviteInfo>(IllegalStateException("Could not open the invite"))
            }
            publishInvite()
            Result.success(_invite.value!!)
        }
    }

    fun cancelInvite() {
        scope.launch {
            if (activeInvite != null) endInvite(InviteStatus.CANCELLED)
            _invite.value = null
        }
    }

    fun dismissInvite() {
        scope.launch { if (activeInvite == null) _invite.value = null }
    }

    /** Enter a code someone gave you. On success a contact request is sent and you wait for them to accept. */
    suspend fun joinWithCode(input: String): Result<Unit> {
        val code = InviteCode.normalize(input)
            ?: return Result.failure(IllegalArgumentException("A code has 8 letters and numbers, like K7M4-QX2P"))
        val derived = withContext(Dispatchers.IO) { InviteCode.derive(code) }
        return onEngine {
            val t = webrtcReady()
                ?: return@onEngine Result.failure<Unit>(IllegalStateException("Not connected to the signaling server yet. Check your internet and Settings → Network."))
            if (me == null) return@onEngine Result.failure<Unit>(IllegalStateException("No identity"))
            pendingJoin = PendingJoin(derived, clock.now())
            _join.value = JoinInfo(JoinStatus.CONNECTING, "Looking for them…")
            if (!t.connect(derived.rendezvousId)) {
                failJoin("Could not start connecting")
                return@onEngine Result.failure<Unit>(IllegalStateException("Could not start connecting"))
            }
            Result.success(Unit)
        }
    }

    fun resetJoin() {
        scope.launch {
            pendingJoin = null
            _join.value = JoinInfo(JoinStatus.IDLE)
        }
    }

    suspend fun setBlocked(peerId: String, blocked: Boolean) = onEngine { setBlockedInternal(peerId, blocked) }

    private fun setBlockedInternal(peerId: String, blocked: Boolean) {
        val c = store.contact(peerId) ?: return
        if (blocked) {
            store.setContactState(peerId, ContactState.BLOCKED)
            store.failOutboxForPeer(peerId)
            transfers.discardPeer(peerId)
            links.values.filter { it.peerId == peerId }.forEach { closeLink(it, "blocked") }
        } else if (c.bundle != null) {
            store.setContactState(peerId, ContactState.ACCEPTED)
        } else {
            store.deleteContact(peerId)
        }
        publish()
    }

    suspend fun removeContact(peerId: String) = onEngine { removeInternal(peerId) }

    private fun removeInternal(peerId: String) {
        transfers.discardPeer(peerId)
        store.failOutboxForPeer(peerId)
        links.values.filter { it.peerId == peerId }.forEach { closeLink(it, "contact removed") }
        store.deleteContact(peerId)
        transfers.sweep()
        publish()
    }

    suspend fun renameContact(peerId: String, name: String?) = onEngine {
        store.setCustomName(peerId, name?.let { TextSafety.sanitizeName(it) })
    }

    suspend fun setVerified(peerId: String, v: Boolean) = onEngine { store.setVerified(peerId, v) }

    suspend fun setMuted(peerId: String, v: Boolean) = onEngine { store.setMuted(peerId, v) }

    /** User tapped "Connect": ignores the backoff window once. */
    fun connectNow(peerId: String) {
        scope.launch { requestConnect(peerId, force = true) }
    }

    fun connectToNearby(advertisedId: String) = connectNow(advertisedId)

    suspend fun wipeEverything() = onEngine {
        for (l in links.values.toList()) closeLink(l, "reset")
        for (t in transports) t.stop()
        transfers.deleteAll()
        store.wipeAll()
        me = null
        publish()
    }

    companion object {
        private const val AUTH_TIMEOUT_MS = 15_000L
        private const val RESP_TIMEOUT_MS = 10_000L
        private const val LIVENESS_INTERVAL_MS = 25_000L
        private const val ACK_WAIT_MS = 20_000L
        private const val MAX_LINKS = 24
        private const val MAX_STRANGER_LINKS = 6
        private const val MAX_OUTBOX_TOTAL = 2_000
        private const val MAX_OUTBOX_PEER = 500
    }
}
