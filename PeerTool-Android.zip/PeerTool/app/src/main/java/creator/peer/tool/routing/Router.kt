package creator.peer.tool.routing

import creator.peer.tool.storage.RoutePref
import creator.peer.tool.transport.TransportKind

data class LinkView(
    val id: String,
    val kind: TransportKind,
    val peerId: String?,
    val hint: String?,
    val up: Boolean,
    val authed: Boolean,
    val missed: Int,
    val ageMs: Long,
)

/** Pure routing policy: healthy authenticated links only; nearby preferred (no internet metadata), then older links. */
object Router {
    fun pick(links: List<LinkView>, pref: RoutePref): LinkView? {
        val usable = links.filter { it.up && it.authed }
        val allowed = when (pref) {
            RoutePref.AUTO -> usable
            RoutePref.INTERNET_ONLY -> usable.filter { it.kind == TransportKind.WEBRTC }
            RoutePref.NEARBY_ONLY -> usable.filter { it.kind == TransportKind.NEARBY }
        }
        if (allowed.isEmpty()) return null
        return allowed.sortedWith(
            compareBy<LinkView> { it.missed }
                .thenBy { if (it.kind == TransportKind.NEARBY) 0 else 1 }
                .thenByDescending { it.ageMs }
                .thenBy { it.id }
        ).first()
    }

    fun allows(kind: TransportKind, pref: RoutePref): Boolean = when (pref) {
        RoutePref.AUTO -> true
        RoutePref.INTERNET_ONLY -> kind == TransportKind.WEBRTC
        RoutePref.NEARBY_ONLY -> kind == TransportKind.NEARBY
    }
}
