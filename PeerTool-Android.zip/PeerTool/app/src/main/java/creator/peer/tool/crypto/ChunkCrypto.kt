package creator.peer.tool.crypto

import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Per-chunk AES-256-GCM for file transfer. The key is random per transfer and travels only inside the
 * end-to-end encrypted, signed file offer. Nonce = 4 zero bytes || 64-bit chunk index (unique per key);
 * the transfer id, index and chunk count are authenticated as associated data, so chunks cannot be
 * moved between transfers, positions or truncated transfers.
 */
object ChunkCrypto {
    const val TAG_BYTES = 16

    private fun nonce(index: Int): ByteArray =
        ByteBuffer.allocate(12).putInt(0).putLong(index.toLong()).array()

    private fun aad(transferId: String, index: Int, total: Int): ByteArray =
        "PT1|chunk|$transferId|$index|$total".toByteArray(Charsets.UTF_8)

    fun encrypt(key: ByteArray, transferId: String, index: Int, total: Int, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce(index)))
        c.updateAAD(aad(transferId, index, total))
        return c.doFinal(plain)
    }

    /** Throws [java.security.GeneralSecurityException] if the chunk was modified or does not belong here. */
    fun decrypt(key: ByteArray, transferId: String, index: Int, total: Int, cipherText: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce(index)))
        c.updateAAD(aad(transferId, index, total))
        return c.doFinal(cipherText)
    }

    fun sha256(): MessageDigest = MessageDigest.getInstance("SHA-256")
}
