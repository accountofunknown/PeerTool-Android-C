package creator.peer.tool.storage

/** Pure-data, versioned schema. Every step is a list of SQL statements, so it is unit-testable on the JVM. */
object Schema {
    const val VERSION = 4

    fun statements(from: Int, to: Int): List<String> {
        require(from in 0..to && to <= VERSION) { "bad migration range $from..$to" }
        return (from until to).flatMap { step(it + 1) }
    }

    private fun step(version: Int): List<String> = when (version) {
        1 -> listOf(
            """CREATE TABLE identity (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                peer_id TEXT NOT NULL,
                bundle BLOB NOT NULL,
                priv_blob BLOB NOT NULL,
                created_at INTEGER NOT NULL
            )""",
            """CREATE TABLE contacts (
                peer_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                custom_name TEXT,
                bundle BLOB,
                state TEXT NOT NULL,
                verified INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                last_seen_at INTEGER
            )""",
            """CREATE TABLE messages (
                id TEXT PRIMARY KEY,
                peer_id TEXT NOT NULL,
                direction INTEGER NOT NULL,
                body BLOB NOT NULL,
                reply_to TEXT,
                created_at INTEGER NOT NULL,
                received_at INTEGER,
                state TEXT NOT NULL,
                read INTEGER NOT NULL DEFAULT 0
            )""",
            "CREATE INDEX idx_messages_peer_time ON messages(peer_id, created_at)",
            """CREATE TABLE outbox (
                msg_id TEXT PRIMARY KEY,
                peer_id TEXT NOT NULL,
                envelope BLOB NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                next_attempt_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                last_error TEXT,
                FOREIGN KEY (msg_id) REFERENCES messages(id) ON DELETE CASCADE
            )""",
            "CREATE INDEX idx_outbox_due ON outbox(next_attempt_at)",
            """CREATE TABLE processed (
                peer_id TEXT NOT NULL,
                msg_id TEXT NOT NULL,
                at INTEGER NOT NULL,
                PRIMARY KEY (peer_id, msg_id)
            )""",
            """CREATE TABLE settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )""",
        )
        2 -> listOf(
            "ALTER TABLE messages ADD COLUMN read_at INTEGER",
            "ALTER TABLE messages ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE contacts ADD COLUMN muted INTEGER NOT NULL DEFAULT 0",
        )
        3 -> listOf(
            "ALTER TABLE messages ADD COLUMN my_reaction TEXT",
            "ALTER TABLE messages ADD COLUMN their_reaction TEXT",
            """CREATE TABLE transfers (
                id TEXT PRIMARY KEY,
                peer_id TEXT NOT NULL,
                outgoing INTEGER NOT NULL,
                name TEXT NOT NULL,
                mime TEXT NOT NULL,
                size INTEGER NOT NULL,
                chunk_size INTEGER NOT NULL,
                chunks INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                key BLOB NOT NULL,
                state TEXT NOT NULL,
                file_name TEXT,
                done_chunks INTEGER NOT NULL DEFAULT 0,
                bitmap BLOB,
                updated_at INTEGER NOT NULL,
                error TEXT,
                FOREIGN KEY (id) REFERENCES messages(id) ON DELETE CASCADE
            )""",
            "CREATE INDEX idx_transfers_peer ON transfers(peer_id)",
        )
        4 -> listOf(
            "ALTER TABLE contacts ADD COLUMN handle TEXT",
        )
        else -> error("unknown schema step $version")
    }
}
