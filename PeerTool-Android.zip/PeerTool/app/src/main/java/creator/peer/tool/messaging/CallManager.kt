package creator.peer.tool.messaging

import android.content.Context
import android.media.AudioManager
import creator.peer.tool.core.Clock
import creator.peer.tool.core.DiagLog
import creator.peer.tool.core.Ids
import creator.peer.tool.protocol.Inner
import creator.peer.tool.storage.Settings
import creator.peer.tool.transport.WebRtcUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.webrtc.AudioSource
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule

enum class CallPhase { OUTGOING, INCOMING, CONNECTING, ACTIVE, ENDED }

data class CallInfo(
    val callId: String,
    val peerId: String,
    val peerName: String,
    val video: Boolean,
    val outgoing: Boolean,
    val phase: CallPhase,
    val activeSince: Long? = null,
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val cameraOn: Boolean = false,
    val status: String = "",
)

/** What the call manager needs from the messaging engine. */
interface CallHost {
    /** End-to-end encrypted and signed, best-effort. */
    fun sendControl(peerId: String, inner: Inner): Boolean
    fun hasRoute(peerId: String): Boolean
    fun connect(peerId: String)
    fun contactName(peerId: String): String?
    fun isAcceptedContact(peerId: String): Boolean

    /** Adds a local-only line to the chat (e.g. "Missed call"). */
    fun addNote(peerId: String, text: String, outgoing: Boolean)

    /** Starts/stops the incoming-call notification and ringtone. */
    fun ringing(on: Boolean, peerId: String, name: String, video: Boolean)
}

/**
 * One-to-one voice/video calls over WebRTC media.
 *
 * Session set-up (offer, answer, ICE candidates, hang-up) is exchanged as end-to-end encrypted, signed messages over the
 * already-authenticated peer link, so the signaling server never sees it and the DTLS fingerprints inside the SDP are
 * authenticated by the contact's identity key. Media itself is DTLS-SRTP encrypted by WebRTC and flows directly between
 * the phones (or via your TURN server if the direct path fails). All state lives on the engine thread ([scope]).
 */
class CallManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settings: () -> Settings,
    private val host: CallHost,
    private val diag: DiagLog,
    private val clock: Clock,
) {
    private class ActiveCall(val callId: String, val peerId: String, val video: Boolean, val outgoing: Boolean) {
        var connectedAt = 0L
    }

    private val _info = MutableStateFlow<CallInfo?>(null)
    val info: StateFlow<CallInfo?> = _info.asStateFlow()
    private val _local = MutableStateFlow<VideoTrack?>(null)
    val localVideo: StateFlow<VideoTrack?> = _local.asStateFlow()
    private val _remote = MutableStateFlow<VideoTrack?>(null)
    val remoteVideo: StateFlow<VideoTrack?> = _remote.asStateFlow()

    private var cur: ActiveCall? = null
    private var pendingOffer: Inner.CallOffer? = null
    private var pc: PeerConnection? = null
    private var remoteSet = false
    private val pendingIce = ArrayList<IceCandidate>()
    private var timeoutJob: Job? = null
    private var disconnectJob: Job? = null

    private var audioSource: AudioSource? = null
    private var audioTrack: MediaStreamTrack? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: VideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null

    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private val audioManager: AudioManager? = context.getSystemService(AudioManager::class.java)

    private fun err(e: Throwable) = diag.add("call: observer error ${e.javaClass.simpleName}")

    /** Shared EGL context for renderers; must be the one the factory and camera use. */
    fun eglBaseContext(): EglBase.Context = ensureFactory().second.eglBaseContext

    @Synchronized
    private fun ensureFactory(): Pair<PeerConnectionFactory, EglBase> {
        val f = factory
        val e = egl
        if (f != null && e != null) return f to e
        WebRtcUtil.ensureInit(context)
        val eglBase = EglBase.create()
        val adm = JavaAudioDeviceModule.builder(context.applicationContext).createAudioDeviceModule()
        val created = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        egl = eglBase
        factory = created
        return created to eglBase
    }

    // ------------------------------------------------------------------ public API (any thread)

    fun start(peerId: String, video: Boolean) {
        scope.launch { startInternal(peerId, video) }
    }

    fun answer(withCamera: Boolean) {
        scope.launch { answerInternal(withCamera) }
    }

    fun decline() {
        scope.launch {
            val c = cur ?: return@launch
            if (c.outgoing || _info.value?.phase != CallPhase.INCOMING) return@launch
            end(c.callId, "Declined", "declined")
        }
    }

    fun hangup() {
        scope.launch {
            val c = cur ?: return@launch
            end(c.callId, if (c.connectedAt > 0L) "Call ended" else "Cancelled", "hangup")
        }
    }

    fun dismissEnded() {
        scope.launch { if (_info.value?.phase == CallPhase.ENDED) _info.value = null }
    }

    fun toggleMute() {
        scope.launch {
            val t = audioTrack ?: return@launch
            val muted = !(_info.value?.muted ?: false)
            t.setEnabled(!muted)
            _info.value = _info.value?.copy(muted = muted)
        }
    }

    fun toggleSpeaker() {
        scope.launch {
            val on = !(_info.value?.speaker ?: false)
            setSpeaker(on)
            _info.value = _info.value?.copy(speaker = on)
        }
    }

    fun toggleCamera() {
        scope.launch {
            val t = videoTrack ?: return@launch
            val on = !(_info.value?.cameraOn ?: false)
            t.setEnabled(on)
            _info.value = _info.value?.copy(cameraOn = on)
        }
    }

    fun switchCamera() {
        scope.launch {
            try {
                (capturer as? CameraVideoCapturer)?.switchCamera(null)
            } catch (e: Throwable) {
                diag.add("call: camera switch failed")
            }
        }
    }

    // ------------------------------------------------------------------ outgoing

    private suspend fun startInternal(peerId: String, video: Boolean) {
        if (cur != null || !host.isAcceptedContact(peerId)) return
        val callId = Ids.newMessageId()
        val call = ActiveCall(callId, peerId, video, true)
        cur = call
        _info.value = CallInfo(
            callId, peerId, host.contactName(peerId) ?: "Contact", video, true, CallPhase.OUTGOING,
            speaker = video, cameraOn = video, status = "Calling…",
        )
        diag.add("call: outgoing ${if (video) "video" else "voice"}")
        var tries = 0
        while (!host.hasRoute(peerId) && tries < 15) {
            host.connect(peerId)
            delay(1_000)
            tries++
            if (cur !== call) return
        }
        if (cur !== call) return
        if (!host.hasRoute(peerId)) {
            end(callId, "Couldn't reach them", null)
            return
        }
        if (hideIpWithoutTurn()) {
            end(callId, "Hide-my-IP needs a TURN server (Settings \u2192 Network)", null)
            return
        }
        audioStart(video)
        val p = createPc(callId)
        if (p == null) {
            end(callId, "Call failed", null)
            return
        }
        pc = p
        try {
            addMedia(p, video)
        } catch (e: Throwable) {
            end(callId, "Microphone or camera unavailable", null)
            return
        }
        p.createOffer(WebRtcUtil.sdpObserver(this::err, onCreated = { sdp ->
            p.setLocalDescription(WebRtcUtil.sdpObserver(this::err, onSet = {
                scope.launch {
                    if (cur !== call) return@launch
                    val ok = host.sendControl(peerId, Inner.CallOffer(callId, video, (p.localDescription ?: sdp).description))
                    if (!ok) end(callId, "Couldn't reach them", null)
                }
            }, onFailure = { scope.launch { end(callId, "Call failed", "failed") } }), sdp)
        }, onFailure = { scope.launch { end(callId, "Call failed", "failed") } }), MediaConstraints())
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(RING_TIMEOUT_MS)
            if (cur === call && _info.value?.phase == CallPhase.OUTGOING) end(callId, "No answer", "timeout")
        }
    }

    // ------------------------------------------------------------------ incoming

    fun onOffer(peerId: String, offer: Inner.CallOffer) {
        if (!settings().allowCalls) {
            host.sendControl(peerId, Inner.CallEnd(offer.callId, "declined"))
            return
        }
        if (cur != null) {
            host.sendControl(peerId, Inner.CallEnd(offer.callId, "busy"))
            return
        }
        val call = ActiveCall(offer.callId, peerId, offer.video, false)
        cur = call
        pendingOffer = offer
        val name = host.contactName(peerId) ?: "Contact"
        _info.value = CallInfo(
            offer.callId, peerId, name, offer.video, false, CallPhase.INCOMING,
            speaker = offer.video, cameraOn = offer.video,
            status = if (offer.video) "Incoming video call" else "Incoming voice call",
        )
        host.ringing(true, peerId, name, offer.video)
        diag.add("call: incoming ${if (offer.video) "video" else "voice"}")
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(RING_TIMEOUT_MS)
            if (cur === call && _info.value?.phase == CallPhase.INCOMING) end(offer.callId, "Missed call", null)
        }
    }

    private suspend fun answerInternal(withCamera: Boolean) {
        val c = cur ?: return
        val offer = pendingOffer ?: return
        if (c.outgoing || _info.value?.phase != CallPhase.INCOMING) return
        pendingOffer = null
        host.ringing(false, c.peerId, "", c.video)
        if (hideIpWithoutTurn()) {
            end(c.callId, "Hide-my-IP needs a TURN server (Settings \u2192 Network)", "failed")
            return
        }
        val wantVideo = c.video && withCamera
        _info.value = _info.value?.copy(phase = CallPhase.CONNECTING, status = "Connecting…", cameraOn = wantVideo)
        audioStart(c.video)
        val p = createPc(c.callId)
        if (p == null) {
            end(c.callId, "Call failed", "failed")
            return
        }
        pc = p
        startConnectTimeout(c)
        val remote = SessionDescription(SessionDescription.Type.OFFER, offer.sdp)
        p.setRemoteDescription(WebRtcUtil.sdpObserver(this::err, onSet = {
            scope.launch {
                if (cur !== c) return@launch
                remoteSet = true
                flushIce(p)
                try {
                    addMedia(p, wantVideo)
                } catch (e: Throwable) {
                    end(c.callId, "Microphone or camera unavailable", "failed")
                    return@launch
                }
                p.createAnswer(WebRtcUtil.sdpObserver(this::err, onCreated = { ans ->
                    p.setLocalDescription(WebRtcUtil.sdpObserver(this::err, onSet = {
                        scope.launch {
                            if (cur === c) host.sendControl(c.peerId, Inner.CallAnswer(c.callId, (p.localDescription ?: ans).description))
                        }
                    }, onFailure = { scope.launch { end(c.callId, "Call failed", "failed") } }), ans)
                }, onFailure = { scope.launch { end(c.callId, "Call failed", "failed") } }), MediaConstraints())
            }
        }, onFailure = { scope.launch { end(c.callId, "Call failed", "failed") } }), remote)
    }

    fun onAnswer(peerId: String, ans: Inner.CallAnswer) {
        val c = cur ?: return
        val p = pc ?: return
        if (!c.outgoing || c.peerId != peerId || c.callId != ans.callId || _info.value?.phase != CallPhase.OUTGOING) return
        _info.value = _info.value?.copy(phase = CallPhase.CONNECTING, status = "Connecting…")
        startConnectTimeout(c)
        p.setRemoteDescription(WebRtcUtil.sdpObserver(this::err, onSet = {
            scope.launch {
                if (cur !== c) return@launch
                remoteSet = true
                flushIce(p)
            }
        }, onFailure = { scope.launch { end(c.callId, "Call failed", "failed") } }), SessionDescription(SessionDescription.Type.ANSWER, ans.sdp))
    }

    fun onIce(peerId: String, ice: Inner.CallIce) {
        val c = cur ?: return
        if (c.peerId != peerId || c.callId != ice.callId) return
        val cand = IceCandidate(ice.mid, ice.index, ice.candidate)
        val p = pc
        if (remoteSet && p != null) p.addIceCandidate(cand) else if (pendingIce.size < 64) pendingIce.add(cand)
    }

    fun onEnd(peerId: String, e: Inner.CallEnd) {
        val c = cur ?: return
        if (c.peerId != peerId || c.callId != e.callId) return
        val text = when (e.reason) {
            "declined" -> "Declined"
            "busy" -> "Busy"
            "timeout" -> if (c.outgoing) "No answer" else "Missed call"
            "failed" -> "Connection failed"
            else -> if (!c.outgoing && c.connectedAt == 0L) "Missed call" else "Call ended"
        }
        end(c.callId, text, null)
    }

    // ------------------------------------------------------------------ peer connection

    private fun flushIce(p: PeerConnection) {
        for (cnd in pendingIce) p.addIceCandidate(cnd)
        pendingIce.clear()
    }

    private fun startConnectTimeout(c: ActiveCall) {
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(CONNECT_TIMEOUT_MS)
            if (cur === c && _info.value?.phase != CallPhase.ACTIVE) end(c.callId, "Connection failed", "failed")
        }
    }

    private fun hideIpWithoutTurn(): Boolean = settings().callHideIp && settings().turnUrl.isBlank()

    private fun iceServers(): List<PeerConnection.IceServer> {
        val s = settings()
        val list = ArrayList<PeerConnection.IceServer>()
        if (s.stunUrl.isNotBlank()) list.add(PeerConnection.IceServer.builder(s.stunUrl.trim()).createIceServer())
        if (s.turnUrl.isNotBlank()) {
            list.add(
                PeerConnection.IceServer.builder(s.turnUrl.trim()).setUsername(s.turnUser).setPassword(s.turnCred).createIceServer()
            )
        }
        return list
    }

    private fun createPc(callId: String): PeerConnection? {
        return try {
            val f = ensureFactory().first
            val cfg = PeerConnection.RTCConfiguration(iceServers())
            cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            val s = settings()
            if (s.callHideIp && s.turnUrl.isNotBlank()) cfg.iceTransportsType = PeerConnection.IceTransportsType.RELAY
            val obs = WebRtcUtil.proxyOf(PeerConnection.Observer::class.java, this::err) { name, args ->
                when (name) {
                    "onIceCandidate" -> {
                        val c = args.getOrNull(0) as? IceCandidate
                        if (c != null) {
                            scope.launch {
                                val call = cur
                                if (call != null && call.callId == callId) {
                                    host.sendControl(call.peerId, Inner.CallIce(callId, c.sdpMid ?: "", c.sdpMLineIndex, c.sdp))
                                }
                            }
                        }
                    }
                    "onConnectionChange" -> {
                        val st = args.getOrNull(0) as? PeerConnection.PeerConnectionState
                        if (st != null) scope.launch { onConnState(callId, st) }
                    }
                    "onTrack" -> {
                        val tr = args.getOrNull(0) as? RtpTransceiver
                        val track = tr?.receiver?.track()
                        scope.launch { onRemoteTrack(callId, track) }
                    }
                    "onAddTrack" -> {
                        val rx = args.getOrNull(0) as? RtpReceiver
                        val track = rx?.track()
                        scope.launch { onRemoteTrack(callId, track) }
                    }
                }
            }
            f.createPeerConnection(cfg, obs)
        } catch (e: Throwable) {
            diag.add("call: could not create connection (${e.javaClass.simpleName})")
            null
        }
    }

    private fun onRemoteTrack(callId: String, track: MediaStreamTrack?) {
        if (cur?.callId != callId) return
        if (track is VideoTrack) {
            track.setEnabled(true)
            _remote.value = track
        }
    }

    private fun onConnState(callId: String, st: PeerConnection.PeerConnectionState) {
        val c = cur ?: return
        if (c.callId != callId) return
        when (st) {
            PeerConnection.PeerConnectionState.CONNECTED -> {
                disconnectJob?.cancel()
                if (c.connectedAt == 0L) {
                    c.connectedAt = clock.now()
                    timeoutJob?.cancel()
                    _info.value = _info.value?.copy(phase = CallPhase.ACTIVE, activeSince = c.connectedAt, status = "")
                    diag.add("call: connected")
                }
            }
            PeerConnection.PeerConnectionState.DISCONNECTED -> {
                disconnectJob?.cancel()
                disconnectJob = scope.launch {
                    delay(10_000)
                    if (cur === c) end(callId, "Connection lost", "failed")
                }
            }
            PeerConnection.PeerConnectionState.FAILED -> end(callId, "Connection failed", "failed")
            else -> Unit
        }
    }

    // ------------------------------------------------------------------ media

    private fun addMedia(p: PeerConnection, wantVideo: Boolean) {
        val f = ensureFactory().first
        val src = f.createAudioSource(MediaConstraints())
        val track = f.createAudioTrack("pt_audio", src)
        track.setEnabled(true)
        audioSource = src
        audioTrack = track
        p.addTrack(track, listOf("pt_stream"))
        if (wantVideo) startCamera(f, p)
    }

    private fun startCamera(f: PeerConnectionFactory, p: PeerConnection) {
        val enumerator = Camera2Enumerator(context)
        val names = enumerator.deviceNames
        val device = names.firstOrNull { enumerator.isFrontFacing(it) } ?: names.firstOrNull() ?: return
        val cap = enumerator.createCapturer(device, null) ?: return
        val eglBase = ensureFactory().second
        val h = SurfaceTextureHelper.create("pt_capture", eglBase.eglBaseContext)
        val vs = f.createVideoSource(cap.isScreencast)
        cap.initialize(h, context.applicationContext, vs.capturerObserver)
        cap.startCapture(CAPTURE_W, CAPTURE_H, CAPTURE_FPS)
        val vt = f.createVideoTrack("pt_video", vs)
        vt.setEnabled(true)
        capturer = cap
        helper = h
        videoSource = vs
        videoTrack = vt
        p.addTrack(vt, listOf("pt_stream"))
        _local.value = vt
    }

    @Suppress("DEPRECATION")
    private fun audioStart(speaker: Boolean) {
        val am = audioManager ?: return
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = speaker
    }

    @Suppress("DEPRECATION")
    private fun setSpeaker(on: Boolean) {
        audioManager?.isSpeakerphoneOn = on
    }

    @Suppress("DEPRECATION")
    private fun audioStop() {
        val am = audioManager ?: return
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    // ------------------------------------------------------------------ ending

    /** Ends the current call. [sendCode] (if not null) tells the peer why. */
    private fun end(callId: String, text: String, sendCode: String?) {
        val c = cur ?: return
        if (c.callId != callId) return
        timeoutJob?.cancel()
        disconnectJob?.cancel()
        host.ringing(false, c.peerId, "", c.video)
        if (sendCode != null) host.sendControl(c.peerId, Inner.CallEnd(callId, sendCode))
        val kind = if (c.video) "Video call" else "Voice call"
        val icon = if (c.video) "\uD83D\uDCF9" else "\uD83D\uDCDE"
        val note = when {
            c.connectedAt > 0L -> {
                val secs = ((clock.now() - c.connectedAt) / 1000).coerceAtLeast(0)
                "$icon $kind \u00B7 %d:%02d".format(secs / 60, secs % 60)
            }
            c.outgoing -> "$icon $kind \u2014 ${text.replaceFirstChar { it.lowercase() }}"
            text == "Missed call" -> "$icon Missed ${kind.lowercase()}"
            else -> "$icon $kind \u2014 ${text.replaceFirstChar { it.lowercase() }}"
        }
        host.addNote(c.peerId, note, c.outgoing)
        diag.add("call: ended ($text)")
        cur = null
        pendingOffer = null
        remoteSet = false
        pendingIce.clear()
        releaseMedia()
        audioStop()
        _info.value = _info.value?.copy(phase = CallPhase.ENDED, status = text, muted = false, activeSince = _info.value?.activeSince)
        scope.launch {
            delay(2_500)
            val i = _info.value
            if (i != null && i.callId == callId && i.phase == CallPhase.ENDED) _info.value = null
        }
    }

    private fun releaseMedia() {
        _local.value = null
        _remote.value = null
        val p = pc
        val at = audioTrack
        val asrc = audioSource
        val vt = videoTrack
        val vsrc = videoSource
        val cap = capturer
        val h = helper
        pc = null
        audioTrack = null
        audioSource = null
        videoTrack = null
        videoSource = null
        capturer = null
        helper = null
        try {
            cap?.stopCapture()
        } catch (_: Throwable) {
        }
        try {
            p?.close()
        } catch (_: Throwable) {
        }
        // Give the UI a moment to detach its renderers before native objects are freed.
        scope.launch {
            delay(600)
            try { cap?.dispose() } catch (_: Throwable) { }
            try { vt?.dispose() } catch (_: Throwable) { }
            try { vsrc?.dispose() } catch (_: Throwable) { }
            try { h?.dispose() } catch (_: Throwable) { }
            try { at?.dispose() } catch (_: Throwable) { }
            try { asrc?.dispose() } catch (_: Throwable) { }
            try { p?.dispose() } catch (_: Throwable) { }
        }
    }

    companion object {
        private const val RING_TIMEOUT_MS = 45_000L
        private const val CONNECT_TIMEOUT_MS = 30_000L
        private const val CAPTURE_W = 640
        private const val CAPTURE_H = 480
        private const val CAPTURE_FPS = 24
    }
}
