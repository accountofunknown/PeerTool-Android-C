package creator.peer.tool

import creator.peer.tool.routing.LinkView
import creator.peer.tool.routing.Router
import creator.peer.tool.storage.RoutePref
import creator.peer.tool.transport.TransportKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RouterTest {
    private fun link(
        id: String, kind: TransportKind, up: Boolean = true, authed: Boolean = true, missed: Int = 0, age: Long = 1000,
    ) = LinkView(id, kind, "peer", "peer", up, authed, missed, age)

    @Test
    fun ignoresUnauthenticatedOrDownLinks() {
        val links = listOf(
            link("a", TransportKind.WEBRTC, authed = false),
            link("b", TransportKind.NEARBY, up = false),
        )
        assertNull(Router.pick(links, RoutePref.AUTO))
    }

    @Test
    fun autoPrefersHealthyNearbyThenInternet() {
        val web = link("web", TransportKind.WEBRTC)
        val near = link("near", TransportKind.NEARBY)
        assertEquals("near", Router.pick(listOf(web, near), RoutePref.AUTO)?.id)
        val degradedNear = link("near", TransportKind.NEARBY, missed = 1)
        assertEquals("web", Router.pick(listOf(web, degradedNear), RoutePref.AUTO)?.id)
    }

    @Test
    fun routePreferenceIsHonoured() {
        val web = link("web", TransportKind.WEBRTC)
        val near = link("near", TransportKind.NEARBY)
        assertEquals("web", Router.pick(listOf(web, near), RoutePref.INTERNET_ONLY)?.id)
        assertEquals("near", Router.pick(listOf(web, near), RoutePref.NEARBY_ONLY)?.id)
        assertNull(Router.pick(listOf(web), RoutePref.NEARBY_ONLY))
        assertNull(Router.pick(listOf(near), RoutePref.INTERNET_ONLY))
    }

    @Test
    fun allowsMatchesPreference() {
        assertEquals(true, Router.allows(TransportKind.NEARBY, RoutePref.AUTO))
        assertEquals(false, Router.allows(TransportKind.NEARBY, RoutePref.INTERNET_ONLY))
        assertEquals(false, Router.allows(TransportKind.WEBRTC, RoutePref.NEARBY_ONLY))
    }
}
