package creator.peer.tool

import creator.peer.tool.core.B64
import creator.peer.tool.crypto.ChunkCrypto
import creator.peer.tool.crypto.IdentityKeys
import creator.peer.tool.crypto.PeerCrypto
import creator.peer.tool.protocol.Inner
import creator.peer.tool.protocol.InnerCodec
import creator.peer.tool.protocol.Limits
import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FileFeatureTest {
    private val key = ByteArray(32) { (it * 3).toByte() }
    private val plain = ByteArray(Limits.CHUNK_SIZE) { (it % 251).toByte() }

    @Test
    fun chunkRoundTripAndBinding() {
        val ct = ChunkCrypto.encrypt(key, "t1", 7, 100, plain)
        assertEquals(plain.size + ChunkCrypto.TAG_BYTES, ct.size)
        assertArrayEquals(plain, ChunkCrypto.decrypt(key, "t1", 7, 100, ct))
        // different index, transfer id, total or key must all fail
        for (bad in listOf(
            { ChunkCrypto.decrypt(key, "t1", 8, 100, ct) },
            { ChunkCrypto.decrypt(key, "t2", 7, 100, ct) },
            { ChunkCrypto.decrypt(key, "t1", 7, 101, ct) },
            { ChunkCrypto.decrypt(ByteArray(32), "t1", 7, 100, ct) },
        )) {
            try {
                bad()
                fail("must not decrypt")
            } catch (expected: java.security.GeneralSecurityException) {
            }
        }
        val tampered = ct.copyOf().also { it[5] = (it[5].toInt() xor 0x40).toByte() }
        try {
            ChunkCrypto.decrypt(key, "t1", 7, 100, tampered)
            fail("tampered chunk must fail")
        } catch (expected: java.security.GeneralSecurityException) {
        }
    }

    @Test
    fun identicalChunkEncryptsDeterministicallyButDifferentIndicesDiffer() {
        val a = ChunkCrypto.encrypt(key, "t1", 1, 10, plain)
        assertArrayEquals(a, ChunkCrypto.encrypt(key, "t1", 1, 10, plain))
        assertFalse(a.contentEquals(ChunkCrypto.encrypt(key, "t1", 2, 10, plain)))
    }

    private fun fileInner() = Inner.File("photo.jpg", "image/jpeg", 40_000L, "a".repeat(64), Limits.CHUNK_SIZE, key, 9L)

    @Test
    fun fileOfferRoundTrip() {
        val d = InnerCodec.decode(InnerCodec.encode(fileInner())) as Inner.File
        assertEquals("photo.jpg", d.name)
        assertEquals("image/jpeg", d.mime)
        assertEquals(40_000L, d.size)
        assertEquals(Limits.CHUNK_SIZE, d.chunkSize)
        assertArrayEquals(key, d.key)
    }

    @Test
    fun malformedFileOffersAreRejected() {
        fun base(): JSONObject = JSONObject(String(InnerCodec.encode(fileInner())))
        fun decode(o: JSONObject) = InnerCodec.decode(o.toString().toByteArray())
        assertNotNull(decode(base()))
        assertNull(decode(base().put("sz", 0)))
        assertNull(decode(base().put("sz", Limits.MAX_FILE_BYTES + 1)))
        assertNull(decode(base().put("cs", 1024)))
        assertNull(decode(base().put("h", "xyz")))
        assertNull(decode(base().put("k", B64.enc(ByteArray(16)))))
        assertNull(decode(base().put("m", "not a mime")))
        assertNull(decode(base().put("n", "")))
    }

    @Test
    fun controlMessagesRoundTripWithLimits() {
        assertEquals(Inner.FileReq("t", listOf(0, 5, 9)), InnerCodec.decode(InnerCodec.encode(Inner.FileReq("t", listOf(0, 5, 9)))))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.FileReq("t", emptyList()))))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.FileReq("t", (0..Limits.MAX_REQ_INDICES).toList()))))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.FileReq("t", listOf(-1)))))
        assertEquals(Inner.FileDone("t"), InnerCodec.decode(InnerCodec.encode(Inner.FileDone("t"))))
        assertEquals(Inner.FileCancel("t", "why"), InnerCodec.decode(InnerCodec.encode(Inner.FileCancel("t", "why"))))
        assertEquals(Inner.React("m", "\uD83D\uDC4D"), InnerCodec.decode(InnerCodec.encode(Inner.React("m", "\uD83D\uDC4D"))))
        assertEquals(Inner.React("m", ""), InnerCodec.decode(InnerCodec.encode(Inner.React("m", ""))))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.React("m", "x".repeat(Limits.MAX_EMOJI_CHARS + 1)))))
    }

    @Test
    fun vanityPrefixValidation() {
        assertTrue(PeerCrypto.isValidVanityPrefix("a"))
        assertTrue(PeerCrypto.isValidVanityPrefix("ab27"))
        assertFalse(PeerCrypto.isValidVanityPrefix(""))
        assertFalse(PeerCrypto.isValidVanityPrefix("abcde"))
        assertFalse(PeerCrypto.isValidVanityPrefix("A"))
        assertFalse(PeerCrypto.isValidVanityPrefix("a1"))
    }

    @Test
    fun vanityIdentityIsAFullWorkingIdentity() {
        val k = IdentityKeys.generateVanity("a", 2, { }, { false })
        assertNotNull(k)
        assertTrue(k!!.peerId.startsWith("pta"))
        assertTrue(PeerCrypto.isValidPeerId(k.peerId))
        assertEquals(k.peerId, PeerCrypto.peerIdOf(k.bundle))
        assertTrue(PeerCrypto.validateBundle(k.bundle))
        val ctx = "c".toByteArray()
        val ct = PeerCrypto.encryptFor(k.bundle, "hi".toByteArray(), ctx)!!
        assertArrayEquals("hi".toByteArray(), k.decrypt(ct, ctx))
        assertTrue(PeerCrypto.verify(k.bundle, k.sign("m".toByteArray()), "m".toByteArray()))
        // survives serialization like any identity
        assertEquals(k.peerId, IdentityKeys.deserialize(k.serializePrivate()).peerId)
    }

    @Test
    fun vanitySearchCanBeCancelled() {
        // 4 letters would take very long on average; cancel immediately and expect null without hanging
        val k = IdentityKeys.generateVanity("zzzz", 2, { }, { true })
        assertNull(k)
    }
}
