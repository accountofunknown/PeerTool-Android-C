package creator.peer.tool

import creator.peer.tool.core.FriendlyName
import creator.peer.tool.crypto.InviteCode
import creator.peer.tool.protocol.Handles
import creator.peer.tool.protocol.HelloBody
import creator.peer.tool.protocol.ShareLink
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InviteAndHandleTest {
    @Test
    fun generatedCodesUseTheSafeAlphabet() {
        repeat(50) {
            val c = InviteCode.generate()
            assertEquals(InviteCode.LENGTH, c.length)
            assertTrue(c.all { it in InviteCode.ALPHABET })
        }
        assertEquals("ABCD-EFGH", InviteCode.format("ABCDEFGH"))
        assertEquals(32, InviteCode.ALPHABET.toSet().size)
    }

    @Test
    fun normalizeAcceptsHumanTypingAndRejectsJunk() {
        assertEquals("K7M4QX2P", InviteCode.normalize("k7m4-qx2p"))
        assertEquals("K7M4QX2P", InviteCode.normalize("  K7M4 QX2P "))
        assertNull(InviteCode.normalize("K7M4QX2"))
        assertNull(InviteCode.normalize("K7M4QX2PP"))
        assertNull(InviteCode.normalize("K7M4QX20")) // 0 is not in the alphabet
        assertNull(InviteCode.normalize("K7M4QXIO"))
        assertNull(InviteCode.normalize(""))
    }

    @Test
    fun derivationIsDeterministicAndSeparatesCodes() {
        val a1 = InviteCode.derive("K7M4QX2P")
        val a2 = InviteCode.derive("K7M4QX2P")
        val b = InviteCode.derive("K7M4QX2Q")
        assertEquals(a1.rendezvousId, a2.rendezvousId)
        assertArrayEquals(a1.key, a2.key)
        assertNotEquals(a1.rendezvousId, b.rendezvousId)
        assertFalse(a1.key.contentEquals(b.key))
        assertTrue(InviteCode.isRendezvousId(a1.rendezvousId))
        assertEquals(27, a1.rendezvousId.length) // never collides with the 28-char real peer IDs
        assertEquals(32, a1.key.size)
    }

    @Test
    fun proofsAreBoundToDirectionAndBothIds() {
        val k = InviteCode.derive("AAAAAAAA").key
        val req = InviteCode.proofRequest(k, "ptINVITEE", "ptINVITER")
        assertTrue(InviteCode.same(req, InviteCode.proofRequest(k, "ptINVITEE", "ptINVITER")))
        assertFalse(InviteCode.same(req, InviteCode.proofRequest(k, "ptOTHER", "ptINVITER")))
        assertFalse(InviteCode.same(req, InviteCode.proofRequest(k, "ptINVITEE", "ptOTHER")))
        assertFalse(InviteCode.same(req, InviteCode.proofAccept(k, "ptINVITER", "ptINVITEE")))
        val other = InviteCode.derive("BBBBBBBB").key
        assertFalse(InviteCode.same(req, InviteCode.proofRequest(other, "ptINVITEE", "ptINVITER")))
    }

    @Test
    fun handlesAreNormalizedAndValidated() {
        assertEquals("shashank", Handles.normalize("@Shashank"))
        assertEquals("ok_name1", Handles.normalize(" ok_name1 "))
        assertNull(Handles.normalize("ab"))
        assertNull(Handles.normalize("has space"))
        assertNull(Handles.normalize("a".repeat(21)))
        assertNull(Handles.normalize("bad-char"))
        assertNull(Handles.normalize(""))
    }

    @Test
    fun helloBodyRoundTripAndHardening() {
        val proof = ByteArray(32) { it.toByte() }
        val h = HelloBody.decode(HelloBody.encode("Anna", "anna_k", proof))
        assertEquals("Anna", h.name)
        assertEquals("anna_k", h.handle)
        assertArrayEquals(proof, h.proof)
        val plain = HelloBody.decode(HelloBody.encode("Bob", "", null))
        assertEquals("Bob", plain.name)
        assertEquals("", plain.handle)
        assertNull(plain.proof)
        // a hostile handle is dropped instead of displayed, and absurd proofs are ignored
        val bad = HelloBody.decode("""{"n":"X","h":"<b>x</b>","p":"AAAA"}""".toByteArray())
        assertEquals("", bad.handle)
        assertNull(bad.proof)
        val junk = HelloBody.decode("not json".toByteArray())
        assertEquals("", junk.name)
    }

    @Test
    fun shareLinkCarriesAHandle() {
        val bundle = ByteArray(120) { (it * 5).toByte() }
        val link = ShareLink.build(bundle, "Zoë", "zoe_99")
        val d = ShareLink.parseFull(link)
        assertNotNull(d)
        assertArrayEquals(bundle, d!!.bundle)
        assertEquals("Zoë", d.name)
        assertEquals("zoe_99", d.handle)
        // links without a handle (v1.0) still parse
        assertEquals("", ShareLink.parseFull(ShareLink.build(bundle, "Zoë"))!!.handle)
        // an invalid handle in a link is ignored, not trusted
        assertEquals("", ShareLink.parseFull(ShareLink.build(bundle, "Zoë") + "&h=%3Cscript%3E")!!.handle)
    }

    @Test
    fun friendlyNameIsStableAndWellFormed() {
        val id = "ptabcdefghijklmnopqrstuvwxy"
        assertEquals(FriendlyName.of(id), FriendlyName.of(id))
        assertTrue(Regex("^[a-z]+-[a-z]+-[0-9]{2}$").matches(FriendlyName.of(id)))
        val names = (0 until 200).map { FriendlyName.of("pt" + it.toString().padStart(26, 'a')) }.toSet()
        assertTrue("labels should spread out, got ${names.size}", names.size > 150)
    }
}

class SchemaV4Test {
    @Test
    fun upgradeFromV3AddsContactHandle() {
        java.sql.DriverManager.getConnection("jdbc:sqlite::memory:").use { c ->
            c.createStatement().use { st ->
                creator.peer.tool.storage.Schema.statements(0, 3).forEach { st.execute(it) }
                st.execute("INSERT INTO contacts(peer_id,name,state,verified,created_at) VALUES('ptA','Alice','ACCEPTED',1,1)")
                creator.peer.tool.storage.Schema.statements(3, 4).forEach { st.execute(it) }
                st.executeQuery("SELECT name, handle FROM contacts").use {
                    assertTrue(it.next())
                    assertEquals("Alice", it.getString(1))
                    assertNull(it.getString(2))
                }
            }
        }
    }
}
