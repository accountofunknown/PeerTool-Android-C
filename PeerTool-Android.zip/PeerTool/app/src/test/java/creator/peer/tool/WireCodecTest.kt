package creator.peer.tool

import creator.peer.tool.protocol.Envelope
import creator.peer.tool.protocol.Inner
import creator.peer.tool.protocol.InnerCodec
import creator.peer.tool.protocol.Kind
import creator.peer.tool.protocol.Limits
import creator.peer.tool.protocol.ShareLink
import creator.peer.tool.protocol.WireCodec
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WireCodecTest {
    private fun env(body: ByteArray = byteArrayOf(1, 2, 3)) =
        Envelope(Kind.MSG, "abc123", "ptfrom", "ptto", 1_700_000_000_000L, body, byteArrayOf(9, 8), null)

    @Test
    fun envelopeRoundTrip() {
        val e = env()
        val d = WireCodec.decode(WireCodec.encode(e))
        assertNotNull(d)
        assertEquals(e.kind, d!!.kind)
        assertEquals(e.id, d.id)
        assertEquals(e.from, d.from)
        assertEquals(e.to, d.to)
        assertEquals(e.ts, d.ts)
        assertArrayEquals(e.body, d.body)
        assertArrayEquals(e.sig, d.sig)
        assertNull(d.bundle)
    }

    @Test
    fun rejectsGarbageUnknownKindAndOversize() {
        assertNull(WireCodec.decode(ByteArray(0)))
        assertNull(WireCodec.decode("not json".toByteArray()))
        assertNull(WireCodec.decode("""{"v":1,"k":"evil","id":"a","f":"b","t":"c","ts":1,"c":""}""".toByteArray()))
        assertNull(WireCodec.decode("""{"v":2,"k":"msg","id":"a","f":"b","t":"c","ts":1,"c":""}""".toByteArray()))
        assertNull(WireCodec.decode(ByteArray(Limits.MAX_ENVELOPE_BYTES + 1) { 'a'.code.toByte() }))
        val longId = "x".repeat(Limits.MAX_FIELD + 1)
        assertNull(WireCodec.decode("""{"v":1,"k":"msg","id":"$longId","f":"b","t":"c","ts":1,"c":""}""".toByteArray()))
    }

    @Test
    fun signingInputChangesWithEveryField() {
        val base = WireCodec.signingInput(env())
        val variants = listOf(
            Envelope(Kind.REQ, "abc123", "ptfrom", "ptto", 1_700_000_000_000L, byteArrayOf(1, 2, 3)),
            Envelope(Kind.MSG, "abc124", "ptfrom", "ptto", 1_700_000_000_000L, byteArrayOf(1, 2, 3)),
            Envelope(Kind.MSG, "abc123", "ptfrom2", "ptto", 1_700_000_000_000L, byteArrayOf(1, 2, 3)),
            Envelope(Kind.MSG, "abc123", "ptfrom", "ptto2", 1_700_000_000_000L, byteArrayOf(1, 2, 3)),
            Envelope(Kind.MSG, "abc123", "ptfrom", "ptto", 1_700_000_000_001L, byteArrayOf(1, 2, 3)),
            Envelope(Kind.MSG, "abc123", "ptfrom", "ptto", 1_700_000_000_000L, byteArrayOf(1, 2, 4)),
        )
        for (v in variants) assertFalse(base.contentEquals(WireCodec.signingInput(v)))
    }

    @Test
    fun innerTextRoundTripAndLimits() {
        val t = Inner.Text("héllo 🌍 مرحبا", "reply-id", 5L)
        assertEquals(t, InnerCodec.decode(InnerCodec.encode(t)))
        val tooLong = Inner.Text("a".repeat(Limits.MAX_TEXT_BYTES + 1), null, 1L)
        assertNull(InnerCodec.decode(InnerCodec.encode(tooLong)))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.Text("   ", null, 1L))))
    }

    @Test
    fun innerReceiptsAreBounded() {
        val ids = (1..Limits.MAX_IDS_PER_RECEIPT).map { "id$it" }
        assertEquals(Inner.Ack(ids), InnerCodec.decode(InnerCodec.encode(Inner.Ack(ids))))
        val tooMany = (1..Limits.MAX_IDS_PER_RECEIPT + 1).map { "id$it" }
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.Ack(tooMany))))
        assertNull(InnerCodec.decode(InnerCodec.encode(Inner.Read(emptyList()))))
        assertEquals(Inner.Delete("m1"), InnerCodec.decode(InnerCodec.encode(Inner.Delete("m1"))))
    }

    @Test
    fun shareLinkRoundTrip() {
        val bundle = ByteArray(300) { (it * 7).toByte() }
        val link = ShareLink.build(bundle, "Zoë & Co")
        assertTrue(link.startsWith("peertool://add?"))
        val parsed = ShareLink.parse(link)
        assertNotNull(parsed)
        assertArrayEquals(bundle, parsed!!.first)
        assertEquals("Zoë & Co", parsed.second)
        assertNull(ShareLink.parse("https://example.com"))
        assertNull(ShareLink.parse("peertool://add?n=x"))
    }
}
