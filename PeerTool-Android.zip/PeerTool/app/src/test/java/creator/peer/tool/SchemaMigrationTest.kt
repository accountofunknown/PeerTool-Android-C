package creator.peer.tool

import creator.peer.tool.storage.Schema
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.sql.Connection
import java.sql.DriverManager

/** Runs the real migration SQL against an in-memory SQLite (JDBC) database. */
class SchemaMigrationTest {
    private fun open(): Connection {
        val c = DriverManager.getConnection("jdbc:sqlite::memory:")
        c.createStatement().use { it.execute("PRAGMA foreign_keys = ON") }
        return c
    }

    private fun run(c: Connection, sql: List<String>) {
        c.createStatement().use { st -> sql.forEach { st.execute(it) } }
    }

    private fun columns(c: Connection, table: String): Set<String> =
        c.createStatement().use { st ->
            st.executeQuery("PRAGMA table_info($table)").use { rs ->
                val out = HashSet<String>()
                while (rs.next()) out.add(rs.getString("name"))
                out
            }
        }

    private fun count(c: Connection, table: String): Int =
        c.createStatement().use { st -> st.executeQuery("SELECT COUNT(*) FROM $table").use { it.next(); it.getInt(1) } }

    @Test
    fun freshInstallCreatesLatestSchema() {
        open().use { c ->
            run(c, Schema.statements(0, Schema.VERSION))
            assertTrue(columns(c, "messages").containsAll(setOf("id", "body", "state", "read_at", "pinned")))
            assertTrue(columns(c, "contacts").contains("muted"))
            for (t in listOf("identity", "contacts", "messages", "outbox", "processed", "settings")) {
                assertTrue("missing table $t", columns(c, t).isNotEmpty())
            }
        }
    }

    @Test
    fun upgradeFromV1KeepsDataAndAddsColumns() {
        open().use { c ->
            run(c, Schema.statements(0, 1))
            assertFalse(columns(c, "messages").contains("read_at"))
            run(
                c,
                listOf(
                    "INSERT INTO contacts(peer_id,name,state,verified,created_at) VALUES('ptA','Alice','ACCEPTED',1,1)",
                    "INSERT INTO messages(id,peer_id,direction,body,created_at,state,read) VALUES('m1','ptA',1,x'00',5,'QUEUED',1)",
                    "INSERT INTO outbox(msg_id,peer_id,envelope,next_attempt_at,created_at,expires_at) VALUES('m1','ptA',x'01',0,5,99)",
                )
            )
            run(c, Schema.statements(1, 2))
            assertEquals(1, count(c, "contacts"))
            assertEquals(1, count(c, "messages"))
            assertEquals(1, count(c, "outbox"))
            assertTrue(columns(c, "messages").containsAll(setOf("read_at", "pinned")))
            assertTrue(columns(c, "contacts").contains("muted"))
            c.createStatement().use { st ->
                st.executeQuery("SELECT pinned, (SELECT muted FROM contacts) FROM messages").use {
                    assertTrue(it.next())
                    assertEquals(0, it.getInt(1))
                    assertEquals(0, it.getInt(2))
                }
            }
        }
    }

    @Test
    fun deletingMessageCascadesToOutbox() {
        open().use { c ->
            run(c, Schema.statements(0, Schema.VERSION))
            run(
                c,
                listOf(
                    "INSERT INTO messages(id,peer_id,direction,body,created_at,state,read) VALUES('m1','ptA',1,x'00',5,'QUEUED',1)",
                    "INSERT INTO outbox(msg_id,peer_id,envelope,next_attempt_at,created_at,expires_at) VALUES('m1','ptA',x'01',0,5,99)",
                )
            )
            run(c, listOf("DELETE FROM messages WHERE id='m1'"))
            assertEquals(0, count(c, "outbox"))
        }
    }

    @Test
    fun outboxRejectsOrphans() {
        open().use { c ->
            run(c, Schema.statements(0, Schema.VERSION))
            try {
                run(c, listOf("INSERT INTO outbox(msg_id,peer_id,envelope,next_attempt_at,created_at,expires_at) VALUES('nope','ptA',x'01',0,5,99)"))
                fail("foreign key must reject an orphan outbox row")
            } catch (expected: java.sql.SQLException) {
            }
        }
    }

    @Test
    fun processedTableRejectsDuplicateIds() {
        open().use { c ->
            run(c, Schema.statements(0, Schema.VERSION))
            run(c, listOf("INSERT INTO processed(peer_id,msg_id,at) VALUES('ptA','m1',1)"))
            try {
                run(c, listOf("INSERT INTO processed(peer_id,msg_id,at) VALUES('ptA','m1',2)"))
                fail("duplicate (peer,msg) must be rejected")
            } catch (expected: java.sql.SQLException) {
            }
        }
    }

    @Test
    fun invalidRangesAreRejected() {
        try {
            Schema.statements(2, 1)
            fail()
        } catch (expected: IllegalArgumentException) {
        }
        try {
            Schema.statements(0, Schema.VERSION + 1)
            fail()
        } catch (expected: IllegalArgumentException) {
        }
    }
}
