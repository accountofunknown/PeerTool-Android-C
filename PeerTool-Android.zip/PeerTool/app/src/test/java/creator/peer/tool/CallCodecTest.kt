package creator.peer.tool

import creator.peer.tool.protocol.Inner
import creator.peer.tool.protocol.InnerCodec
import creator.peer.tool.protocol.Limits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CallCodecTest {
    private fun rt(i: Inner): Inner? = InnerCodec.decode(InnerCodec.encode(i))

    @Test
    fun callMessagesRoundTrip() {
        val offer = Inner.CallOffer("c1", true, "v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\n")
        assertEquals(offer, rt(offer))
        assertEquals(Inner.CallOffer("c1", false, "v=0"), rt(Inner.CallOffer("c1", false, "v=0")))
        val answer = Inner.CallAnswer("c1", "v=0\r\n")
        assertEquals(answer, rt(answer))
        val ice = Inner.CallIce("c1", "0", 0, "candidate:1 1 udp 2122260223 192.168.1.5 54321 typ host")
        assertEquals(ice, rt(ice))
        assertEquals(Inner.CallEnd("c1", "declined"), rt(Inner.CallEnd("c1", "declined")))
    }

    @Test
    fun malformedCallMessagesAreRejected() {
        assertNull(rt(Inner.CallOffer("", true, "v=0")))
        assertNull(rt(Inner.CallOffer("c1", true, "")))
        assertNull(rt(Inner.CallOffer("c1", true, "x".repeat(Limits.MAX_SDP + 1))))
        assertNull(rt(Inner.CallAnswer("c1", "")))
        assertNull(rt(Inner.CallIce("c1", "0", 0, "")))
        assertNull(rt(Inner.CallIce("c1", "0", 0, "x".repeat(1_025))))
        assertNull(rt(Inner.CallIce("c1", "0", 99, "candidate:1")))
        assertNull(rt(Inner.CallIce("c1", "0", -1, "candidate:1")))
        assertNull(rt(Inner.CallEnd("", "hangup")))
    }

    @Test
    fun longReasonsAreTruncatedNotTrusted() {
        val d = rt(Inner.CallEnd("c1", "r".repeat(500))) as Inner.CallEnd
        assertEquals(40, d.reason.length)
    }
}
