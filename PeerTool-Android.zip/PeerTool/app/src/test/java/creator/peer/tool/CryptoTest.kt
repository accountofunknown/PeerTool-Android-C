package creator.peer.tool

import creator.peer.tool.crypto.BundleCodec
import creator.peer.tool.crypto.IdentityKeys
import creator.peer.tool.crypto.PeerCrypto
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class CryptoTest {
    private val alice = IdentityKeys.generate()
    private val bob = IdentityKeys.generate()

    @Test
    fun peerIdIsDerivedFromBundleAndWellFormed() {
        assertTrue(PeerCrypto.isValidPeerId(alice.peerId))
        assertEquals(alice.peerId, PeerCrypto.peerIdOf(alice.bundle))
        assertNotEquals(alice.peerId, bob.peerId)
        assertTrue(PeerCrypto.validateBundle(alice.bundle))
    }

    @Test
    fun bundleParserRejectsMalformedInput() {
        assertNull(BundleCodec.parse(ByteArray(0)))
        assertNull(BundleCodec.parse(alice.bundle + byteArrayOf(0)))
        assertNull(BundleCodec.parse(alice.bundle.copyOf(alice.bundle.size - 1)))
        val bad = alice.bundle.copyOf().also { it[0] = 'X'.code.toByte() }
        assertNull(BundleCodec.parse(bad))
        assertFalse(PeerCrypto.validateBundle(ByteArray(40) { 1 }))
    }

    @Test
    fun hybridEncryptionRoundTripAndContextBinding() {
        val ctx = "PT1|msg|id1|a|b".toByteArray()
        val ct = PeerCrypto.encryptFor(bob.bundle, "secret hello".toByteArray(), ctx)
        assertNotNull(ct)
        assertArrayEquals("secret hello".toByteArray(), bob.decrypt(ct!!, ctx))
        // wrong context (e.g. message replayed under a different id) must fail
        try {
            bob.decrypt(ct, "PT1|msg|id2|a|b".toByteArray())
            fail("decrypt with wrong context must fail")
        } catch (expected: java.security.GeneralSecurityException) {
        }
        // wrong recipient must fail
        try {
            alice.decrypt(ct, ctx)
            fail("wrong recipient must fail")
        } catch (expected: java.security.GeneralSecurityException) {
        }
        // tampering must fail
        val tampered = ct.copyOf().also { it[it.size - 1] = (it[it.size - 1].toInt() xor 1).toByte() }
        try {
            bob.decrypt(tampered, ctx)
            fail("tampered ciphertext must fail")
        } catch (expected: java.security.GeneralSecurityException) {
        }
    }

    @Test
    fun signaturesVerifyOnlyForSignerAndUnmodifiedData() {
        val data = "payload".toByteArray()
        val sig = alice.sign(data)
        assertTrue(PeerCrypto.verify(alice.bundle, sig, data))
        assertFalse(PeerCrypto.verify(bob.bundle, sig, data))
        assertFalse(PeerCrypto.verify(alice.bundle, sig, "payloaD".toByteArray()))
        assertFalse(PeerCrypto.verify(alice.bundle, ByteArray(sig.size), data))
    }

    @Test
    fun privateSerializationRoundTrip() {
        val restored = IdentityKeys.deserialize(alice.serializePrivate())
        assertEquals(alice.peerId, restored.peerId)
        val ctx = "c".toByteArray()
        val ct = PeerCrypto.encryptFor(alice.bundle, "x".toByteArray(), ctx)!!
        assertArrayEquals("x".toByteArray(), restored.decrypt(ct, ctx))
        assertTrue(PeerCrypto.verify(alice.bundle, restored.sign("m".toByteArray()), "m".toByteArray()))
    }
}
