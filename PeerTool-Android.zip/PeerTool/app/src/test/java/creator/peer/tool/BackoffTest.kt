package creator.peer.tool

import creator.peer.tool.core.Backoff
import creator.peer.tool.core.Base32
import creator.peer.tool.core.TextSafety
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class BackoffTest {
    private val b = Backoff(baseMs = 5_000, capMs = 900_000, jitter = 0.2)

    @Test
    fun delayGrowsAndStaysWithinJitterBounds() {
        val rnd = Random(42)
        var prevMin = 0L
        for (attempt in 0..30) {
            val d = b.delayMs(attempt, rnd)
            assertTrue("attempt $attempt delay $d", d >= 1)
            assertTrue(d <= b.maxDelayMs())
            val raw = minOf(900_000L, 5_000L * (1L shl minOf(attempt, 20)))
            assertTrue(d >= (raw * 0.8).toLong() - 1)
            assertTrue(d <= (raw * 1.2).toLong() + 1)
            assertTrue(raw >= prevMin)
            prevMin = raw
        }
    }

    @Test
    fun negativeAttemptIsTreatedAsFirst() {
        val d = b.delayMs(-5, Random(1))
        assertTrue(d in 4_000L..6_000L)
    }

    @Test
    fun base32HasExpectedLengthAndAlphabet() {
        val s = Base32.encode(ByteArray(16) { it.toByte() })
        assertEquals(26, s.length)
        assertTrue(s.all { it in 'a'..'z' || it in '2'..'7' })
    }

    @Test
    fun base32KnownVector() {
        // RFC 4648: BASE32("foobar") = MZXW6YTBOI====== (lower-case, no padding here)
        assertEquals("mzxw6ytboi", Base32.encode("foobar".toByteArray()))
    }

    @Test
    fun sanitizeNameRemovesControlAndBidiCharacters() {
        val dirty = "  Al\u202Eice\u0007  \n Smith  "
        assertEquals("Alice Smith", TextSafety.sanitizeName(dirty))
        assertEquals(40, TextSafety.sanitizeName("x".repeat(100)).length)
    }
}
